#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/cdrom.h>
#include <linux/iso_fs.h>

struct ISODR
{
	struct ISODR *next;
	struct iso_directory_record isodr;
};
enum {
	ISODR_FLAG_ISFILE=0,
	ISODR_FLAG_ISDIR=2
};

char **Argv;
char *formatstr[]={
	"Unknown",
	"LBA",
	"MSF"
};
struct ISODR *ISODR=NULL;

void dumpch(char *data, int len);
void hexdump(char *data, int len);

void Exit()
{
	perror(Argv[0]);
	exit(1);
}

void printmsf(struct cdrom_msf0 *msf)
{
	printf("%u:%u:%u",
			msf->minute,
			msf->second,
			msf->frame);
}

unsigned long msf2frame(struct cdrom_msf0 *msf)
{
	return(msf->minute*CD_SECS*CD_FRAMES+
		msf->second*CD_FRAMES+
		msf->frame);
}

char *cdstatus(int status)
{
	char *statusstr[]={
		"CDS_NO_INFO",
		"CDS_NO_DISC",
		"CDS_TRAY_OPEN",
		"CDS_DRIVE_NOT_READY",
		"CDS_DISC_OK"
	};
	char *formatstr[]={
		"CDS_AUDIO",
		"CDS_DATA_1",
		"CDS_DATA_2",
		"CDS_XA_2_1",
		"CDS_XA_2_2",
		"CDS_MIXED"
	};
	if(status<=CDS_DISC_OK && status>=CDS_NO_INFO)
		return(statusstr[status-CDS_NO_INFO]);
	if(status<=CDS_MIXED && status>=CDS_AUDIO)
		return(formatstr[status-CDS_AUDIO]);
	return("Invalid!");
}

void frame2msf(unsigned long i, struct cdrom_msf *msf)
{
	msf->cdmsf_min0  =   i   /CD_SECS   /CD_FRAMES;
	msf->cdmsf_sec0  =  (i   /CD_FRAMES)%CD_SECS;
	msf->cdmsf_frame0=   i   %CD_FRAMES;
	msf->cdmsf_min1  =  (i+1)/CD_SECS   /CD_FRAMES;
	msf->cdmsf_sec1  = ((i+1)/CD_FRAMES)%CD_SECS;
	msf->cdmsf_frame1=  (i+1)%CD_FRAMES;
}

void printmsf2(struct cdrom_msf *msf)
{
	printf("min0  : %d\n",msf->cdmsf_min0);
	printf("sec0  : %d\n",msf->cdmsf_sec0);
	printf("frame0: %d\n",msf->cdmsf_frame0);
	printf("min1  : %d\n",msf->cdmsf_min1);
	printf("sec1  : %d\n",msf->cdmsf_sec1);
	printf("frame1: %d\n",msf->cdmsf_frame1);
}

void printisodr(struct iso_directory_record *isodr)
{
	char ch;

	printf("length                : %u\n",*isodr->length);
	printf("ext_attr_length       : %u\n",*isodr->ext_attr_length);
	printf("extent                : %ld\n",*(unsigned long*)isodr->extent);
	printf("size                  : %ld\n",*(unsigned long*)isodr->size);
	//printf("date                  : %u\n",*isodr->date);
	printf("flags                 : %u\n",*isodr->flags);
	printf("file_unit_size        : %u\n",*isodr->file_unit_size);
	printf("interleave            : %lu\n",*(unsigned long*)isodr->interleave);
	printf("volume_sequence_number: %u\n",*isodr->volume_sequence_number);
	printf("name_len              : %u\n",*isodr->name_len);
	ch=isodr->name[0];
	printf("name                  : ");
	switch(ch)
	{
		case 0:
			printf(".");
			break;
		case 1:
			printf("..");
			break;
		default:
			printf("%*.*s",*isodr->name_len,*isodr->name_len,isodr->name);
			break;
	}
	printf("\n");
}

void dumpch(char *data, int len)
{
	int i;

	for(i=0;i<len;i++)
		if(isprint(data[i]))
			printf("%c",data[i]);
		else
			printf(".");
}

void hexdump(char *data, int len)
{
	int i,j;

	for(i=0;i<len;i++)
	{
		if(!(i%16))
			printf("\n%8.8x: ",i);
		printf("%2.2x",data[i]&0xff);
		if(!((i+1)%4))
			printf(" ");
		if(((i+1)%16)==0 || (i+1)==len)
		{
			j=i>>4<<4;
			dumpch(&data[j],i-j+1);
		}
	}
	printf("\n");
}

struct ISODR *isoreaddirblock(int fd, int i)
{
	struct iso_directory_record *isodrptr;
	struct ISODR *ISODR=NULL, *isodr=NULL;
	struct cdrom_msf msf;
	u_char data[CD_FRAMESIZE_RAW];
	void *ptr;
	int offset;

	frame2msf(i,&msf);
	printmsf2(&msf);
	memcpy(data,&msf,sizeof(msf));
	if(ioctl(fd,CDROMREADRAW,data,data) < 0)
		Exit(Argv[0]);
	else
	{
		hexdump(data+CD_SYNC_SIZE+CD_HEAD_SIZE+CD_SUBHEAD_SIZE,2048);
		printf("\n");
		ptr=data+CD_SYNC_SIZE+CD_HEAD_SIZE+CD_SUBHEAD_SIZE;
		offset=0;
		while(offset<2048)
		{
			isodrptr=ptr+offset;
			if(!*isodrptr->length) return(ISODR);
			if(!ISODR)
			{
				isodr=ISODR=malloc(*isodrptr->length+sizeof(struct ISODR*));
				isodr->next=NULL;
			}
			else
			{
				isodr->next=malloc(*isodrptr->length+sizeof(struct ISODR*));
				isodr=isodr->next;
				isodr->next=NULL;
			}
			memcpy(&isodr->isodr, isodrptr, *isodrptr->length);
			printf("offset                ) %d\n",offset);
			printisodr(isodrptr);
			offset+=*isodrptr->length;
		}
	}
	return(ISODR);
}

int main(int argc, char **argv)
{
	int fd,i;
	struct cdrom_tochdr toc;
	struct cdrom_tocentry toce;
	struct cdrom_mcn mcn;
	struct cdrom_multisession ms;
	struct cdrom_msf msf;
	struct iso_directory_record *isodrptr;
	struct ISODR *isodr, *isodrtail;
	u_char data[CD_FRAMESIZE_RAW], isopddata[CD_FRAMESIZE_RAW];
	FILE *f=NULL,*b;
	char fname[1024];
	struct iso_primary_descriptor *isopd;
	unsigned long trackoffset=0;

	Argv=argv;
	fd=open(argv[1],O_RDONLY);
	if(fd == -1)
		Exit();
	printf("Opened: %s\n\n",argv[1]);

	printf("RESET\n");
	if(ioctl(fd,CDROMRESET,NULL)==-1)
		Exit();
	printf("\n");

	printf("DRIVE_STATUS\n");
	if((i=ioctl(fd,CDROM_DRIVE_STATUS,CDSL_CURRENT))==-1)
		Exit();
	printf("Drive Status: %d = %s\n",i,cdstatus(i));
	printf("\n");

	printf("DISC_STATUS\n");
	if((i=ioctl(fd,CDROM_DISC_STATUS))==-1)
		Exit();
	printf("Disk Format/Status: %d = %s\n",i,cdstatus(i));
	printf("\n");

	printf("TOCHDR\n");
	if(ioctl(fd,CDROMREADTOCHDR,&toc)==-1)
		Exit();
	printf("First Track: %u\n",toc.cdth_trk0);
	printf("Last  Track: %u\n",toc.cdth_trk1);
	printf("\n");
	
	printf("TOCENTRY\n");
	memset(&toce,0,sizeof(toce));
	toce.cdte_format=CDROM_MSF;
	for(i=toc.cdth_trk0; i<=toc.cdth_trk1; i++)
	{
		toce.cdte_track=i;
		if(ioctl(fd,CDROMREADTOCENTRY,&toce)==-1)
			Exit();
		printf("Track    : %u\n",toce.cdte_track);
		printf("Address  : %u\n",toce.cdte_adr);
		printf("Control  : %u\n",toce.cdte_ctrl);
		printf("Format   : %d = %s\n",toce.cdte_format, formatstr[toce.cdte_format]);
		switch(toce.cdte_format)
		{
			case CDROM_MSF:
				printf("MSF      : %lu  ",msf2frame(&toce.cdte_addr.msf));
				if(i==toc.cdth_trk0)
					trackoffset=msf2frame(&toce.cdte_addr.msf);
				printmsf(&toce.cdte_addr.msf);
				printf("\n");
				break;
			case CDROM_LBA:
				printf("LBA      : 0x%.8x\n",toce.cdte_addr.lba);
				break;
		}
		printf("DataMode : %u\n",toce.cdte_datamode);
	}
	printf("\n");

	printf("MULTISESSION\n");
	ms.addr_format=CDROM_LBA;
	if(ioctl(fd,CDROMMULTISESSION,&ms)==-1)
		perror(argv[0]);
	else
	{
		printf("Address of Last Session: 0x%.8x\n",ms.addr.lba);
		printf("XA Flag                : %d\n",ms.xa_flag);
		printf("Format                 : %d = %s\n",ms.addr_format,formatstr[ms.addr_format]);
	}
	printf("\n");

	printf("MCN\n");
	if(ioctl(fd,CDROM_GET_MCN,&mcn)==-1)
		perror(argv[0]);
	else
		printf("Medium Catalog Number: %s\n",mcn.medium_catalog_number);
	printf("\n");

	printf("iso primary descriptor\n");
	frame2msf(trackoffset+16,&msf);
	printmsf2(&msf);
	memcpy(isopddata,&msf,sizeof(msf));
	if(ioctl(fd,CDROMREADRAW,isopddata,isopddata) < 0)
		perror(argv[0]);
	isopd=(struct iso_primary_descriptor*)(&isopddata[CD_SYNC_SIZE+CD_HEAD_SIZE+CD_SUBHEAD_SIZE]);
	printf("type                  : %d\n",*isopd->type);
	printf("id                    : %5.5s\n",isopd->id);
	printf("version               : %d\n",*isopd->version);
	printf("system_id             : %32.32s\n",isopd->system_id);
	printf("volume_id             : %32.32s\n",isopd->volume_id);
	printf("volume_space_size     : %ld * %d\n",*(long*)isopd->volume_space_size,ISOFS_BLOCK_SIZE);
	printf("volume_set_size       : 0x%lx\n",*(long*)isopd->volume_set_size);
	printf("volume_sequence_number: 0x%lx\n",*(long*)isopd->volume_sequence_number);
	printf("logical_block_size    : %ld\n",*(long*)isopd->logical_block_size);
	printf("path_table_size       : %ld\n",*(long*)isopd->path_table_size);
	printf("type_l_path_table     : %ld\n",*(long*)isopd->type_l_path_table);
	printf("opt_type_l_path_table : %ld\n",*(long*)isopd->opt_type_l_path_table);
	//printf("type_m_path_table     : %ld\n",*(long*)isopd->type_m_path_table);
	//hexdump(isopd->type_m_path_table,4);
	//printf("\nopt_type_m_path_table : %ld\n",*(long*)isopd->opt_type_m_path_table);
	printf("iso directory record\n");
	isodrptr=(struct iso_directory_record*)&isopd->root_directory_record;
	printisodr(isodrptr);
	printf("volume_set_id         : %.28s\n",isopd->volume_set_id);
	printf("publisher_id          : %.128s\n",isopd->publisher_id);
	printf("preparer_id           : %.128s\n",isopd->preparer_id);
	printf("application_id        : %.128s\n",isopd->application_id);
	printf("copyright_file_id     : %.37s\n",isopd->copyright_file_id);
	printf("abstract_file_id      : %.37s\n",isopd->abstract_file_id);
	printf("bibliographic_file_id : %.37s\n",isopd->bibliographic_file_id);
	printf("file_structure_version: %d\n",*isopd->file_structure_version);
	printf("application_data      : ");
	hexdump(isopd->application_data,512);
	printf("\n\n");
	
	i=trackoffset+22;
	printf("Name: %s\n",argv[5]);
	do
	{
		if(!ISODR)
			isodr=isodrtail=ISODR=isoreaddirblock(fd,i);
		else
			isodrtail->next=isoreaddirblock(fd,i);
		while(isodrtail && isodrtail->next)
			isodrtail=isodrtail->next;
		while(isodr && (!(*isodr->isodr.flags&ISODR_FLAG_ISDIR) || (*isodr->isodr.name_len==1)))
			isodr=isodr->next;
		if(isodr)
		{
			printf("\nDIR: \n");
			printisodr(&isodr->isodr);
			i=trackoffset+(*(long*)isodr->isodr.extent);
			isodr=isodr->next;
		}
	} while (isodr);
	printf("\n");

	for(i=(argc>3?atoi(argv[3]):0);
		i<(argc>4?atoi(argv[4]):CD_MINS*CD_SECS*CD_FRAMES);
		i++)
	{
		//printf("\033[H\033[J");
		frame2msf(i,&msf);
		printf("frame : %d\n",i);
		printmsf2(&msf);
		fflush(stdout);
		memcpy(data,&msf,sizeof(msf));
		if(ioctl(fd,CDROMREADRAW,data,data)<0)
		{
			perror(argv[0]);
		}
		else
		{
			if(!f)
				f=fopen(argv[2],"wb");
			if(f)
			{
				fwrite(data,CD_FRAMESIZE_RAW,1,f);
				fflush(f);
			}
			sprintf(fname,"%s%d",argv[2],i);
			b=fopen(fname,"wb");
			fwrite(data,CD_FRAMESIZE_RAW,1,b);
			fclose(b);
		}
	}

	if(f)
		fclose(f);
	close(fd);
	return(0);
}
