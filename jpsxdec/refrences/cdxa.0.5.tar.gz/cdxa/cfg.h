#ifndef cfg_h
#define cfg_h

#include "jax/jax.h"

#define VERSION 0x0055

#define TRIPLE(c)   	(int)(c),(int)(c),(int)(c)

extern char dofilefilter, wavstoponend, playonrip, skipplayonrip;
extern int xascansize;
extern float guiR, guiG, guiB;
extern XColor grays[4];
extern char *mp3command, *mp3ext;

void readcfg(char *filename);
void writecfg(char *filename);
char *cfgname();

#endif
