#define cdxa_c
#include "cdxa.h"

/******************************************************************************/

int handle_expose(Jax *jax)
{
	static Region clip=NULL;
	static XRectangle rect;

	jax->xe.xany.type=Expose; //force for HS expose handler
	if (!clip)
		clip=XCreateRegion();
	rect.x=jax->xe.xexpose.x;
	rect.y=jax->xe.xexpose.y;
	rect.width=jax->xe.xexpose.width;
	rect.height=jax->xe.xexpose.height;
	//printf("Expose %d (%d,%d,%d,%d)\n",jax->xe.xexpose.count,rect.x,rect.y,rect.width,rect.height);
	XUnionRectWithRegion(&rect, clip, clip);
	if(jax->xe.xexpose.count>0)
		return(0);
	XSetRegion(jax->d,jax->gc,clip);
	XDestroyRegion(clip);
	clip=NULL;

	JAXsetfg(jax,grays[1].pixel);
	JAXfillrectangle(jax,0,0,W,H);

	HSeventhandler(jax);

	XSetClipMask(jax->d,jax->gc,None);
	return(0);
}

/******************************************************************************/

int handle_button(Jax *jax)
{
	int rv;

	if((rv=HSeventhandler(jax)))
		return(rv);
	return(0);
}

/******************************************************************************/

int handle_destroy(Jax *jax, Hotspot *hs)
{
	if(playstate==PLAY)
		dspreset(dspfd);
	exit(0);
	return(True);
}

/******************************************************************************/

Hotspot *getHS(int id)
{
	int i;

	if(!id)
		return(NULL);
	for(i=0;i<numhs && hs[i].id!=id; i++);
	if(i>=numhs)
		return(NULL);
	return(&hs[i]);
}

/******************************************************************************/

int deleteHS(int id)
{
	int i;

	if(!id)
		return(0);
	for(i=0;i<numhs && hs[i].id!=id; i++);
	if(i>=numhs)
		return(0);
	numhs--;
	memcpy(&hs[i],&hs[i+1],(numhs-i)*sizeof(Hotspot));
	hs=realloc(hs,(numhs)*sizeof(Hotspot));
	return(1);
}

/******************************************************************************/

int newHS(int x, int y, int w, int h, int state, int type, char* label,
		int (*buttonfunc)(Jax*,Hotspot*),
		void (*drawfunc)(Jax*,Hotspot*))
{
	hs=realloc(hs,(numhs+1)*sizeof(Hotspot));
	hs[numhs].id=hsid++;
	hs[numhs].x=x;
	hs[numhs].y=y;
	hs[numhs].w=w;
	hs[numhs].h=h;
	hs[numhs].state=state|DIRTY;
	hs[numhs].type=type;
	// label is malloc'd then copied
	if(label)
		hs[numhs].label=strdup(label);
	else
	{
		hs[numhs].label=malloc(1);
		hs[numhs].label[0]=0;
	}
	if(buttonfunc)
		hs[numhs].buttonfunc=buttonfunc;
	else
		hs[numhs].buttonfunc=doHS;
	if(drawfunc)
		hs[numhs].drawfunc=drawfunc;
	else
		hs[numhs].drawfunc=drawHS;
	if(type==CANVAS)
	{
		hs[numhs].pixmap=XCreatePixmap(jax->d,jax->w,w,h,jax->xwa.depth);
		JAXsetfg(jax,JAXblack(jax));
		XFillRectangle(jax->d,hs[numhs].pixmap,jax->gc,0,0,w,h);
	}
	else
		hs[numhs].pixmap=0;
	hs[numhs].data=NULL;
	numhs++;
	return(hs[numhs-1].id);
}

/******************************************************************************/

int inHS(Hotspot *h, int x, int y)
{
	return(x>=h->x && x<=h->x+h->w &&
			y>=h->y && y<=h->y+h->h);
}

/******************************************************************************/

int HSeventhandler(Jax *jax)
{
	int i;

	for(i=0; i<numhs; i++)
	{
		Printf("HS event: checking '%s'\n",hs[i].label);
		switch(jax->xe.xany.type)
		{
			case ButtonPress:
				if(jax->xe.xbutton.button!=1)
					return(0);
				if(inHS(&hs[i],jax->xe.xbutton.x, jax->xe.xbutton.y))
				{
					doHS(jax,&hs[i]);
					return(0);
				}
				break;
			case ButtonRelease:
				if(jax->xe.xbutton.button!=1)
					return(0);
				if(inHS(&hs[i],jax->xe.xbutton.x, jax->xe.xbutton.y))
					return(doHS(jax,&hs[i]));
				else
					if(hs[i].state&ACTIVE)
					{
						doHS(jax,&hs[i]);
						return(0);
					}
				break;
			case Expose:
				hs[i].state|=DIRTY;
				drawHS(jax,&hs[i]);
				break;
			case MotionNotify:
				if(hs[i].state&ACTIVE)
					return(doHS(jax,&hs[i]));
				break;
			case NoExpose:
				if(ne>0)
					ne--;
				else
					ne=0;
				break;
		}
	}
	switch(jax->xe.xany.type)
	{
		case Expose:
			drawcurrentlocation();
			break;
	}
	return(0);
}

/******************************************************************************/

int doHS(Jax *jax, Hotspot *h)
{
	int err=0;

	//printf("doHS: '%s'\n",h->label);
	switch(jax->xe.xany.type)
	{
		case ButtonPress:
			switch(h->type)
			{
				case CANVAS:
					h->state=ACTIVE|DIRTY;
					if(h->buttonfunc!=doHS)
						err=h->buttonfunc(jax,h);
					break;
				case BUTTON:
					h->state=ACTIVE|DIRTY|(h->state&LEFT);
					break;
				default:
					break;
			}
			break;
		case MotionNotify:
			switch(h->type)
			{
				case CANVAS:
					if(h->state&ACTIVE)
					{
						if(inHS(h, jax->xe.xbutton.x, jax->xe.xbutton.y))
						{
							if(h->state&REST)
								h->state=ACTIVE;
							h->state|=DIRTY;
							if(h->buttonfunc!=doHS)
								err=h->buttonfunc(jax,h);
						}
						else
						{
							if(!(h->state&REST))
								h->state=DIRTY|ACTIVE|REST;
						}
					}
					break;
				case BUTTON:
					if(h->state&ACTIVE)
					{
						if(inHS(h, jax->xe.xbutton.x, jax->xe.xbutton.y))
						{
							if(h->state&REST)
								h->state=DIRTY|ACTIVE|(h->state&LEFT);
						}
						else
						{
							if(!(h->state&REST))
								h->state=DIRTY|ACTIVE|REST|(h->state&LEFT);
						}
					}
					break;
				default:
					break;
			}
			break;
		case ButtonRelease:
			switch(h->type)
			{
				case CANVAS:
					if(inHS(h, jax->xe.xbutton.x, jax->xe.xbutton.y) && h->state&ACTIVE && h->buttonfunc!=doHS)
						err=h->buttonfunc(jax,h);
					if(!(h->state&REST))
						h->state=REST|DIRTY|(h->state&NOREDRAW);
					else
						h->state=REST|(h->state&NOREDRAW);
					break;
				case BUTTON:
					if(inHS(h, jax->xe.xbutton.x, jax->xe.xbutton.y) && h->state&ACTIVE && h->buttonfunc!=doHS)
						err=h->buttonfunc(jax,h);
					if(!(h->state&REST))
						h->state=REST|DIRTY|(h->state&LEFT);
					else
						h->state=REST|(h->state&LEFT);
					break;
				default:
					break;
			}
			break;
		default:
			printf("pushHS:unknown XEvent type: %d\n",jax->xe.xany.type);
			return(0);
	}
	if(h->drawfunc && h->state&DIRTY && !(h->state&NOREDRAW))
		h->drawfunc(jax,h);
	h->state&=~NOREDRAW;
	return(err);
}

/******************************************************************************/

void drawBox(Jax *jax, int x,int y,int w,int h,int light,int dark)
{
	JAXsetfg(jax,light);
	JAXline(jax,x       ,y      ,x+w-1, y       );
	JAXline(jax,x       ,y      ,x,     y+h-1   );
	JAXsetfg(jax,dark);
	JAXline(jax,x+w-1   ,y      ,x+w-1, y+h-1   );
	JAXline(jax,x       ,y+h-1  ,x+w-1, y+h-1   );
}

/******************************************************************************/

void drawHS(Jax *jax, Hotspot *h)
{
	Printf("drawHS:(\"%s\")state=%x\n",h->label,h->state);
	if(!(h->state&DIRTY))
		return;
	switch(h->type)
	{
		case BUTTON:
			JAXsetfg(jax,grays[(h->state&REST?1:3)].pixel);
			JAXfillrectangle(jax,h->x,h->y,h->w,h->h);
			drawBox(jax,h->x,h->y,h->w,h->h,
					grays[(h->state&REST?2:0)].pixel,
					grays[(h->state&REST?0:2)].pixel);
			drawBox(jax,h->x+1,h->y+1,h->w-2,h->h-2,
					grays[(h->state&REST?2:0)].pixel,
					grays[(h->state&REST?0:2)].pixel);
			JAXsetfg(jax,JAXblack(jax));
			if(h->state&LEFT)
				JAXdrawstring(jax,
					h->x+3,
					h->y+h->h/2+JAXstringfullheight(jax)/2-JAXfontdescent(jax),
					h->label);
			else
				JAXdrawstring(jax,
					h->x+h->w/2-JAXstringwidth(jax,h->label)/2,
					h->y+h->h/2+JAXstringfullheight(jax)/2-JAXfontdescent(jax),
					h->label);
			break;
		case LABEL:
			h->state&=~DIRTY;
			JAXsetfg(jax,grays[1].pixel);
			JAXfillrectangle(jax,h->x,h->y,h->w,h->h);
			JAXsetfg(jax,JAXblack(jax));
			switch(h->state)
			{
				case CENTER:
					Printf("(\"%s\")state=%x CENTER\n",h->label,h->state);
					JAXdrawstring(jax,
							h->x+h->w/2-JAXstringwidth(jax,h->label)/2,
							h->y+h->h/2+JAXstringfullheight(jax)/2-JAXfontdescent(jax),
							h->label);
					break;
				case RIGHT:
					Printf("(\"%s\")state=%x RIGHT\n",h->label,h->state);
					JAXdrawstring(jax,
							h->x+h->w-JAXstringwidth(jax,h->label),
							h->y+h->h/2+JAXstringfullheight(jax)/2-JAXfontdescent(jax),
							h->label);
					break;
				case LEFT:
					Printf("(\"%s\")state=%x LEFT\n",h->label,h->state);
					JAXdrawstring(jax,
							h->x,
							h->y+h->h/2+JAXstringfullheight(jax)/2-JAXfontdescent(jax),
							h->label);
					break;
				default:
					break;
			}
			break;
		case CANVAS:
			if(h->pixmap)
			{
				XCopyArea(jax->d,h->pixmap,jax->w,jax->gc,
						0,0,
						h->w,h->h,
						h->x,h->y);
				ne++;
			}
			break;
	}
	h->state&=~DIRTY;
}

/******************************************************************************/

void redrawHS(int id)
{
	Hotspot *h;

	h=getHS(id);
	if(h)
	{
		h->state|=DIRTY;
		drawHS(jax,h);
	}
}

/******************************************************************************/

void redrawallHS()
{
	int i;

	for(i=0; i<numhs; i++)
	{
		hs[i].state|=DIRTY;
		drawHS(jax,&hs[i]);
	}
}

/******************************************************************************/

void setdata(int id, void *data)
{
	Hotspot *h;

	h=getHS(id);
	h->data=data;
}

/******************************************************************************/

void setlabel(int id, char *str, int maxlen)
{
	Hotspot *h;

	h=getHS(id);
	if(!h)
	{
		printf("HS id %d not found!  cannot set label!\n",id);
		return;
	}
	if(!strcmp(h->label+3,str))
		return;
	if(h->label)
		free(h->label);
	if(!maxlen)
		maxlen=strlen(str);
	h->label=malloc(maxlen+4);
	while(str[strlen(str)-1]=='\n')
		str[strlen(str)-1]=0;
	if(*str == 1)
		strncpy(h->label,str+1,maxlen);
	else
	{
		strcpy(h->label," : ");
		strncpy(h->label+3,str,maxlen);
	}
	h->label[maxlen+3]=0;
	redrawHS(h->id);
}

/******************************************************************************/

void setlabelf(int id, char *format, ...)
{
	char str[8192];
	va_list ap;
	
	va_start(ap, format);
	vsprintf(str,format,ap);
	va_end(ap);
	setlabel(id,str,0);
}

/******************************************************************************/
/******************************************************************************/

int getnewcdrom(ISO9660 *iso, char *dev, char track)
{
	if(cdloaded)
		closeISO9660(iso);
	if(openISO9660(iso, dev))
		if(gettocISO9660(iso, track))
			if(getisopdISO9660(iso))
				if(getisodirISO9660(iso))
					return(1);
	return(0);
}

/******************************************************************************/

int selectfile(ISO9660 *iso, char *filename)
{
	if(!findfileISO9660(iso,filename))
		return(0);
	calcboundsISO9660(iso);
	return(1);
}

/******************************************************************************/

void simplexaplay(char *dev, char *filename, char channel, long samplerate)
{
	unsigned long i;
	long size;

	getnewcdrom(&iso, dev, 0);
	if(!selectfile(&iso, filename))
	{
		printf("File not found:%s\n",filename);
		exit(1);
	}
	i=0;
	initXaDecode();
	if(!(dspfd=opendsp()))
		exit(1);
	if(!setdspbits(dspfd,16))
		exit(1);
	if(!setdspchannels(dspfd,2))
		exit(1);
	if(!setdsprate(dspfd,samplerate))
		exit(1);
	if(!setdspS16LE(dspfd))
		exit(1);
	while(ripISO9660RawFrame(&iso,i))
	{
		if((size=convXaToWave(iso.data,wav,channel,0,255)))
			writedsp(dspfd,wav,size);
		i++;
	}
	closedsp(dspfd);
}

/******************************************************************************/

void mkmapdir()
{
	struct stat buf;
	char *env;

	env=getenv("HOME");
	if(env)
		strcpy(mapdir,env);
	else
		mapdir[0]=0;
	strcat(mapdir,"/.cdxa");
	if(stat(mapdir,&buf)==-1 && errno==ENOENT)
		mkdir(mapdir,0755);
}

/******************************************************************************/

int main(int argc, char **argv)
{
	if(argc>5 || argc==3)
	{
		fprintf(stderr,"wrong usage!\n");
		exit(1);
	}
	if(argc<3)
	{
		mkmapdir();
		cdxaplay(argc>1?argv[1]:dev);
		exit(0);
	}
	simplexaplay(argv[1], argv[2], atoi(argv[3]), (argc>4?atoi(argv[4]):Hz));
	return(0);
}

/******************************************************************************/

void cdxaplay(char *_dev)
{
	int i;

	dev=_dev;
	jax=JAXinit(NULL,NULL,NULL,NULL);
	if(!jax)
		exit(1);
	readcfg(NULL);
	JAXcreatewin(jax,
			0,0,
			W,H,
			"CDXA",
			"CDXA",
			0,NULL);
	if(!XGetWindowAttributes(jax->d, jax->w, &jax->xwa))
		exit(0);
	jax->xsh->flags=(PMinSize | PMaxSize | PResizeInc);
	jax->xsh->min_height=
		jax->xsh->max_height=
		jax->xsh->height=H;
	jax->xsh->min_width=
		jax->xsh->max_width=
		jax->xsh->width=W;
	jax->xsh->width_inc=
		jax->xsh->height_inc=0;
	JAXuseGeometry(jax,0);
	JAXdefaultGC(jax);
	JAXloadqueryfont(jax,FONT);
	JAXsetGCfont(jax);

	for(i=0;i<sizeof(grays)/sizeof(XColor);i++)
		XAllocColor(jax->d,jax->cmap,&grays[i]);
	for(i=0;i<sizeof(colors)/sizeof(XColor);i++)
		XAllocColor(jax->d,jax->cmap,&colors[i]);

	JAXaddevents(jax,je);
	JAXsetEH(jax,JAXeventhandler);
	
	//create GUI
	createGUI(jax);
	
	//show GUI
	JAXmapraised(jax);

	//handle GUI
	JAXeventloop(jax);

	exit(0);
}

/******************************************************************************/

int maxStringWidth(Jax *jax,int num_strings, ...)
{
	int max=0,w,i;
	va_list ap;
	char *str;

	va_start(ap,num_strings);
	for(i=0;i<num_strings;i++)
	{
		str=va_arg(ap, char*);
		w=JAXstringwidth(jax,str);
		if(max<w)
			max=w;
	}
	va_end(ap);
	return(max);
}

/******************************************************************************/

void createGUI(Jax *jax)
{
	int x,y,h,w,fh,t,t2,b,r,i;
	char str[1024];

	fh=JAXstringfullheight(jax)+2;

	w=W/6;
	x=0;
	y=0;
	h=fh+4;
	newHS(x,y,w,h,REST,BUTTON,"Eject CDROM",ejectcdrom,NULL);
	x+=w;
	newHS(x,y,w,h,REST,BUTTON,"Load CDROM",newcdrom,NULL);
	x+=w;
	newHS(x,y,w,h,REST,BUTTON,"Open File",openfile,NULL);
	x+=w;
	newHS(x,y,w,h,REST,BUTTON,"Map File",mapfile,NULL);
	x+=w;
	newHS(x,y,w,h,REST,BUTTON,"Save Wav",savewav,NULL);
	x+=w;
	savemp3id=newHS(x,y,w,h,REST,BUTTON,"Save XXX",savewav,NULL);
	setlabelf(savemp3id,"\001Save %s",mp3ext);
	x+=w;
	y+=h+2;

	h=fh+2;
	t=y;
	x=2;
	w=JAXstringwidth(jax,"CDROM ");
	newHS(x,y,w,h,LEFT,LABEL,"CDROM ",NULL,NULL);
	x+=w+5;
	w=maxStringWidth(jax,4,"Name","Publisher","Preparer","Application");
	newHS(x,y,w,h,LEFT,LABEL,"Name",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Publisher",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Preparer",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Application",NULL,NULL);
	x+=w;
	y=t;
	w=(W/3)-x;
	L.cdrom_name=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.cdrom_pub=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.cdrom_prep=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.cdrom_app=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;

	y=t;
	w=W*2/3;
	x=W-w;
	for(i=0;i<MAX_MESSAGE;i++)
	{
		L.messages[i]=newHS(x,y,w,h,LEFT,LABEL,"",NULL,NULL);
		y+=h;
	}
	message=0;

	t2=y;
	
	t=y;
	x=2;
	w=JAXstringwidth(jax,"XA File ");
	newHS(x,y,w,h,LEFT,LABEL,"XA File ",NULL,NULL);
	x+=w+5;
	w=maxStringWidth(jax,3,"Name","Frames","Channels");
	newHS(x,y,w,h,LEFT,LABEL,"Name",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Frames",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Channels",NULL,NULL);
	x+=w;
	y=t;
	w=(W/3)-x;
	L.xa_name=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	w=(W/2)-x;
	L.xa_frames=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.xa_channels=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	
	t=y;
	x=2;
	w=JAXstringwidth(jax,"Frame ");
	newHS(x,y,w,h,LEFT,LABEL,"Frame ",NULL,NULL);
	x+=w+5;
	w=maxStringWidth(jax,5,"MSF","Channel","File #","Type","Stereo");
	newHS(x,y,w,h,LEFT,LABEL,"MSF",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Channel",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"File #",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Type",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Stereo",NULL,NULL);
	x+=w;
	y=t;
	w=(W/2)-x;
	L.frame_msf=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.frame_channel=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.frame_filenum=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.frame_type=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.frame_stereo=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);

	b=y+h;
	r=(W/2);
	
	y=t2;
	t=y;
	x=r;
	w=JAXstringwidth(jax,"Channel ");
	newHS(x,y,w,h,LEFT,LABEL,"Channel ",NULL,NULL);
	x+=w+5;
	w=maxStringWidth(jax,4,"Number","Name","Length","Files");
	newHS(x,y,w,h,LEFT,LABEL,"Number",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,REST,BUTTON,"Name",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Length",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Files",NULL,NULL);
	x+=w;
	y=t;
	w=(W/2)-x;
	L.channel_num=newHS(x,y,w,h,LEFT,LABEL," : 00",NULL,NULL);
	y+=h;
	L.channel_name=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.channel_len=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.channel_files=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;

	t=y;
	x=r;
	w=JAXstringwidth(jax,"Channel File ");
	newHS(x,y,w,h,LEFT,LABEL,"Channel File ",NULL,NULL);
	x+=w+5;
	w=maxStringWidth(jax,3,"Name","Rate","Length");
	newHS(x,y,w,h,REST,BUTTON,"Name",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Rate",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Length",NULL,NULL);
	y+=h;
	newHS(x,y,w,h,LEFT,LABEL,"Offset",NULL,NULL);
	x+=w;
	y=t;
	w=(W/2)-x;
	L.file_name=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	sprintf(str," : %d",Hz);
	L.file_rate=newHS(x,y,w,h,LEFT,LABEL,str,NULL,NULL);
	y+=h;
	L.file_len=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;
	L.file_offset=newHS(x,y,w,h,LEFT,LABEL," : ",NULL,NULL);
	y+=h;

	x=0;
	y=b;
	w=W;
	h=(65536>>WAVESHIFT)*2;
	C.wave=newHS(x,y,w,h,REST,CANVAS,NULL,NULL,NULL);
	y+=h;

	h=fh+4;
	x=2;
	w=JAXstringwidth(jax,"Offset")+6;
	newHS(x,y,w,h,LEFT,LABEL,"Offset",NULL,NULL);
	x+=w;
	w=JAXstringwidth(jax," : 0000000000000")+6;
	L.offset=newHS(x,y,w,h,LEFT,LABEL," : 0",NULL,NULL);
	x+=w+5;
	w=JAXstringwidth(jax,"Play/Pause")+6;
	newHS(x,y,w,h,REST,BUTTON,"Play/Pause",playpause,NULL);
	x+=w;
	w=JAXstringwidth(jax,"Stop")+6;
	newHS(x,y,w,h,REST,BUTTON,"Stop",stop,NULL);
	x+=w+5;
	w=JAXstringwidth(jax,"< Channel")+6;
	newHS(x,y,w,h,REST,BUTTON,"< Channel",channeldown,NULL);
	x+=w;
	w=JAXstringwidth(jax,"Channel >")+6;
	newHS(x,y,w,h,REST,BUTTON,"Channel >",channelup,NULL);
	x+=w+5;
	sprintf(str,"%dHz",Hz);
	w=JAXstringwidth(jax,str)+6;
	newHS(x,y,w,h,REST,BUTTON,str,ratehigh,NULL);
	x+=w;
	sprintf(str,"%dHz",Hz/2);
	w=JAXstringwidth(jax,str)+6;
	newHS(x,y,w,h,REST,BUTTON,str,ratelow,NULL);
	x+=w+5;
	w=JAXstringwidth(jax,"Off")+6;
	newHS(x,y,w,h,REST,BUTTON,"Off",nowave,NULL);
	x+=w;
	w=JAXstringwidth(jax,"Dot")+6;
	newHS(x,y,w,h,REST,BUTTON,"Dot",dotwave,NULL);
	x+=w;
	w=JAXstringwidth(jax,"Line")+6;
	newHS(x,y,w,h,REST,BUTTON,"Line",linewave,NULL);
	x+=w;
	w=JAXstringwidth(jax,"Solid")+6;
	newHS(x,y,w,h,REST,BUTTON,"Solid",solidwave,NULL);
	x+=w;
	/*w=JAXstringwidth(jax,"NoAvg")+6;
	newHS(x,y,w,h,REST,BUTTON,"NoAvg",NULL,NULL);
	*/
	y+=h;

	x=0;
	w=JAXstringwidth(jax,"<")+10;
	h=H-y;
	newHS(x,y,w,h,REST,BUTTON,"<",mapleft,NULL);
	newHS(W-w,y,w,h,REST,BUTTON,">",mapright,NULL);
	x+=w;
	mapw=w=W-(w*2);
	C.map=newHS(x,y,w,h,REST,CANVAS,NULL,mapclick,NULL);
}

/******************************************************************************/

int ejectcdrom(Jax *jax,struct HOTSPOT *h)
{
	if(iso.fd > -1)
		if(ejectCDROM(iso.fd))
			iso.fd=-1;
	playstate=STOP;
	cdloaded=False;
	return(0);
}

/******************************************************************************/

int newcdrom(Jax *jax,struct HOTSPOT *h)
{
	printm("Loading ISO9660 directories from %s\n",dev);
	playstate=STOP;
	cdloaded=False;
	if(getnewcdrom(&iso,dev,track))
	{
		setlabel(L.cdrom_name,iso.isopd->volume_id,28);
		setlabel(L.cdrom_pub,iso.isopd->publisher_id,128);
		setlabel(L.cdrom_prep,iso.isopd->preparer_id,128);
		setlabel(L.cdrom_app,iso.isopd->application_id,128);
		cdloaded=True;
	}
	else
		printm("ERROR: Couldn't get new cdrom!\n");
	iso.isodr=NULL;
	xamap=NULL;
	return(0);
}

/******************************************************************************/

char isxafile(struct ISODR *isodr, char *filename)
{
	int i;
	char isxa;

	if(!dofilefilter)
		return(1);
	iso.isodr=isodr;
	if(!selectfile(&iso, filename))
	{
		printf("ERROR: File not found:%s\n",filename); // messages are not available here
		return(0);
	}
	//printf("Checking file %s:\n",filename);
	for(isxa=False, i=0; !isxa && i<xascansize && i<iso.end-iso.start+1 && ripISO9660RawFrame(&iso,i); i++)
	{
		//printf("%d) type=0x%x\n", i, xatype((SoundSector*)(iso.data)));
		isxa=(xatype((SoundSector*)(iso.data))&(XA_AUDIO|XA_VIDEO|XA_DATA)&&
				xatype((SoundSector*)(iso.data))&(XA_REALTIME));
	}
	//printf("isxa=%d i=%d xascansize=%d iso.end-iso.start+1=%d\n",isxa,i,xascansize,iso.end-iso.start+1);
	return(isxa);
}

/******************************************************************************/

int openfile(Jax *jax,struct HOTSPOT *h)
{
	Hotspot *oldHS;
	int oldnumhs, oldhsid, cancelid;
	struct ISODR *p, *pp;
	char str[4096];

	stop(jax,h);
	printm("Scanning files on cdrom (%s %d sectors)\n",dofilefilter?"filtering":"not filtering",xascansize);

	//save and reset Hotspots
	oldHS=hs;	oldnumhs=numhs;	oldhsid=hsid;
	hs=NULL;	numhs=0;		hsid=1;
	JAXsetfg(jax,grays[1].pixel);
	JAXfillrectangle(jax,0,0,W,H);
	
	{
		int x,y,w,h,ww,id;

		w=0;
		busy=True;
		h=JAXstringfullheight(jax)+6;
		cancelid=newHS(0,H-h,W,h,REST,BUTTON,"Cancel",cancelfileselect,NULL);
		p=iso.ISODR;
		for(x=0; p && x<W; x+=w)
		{
			while(p && *p->isodr.flags&ISODR_FLAG_ISDIR)
				p=p->next;
			for(pp=p, y=0; pp && y+h<=H; y+=h, pp=pp?pp->next:NULL)
			{
				while(pp && *pp->isodr.flags&ISODR_FLAG_ISDIR)
					pp=pp->next;
				if(pp)
				{
					sprintf(str,"%s/%-*.*s",pp->path,*pp->isodr.name_len,*pp->isodr.name_len,pp->isodr.name);
					//printf("%d|%s|%s|%s|\n",*pp->isodr.name_len,pp->path,pp->isodr.name,str);
					ww=JAXstringwidth(jax,str)+6;
					if(w<ww)
						w=ww;
				}
			}
			for(y=0; p && y+h<=H-h; p=p?p->next:NULL)
			{
				while(p && *p->isodr.flags&ISODR_FLAG_ISDIR)
					p=p->next;
				if(p)
				{
					sprintf(str,"%s/%-.*s",p->path,*p->isodr.name_len,p->isodr.name);
					if(dofilefilter)
						setlabelf(cancelid,"\001Filtering %d sectors of file %s",xascansize,str);
					JAXpendingevents(jax);
					if(p->isxa&2) // unscanned
						p->isxa=isxafile(p,str);
					if(p->isxa)
					{
						p->isxa=True;
						id=newHS(x,y,w,h,REST|LEFT,BUTTON,str,setfilename,NULL);
						setdata(id,p);
						redrawallHS();
						y+=h;
					}
					else
						p->isxa=False;
				}
			}
		}
	}
	
	redrawallHS();
	setlabelf(cancelid,"\001Cancel");
	busy=False;

	JAXeventloop(jax);

	//restore Hotspots
	hs=oldHS;	numhs=oldnumhs;		hsid=oldhsid;

	JAXsetfg(jax,grays[1].pixel);
	JAXfillrectangle(jax,0,0,W,H);
	redrawallHS();
	dofilenamechange(jax,h);
	
	return(0);
}

/******************************************************************************/

int cancelfileselect(Jax *jax,struct HOTSPOT *h)
{
	if(busy)
		return(False);
	filename=NULL;
	iso.isodr=NULL;
	return(True);
}

/******************************************************************************/

int setfilename(Jax *jax,struct HOTSPOT *h)
{
	if(busy)
		return(False);
	filename=strdup(h->label);
	iso.isodr=h->data;
	return(True);
}

/******************************************************************************/

void setxamapdata()
{
	if(xamap)
	{
		setlabelf(L.xa_channels,"%02d",xamap->channels);
		setlabelf(L.channel_name,"%s",xamap->channel[channel].name);
		setlabelf(L.channel_len,"%d",xamap->channel[channel].frames);
		setlabelf(L.channel_files,"%03d",xamap->channel[channel].files);
		setlabelf(L.file_name,"%s",xamap->channel[channel].file[filenum].name);
		setlabelf(L.file_rate,"%d",xamap->channel[channel].file[filenum].samplerate);
		setlabelf(L.file_len,"%d",xamap->channel[channel].file[filenum].frames);
		setlabelf(L.file_offset,"%d - %d",xamap->channel[channel].file[filenum].offset, xamap->channel[channel].file[filenum].end);
	}
	else
	{
		setlabelf(L.xa_channels,"");
		setlabelf(L.channel_name,"");
		setlabelf(L.channel_len,"");
		setlabelf(L.channel_files,"");
		setlabelf(L.file_name,"");
		setlabelf(L.file_rate,"");
		setlabelf(L.file_len,"");
		setlabelf(L.file_offset," - ");
	}
}

/******************************************************************************/

int dofilenamechange(Jax *jax,struct HOTSPOT *h)
{
	char str[128];
	gzFile f;

	// clear stuff
	if(xamap)
		freemap(xamap);
	xamap=NULL;
	drawmap();
	setlabel(L.xa_name, "", 0);
	setlabel(L.xa_frames, "", 0);
	setframedata(NULL);
	setxamapdata();
	
	if(!filename)
		return(0);
	if(!selectfile(&iso, filename))
	{
		printm("ERROR: File not found:%s\n",filename);
		return(0);
	}
	setlabel(L.xa_name, filename, 0);
	sprintf(str,"%ld", iso.end - iso.start + 1);
	setlabel(L.xa_frames, str, 0);

	// calc CRCs
	isopdcrc=crc32(0,iso.isopddata,CD_FRAMESIZE_RAW);
	//printf("isopdcrc=%8.8lx\n",isopdcrc);
	isodrcrc=crc32(0,(void*)&iso.isodr->isodr,sizeof(struct iso_directory_record));
	//printf("isodrcrc=%8.8lx\n",isodrcrc);

	// get xamap
	if((f=openxamap("r")))
	{
		xamap=readmap(f);
		gzclose(f);
		setxamapdata();
	}
	else
		xamap=newmap(isopdcrc,isodrcrc,iso.end - iso.start + 1,samplerate);
	drawmap();

	// reset offset
	setframe(0,True);
	
	return(0);
}

/******************************************************************************/

void setframedata(SoundSector *ss)
{
	if(ss)
	{
	unsigned char type=xatype(ss);
	filenum=xafileno(ss);
	setlabelf(L.frame_msf,"%x:%02x.%02x",
			(xamsf(ss)>>16)&0xff,(xamsf(ss)>>8)&0xff,(xamsf(ss)>>0)&0xff);
	setlabelf(L.frame_channel,"%02d",xachannel(ss));
	setlabelf(L.frame_filenum,"%2.2x",xafileno(ss));
	setlabelf(L.frame_type,"%2.2x %s/%s/%s/%s/%s/%s/%s/%s",(int)type,
			type&XA_EOF?"EOF":"___",
			type&XA_REALTIME?"RealTime":"________",
			type&XA_FORM?"Form":"____",
			type&XA_TRIGGER?"Trigger":"_______",
			type&XA_DATA?"Data":"____",
			type&XA_AUDIO?"Audio":"_____",
			type&XA_VIDEO?"Video":"_____",
			type&XA_EOR?"EOR":"___");
	if(ISXAAUDIO(xatype(ss)))
		setlabelf(L.frame_stereo,"%s Flags : %d%d%d%d%d%d%d%d",
				ISXAAUDIO(xatype(ss))
					?xastereo(ss)
						?"Yes"
						:"No"
					:"N/A",
				BIT(ss->sectorFiller[XAFlags],7),
				BIT(ss->sectorFiller[XAFlags],6),
				BIT(ss->sectorFiller[XAFlags],5),
				BIT(ss->sectorFiller[XAFlags],4),
				BIT(ss->sectorFiller[XAFlags],3),
				BIT(ss->sectorFiller[XAFlags],2),
				BIT(ss->sectorFiller[XAFlags],1),
				BIT(ss->sectorFiller[XAFlags],0)
				);
	else
		setlabelf(L.frame_stereo,"N/A");
	}
	else
	{
		setlabelf(L.frame_msf," :  .");
		setlabelf(L.frame_channel,"");
		setlabelf(L.frame_filenum,"");
		setlabelf(L.frame_type,"  .   ___/_______/____/_______/____/_____/_____/___");
		setlabelf(L.frame_stereo,"");
	}
}

/******************************************************************************/

void drawcurrentlocation()
{
	if(xamap)
		drawmapbar(getmapx(frame),channel,XACURRENT,False,True);
}

/******************************************************************************/

void setframe(unsigned long i, int doread)
{
	static int x,y;

	if(!iso.isodr)
		return;
	if(frame!=i)
	{
		frame=i;
		setlabelf(L.offset,"%lu %3d%%",frame,frame*100/xamap->frames);
		if(doread)
		{
			ripISO9660RawFrame(&iso,i);
			setframedata((SoundSector*)iso.data);
		}
		if(x!=getmapx(i) || y!=channel)
		{
			drawmapbar(x,y,maptypes[x][y],False,True);
			x=getmapx(i);
			y=channel;
			drawmapbar(x,y,XACURRENT,False,True);
		}
	}
}

/******************************************************************************/

int chkready()
{
	if(!cdloaded)
	{
		printm("CDROM not loaded!\n");
		return(0);
	}
	if(!iso.isodr)
	{
		printm("No file selected!\n");
		return(0);
	}
	return(1);
}

/******************************************************************************/

void setchannels(int c)
{
	dspsync(dspfd);
	setdspchannels(dspfd,c);
	stereo=c==2;
}

/******************************************************************************/

int playpause(Jax *jax,struct HOTSPOT *h)
{
	static unsigned long i,notdone;
	long size;
	//int blksize;
	SoundSector *ss;

	if(playstate==WAV || playstate==MP3)
		return(0);
	if(!iso.isodr)
		return(0);
	if(!chkready())
		return(0);
	if(playstate==MAP)
		return(mapfile(jax,h));
	if(playstate==STOP)
		i=frame;
	if(playstate==PLAY)
	{
		playstate=PAUSE;
		dspreset(dspfd);
		return(0);
	}
	h->state=REST|DIRTY;
	redrawHS(h->id);
	initXaDecode();
	if(!(dspfd=opendsp()))
		return(0);
	//setdspfrag(dspfd,8,12);
	if(!setdspbits(dspfd,16))
		return(0);
	if(!setdspchannels(dspfd,(stereo?2:1)))
		return(0);
	if(!setdsprate(dspfd,samplerate))
		return(0);
	if(!setdspS16LE(dspfd))
		return(0);
	//setdspfrag(dspfd, 1<<13);
	//getdspblksize(dspfd,&blksize);
	//blksize=(blksize/8192)&0xffffe;
	//setdspdiv(dspfd,blksize);
	playstate=PLAY;
	ss=(SoundSector*)iso.data;
	lastbytes=0;
	while(playstate==PLAY && (notdone=ripISO9660RawFrame(&iso,i)))
	{
		if(framechanged)
		{
			i=frame;
			framechanged=0;
			lastbytes=0;
			continue;
		}
		setframe(i,False);
		if(xachannel(ss)==channel)
		{
			//static int bytes;
			//getdspobytes(dspfd,&bytes);
			//fprintf(stderr,"bytesout=0x%08x\033[K\r",bytes);
			setframedata(ss);
			filenum=xafileno(ss);
			setxamapdata();
			if((size=convXaToWave(iso.data,wav,channel,0,255)))
			{
				if(xastereo(ss)!=stereo)
					setchannels(xastereo(ss)+1);
				if(samplerate!=(xahalfhz(ss)?Hz/2:Hz))
					setsamplerate(xahalfhz(ss)?Hz/2:Hz);
				writedsp(dspfd,wav,size);
				dowaveform(wav,size);
				lastbytes+=size;
				//getdspobytes(dspfd, &outbytes);
				//printf("size=%ld outbytes=%d lastbytes=%d diff=%ld\n",size,outbytes,lastbytes,(outbytes-lastbytes)/size);
				//dspsync(dspfd);
			}
		}
		/*//this skip ahead routine seems to be worse than sequental reads...
		for(i++;
				i < xamap->maplen
				&& !((((int)xamap->map[i].channel)&0xff) == channel
					 && (((int)xamap->map[i].type)&0xff) == XAAUDIO) ;
				i++);*/
		i++;//comment this line if trying skip routine above...
		JAXeventnow(jax);
		JAXsync(jax,False);
	}
	dspsync(dspfd);
	closedsp(dspfd);
	if(!notdone)
		playstate=STOP;
	return(0);
}

/******************************************************************************/

int stop(Jax *jax,struct HOTSPOT *h)
{
	Hotspot *hs;

	if(playstate==PLAY)
		dspreset(dspfd);

	// clear waveout
	hs=getHS(C.wave);
	JAXsetfg(jax,JAXblack(jax));
	XFillRectangle(jax->d,hs->pixmap,jax->gc,0,0,hs->w,hs->h);
	redrawHS(C.wave);

	// reset offset
	if(cdloaded && iso.isodr && playstate==STOP)
		setframe(0,True);

	playstate=STOP;
	
	return(0);
}

/******************************************************************************/

int channelup(Jax *jax,struct HOTSPOT *h)
{
	char str[10];
	
	if(!iso.isodr || playstate==WAV || playstate==MP3)
		return(0);
	if(channel==31)
		return(0);
	channel++;
	if(playstate==PLAY)
		dspreset(dspfd);
	sprintf(str,"%02d",channel&0xff);
	setlabel(L.channel_num,str,0);
	setxamapdata();
	return(0);
}

/******************************************************************************/

int channeldown(Jax *jax,struct HOTSPOT *h)
{
	char str[10];
	
	if(!iso.isodr || playstate==WAV || playstate==MP3)
		return(0);
	if(channel==0)
		return(0);
	channel--;
	if(playstate==PLAY)
		dspreset(dspfd);
	sprintf(str,"%02d",channel&0xff);
	setlabel(L.channel_num,str,0);
	setxamapdata();
	return(0);
}

/******************************************************************************/

void setsamplerate(long hz)
{
	if(!iso.isodr)
		return;
	if(samplerate==hz)
		return;
	samplerate=hz;
	setlabelf(L.file_rate,"%ld",samplerate);
	if(playstate==PLAY)
	{
		dspreset(dspfd);
		setdsprate(dspfd,samplerate);
	}
	xamap->channel[channel].file[filenum].samplerate=samplerate;
	setxamapdata();
}

/******************************************************************************/

int ratehigh(Jax *jax,struct HOTSPOT *h)
{
	setsamplerate(Hz);
	return(0);
}

/******************************************************************************/

int ratelow(Jax *jax,struct HOTSPOT *h)
{
	setsamplerate(Hz/2);
	return(0);
}

/******************************************************************************/

int nowave(Jax *jax, Hotspot *h)
{
	wavemode=NONE;
	return(0);
}
int dotwave(Jax *jax, Hotspot *h)
{
	wavemode=DOT;
	return(0);
}
int linewave(Jax *jax, Hotspot *h)
{
	wavemode=LINE;
	return(0);
}
int solidwave(Jax *jax, Hotspot *h)
{
	wavemode=SOLID;
	return(0);
}

/******************************************************************************/
WavQueue *wavbuf=NULL, *tailbuf=NULL, *freebuf=NULL;
/******************************************************************************/

int bufferlen(WavQueue *buf)
{
	WavQueue *wq;
	int i;
	
	for(wq=buf,i=0;wq;i++,wq=wq->next);
	return(i);
}

/******************************************************************************/

void bufferwav(char *wav, int size, int pos)
{
	if(!pos && wavbuf)
	{
		//printf("clearing wavbuf\n");
		tailbuf->next=freebuf;
		freebuf=wavbuf;
		wavbuf=tailbuf=NULL;
	}
	if(!freebuf)
	{
		//printf("adding to freebuf\n");
		freebuf=malloc(sizeof(WavQueue));
		freebuf->next=NULL;
	}
	if(tailbuf)
	{
		//printf("appending to tailbuf\n");
		tailbuf->next=freebuf;
		tailbuf=tailbuf->next;
		freebuf=freebuf->next;
	}
	else
	{
		//printf("creating new wavbuf\n");
		tailbuf=wavbuf=freebuf;
		freebuf=freebuf->next;
	}
	memcpy(tailbuf->wav,wav,size);
	tailbuf->pos=pos;
	tailbuf->size=size;
	tailbuf->next=NULL;
}

/******************************************************************************/

WavQueue *unbufferwav(int pos)
{
	while(wavbuf && wavbuf->pos+wavbuf->size<pos)
	{
		WavQueue *next;
		next=wavbuf->next;
		wavbuf->next=freebuf;
		freebuf=wavbuf;
		wavbuf=next;
		if(!wavbuf)
			tailbuf=NULL;
	}
	if(!wavbuf)
	{
		//printf("wav buffer output underflow!\n");
		lastbytes=0;
		dspreset(dspfd);
		return(NULL);
	}
	return(wavbuf);
}

/******************************************************************************/

static void dowaveform(char *Wav, long Size)
{
	static int x,y[2],lasty[2],h[2],w,size;
	static float xd;
	static Hotspot *hs=NULL;
	static char *wav;
	WavQueue *wq;

	bufferwav(Wav, Size, lastbytes);
	getdspobytes(dspfd, &outbytes);
	wq=unbufferwav(outbytes);
	//printf("lastbytes=%d outbytes=%d wavbuf=%d tailbuf=%d freebuf=%d\n",lastbytes,outbytes,bufferlen(wavbuf),bufferlen(tailbuf),bufferlen(freebuf));
	if(!wavemode)
		return;
	if(!hs)
		hs=getHS(C.wave);
	if(!wq)
		return;
	wav=wq->wav;
	size=wq->size;
	lasty[1]=lasty[0]=hs->h/2;
	JAXsetfg(jax,JAXblack(jax));
	XFillRectangle(jax->d,hs->pixmap,jax->gc,0,0,hs->w,hs->h);
	xd=size/sizeof(short)/(float)W*(stereo?2:1);
	w=W/(stereo?2:1);
	for(x=0;x<w;x++)
	{
		if(stereo)
		{
			h[0]=-((short*)wav)[((int)(x*xd))>>1<<1]/hs->h/2;
			y[0]=h[0]+hs->h/2;
			h[1]=-((short*)wav)[(((int)(x*xd))>>1<<1)+1]/hs->h/2;
			y[1]=h[1]+hs->h/2;
			switch(wavemode)
			{
				case DOT:
					JAXsetfg(jax,colors[GREEN].pixel);
					XDrawPoint(jax->d,hs->pixmap,jax->gc,x,y[0]);
					JAXsetfg(jax,colors[RED].pixel);
					XDrawPoint(jax->d,hs->pixmap,jax->gc,x+W/2,y[1]);
					break;
				case LINE:
					if(x)
					{
						JAXsetfg(jax,colors[GREEN].pixel);
						XDrawLine(jax->d,hs->pixmap,jax->gc,x-1,lasty[0],x,y[0]);
						JAXsetfg(jax,colors[RED].pixel);
						XDrawLine(jax->d,hs->pixmap,jax->gc,x-1+W/2,lasty[1],x+W/2,y[1]);
					}
					lasty[0]=y[0];
					lasty[1]=y[1];
					break;
				case SOLID:
					JAXsetfg(jax,colors[GREEN].pixel);
					if(h[0]<0)
						XFillRectangle(jax->d,hs->pixmap,jax->gc,x,hs->h/2+h[0],1,-h[0]);
					else
						XFillRectangle(jax->d,hs->pixmap,jax->gc,x,hs->h/2,1,h[0]);
					JAXsetfg(jax,colors[RED].pixel);
					if(h[1]<0)
						XFillRectangle(jax->d,hs->pixmap,jax->gc,x+W/2,hs->h/2+h[1],1,-h[1]);
					else
						XFillRectangle(jax->d,hs->pixmap,jax->gc,x+W/2,hs->h/2,1,h[1]);
					break;
				default:
					break;
			}
		}
		else
		{
			JAXsetfg(jax,colors[YELLOW].pixel);
			h[0]=-((short*)wav)[(int)(x*xd)]/hs->h/2;
			y[0]=h[0]+hs->h/2;
			switch(wavemode)
			{
				case DOT:
					XDrawPoint(jax->d,hs->pixmap,jax->gc,x,y[0]);
					break;
				case LINE:
					if(x)
						XDrawLine(jax->d,hs->pixmap,jax->gc,x-1,lasty[0],x,y[0]);
					lasty[0]=y[0];
					lasty[1]=y[1];
					break;
				case SOLID:
					if(h[0]<0)
						XFillRectangle(jax->d,hs->pixmap,jax->gc,x,hs->h/2+h[0],1,-h[0]);
					else
						XFillRectangle(jax->d,hs->pixmap,jax->gc,x,hs->h/2,1,h[0]);
					break;
				default:
					break;
			}
		}
	}
	if(stereo) // draw split for stereo
	{
		JAXsetfg(jax,grays[1].pixel);
		XFillRectangle(jax->d,hs->pixmap,jax->gc,W/2,0,1,hs->h);
	}
	redrawHS(C.wave);
}

/******************************************************************************/

char *basename(char *fname)
{
	char *p;

	p=strrchr(fname,'/');
	if(p)
		p++;
	else
		p=fname;
	return(p);
}

/******************************************************************************/

gzFile openxamap(char *mode)
{
	char fname[MAXPATHLEN+1];
	int i;
	char *p;
	gzFile f;
	
	sprintf(fname,"%s/",mapdir);
	p=iso.isopd->volume_id;
	for(i=31;(p[i]==' ' || !p[i]) && i; i--);
	strncat(fname,p,i+1);
	strcat(fname," - ");
	strcat(fname,basename(filename));
	strcat(fname,".xamap");
	printm("Opened xamap : \"%s\"\n",fname);
	f=gzopen(fname,mode);
	if(!f)
		perror(fname);
	return(f);
}

/******************************************************************************/

int getmapx(long frame)
{
	if(mapframes)
		return(frame/mapframes);
	else
		return(0);
}

/******************************************************************************/

int mapfile(Jax *jax, Hotspot *h)
{
	gzFile f;
	static unsigned long i,notdone;
	SoundSector *ss;
	int cn,fn;

	if(playstate==MAP || playstate==PLAY || playstate==WAV || playstate==MP3)
		return(0);
	if(!chkready())
		return(0);
	printm("Mapping %s, press stop and mapping is able to continue later.\n",filename);
	if(xamap->maplen!=iso.end - iso.start + 1)
	{
		i=xamap->maplen;
		// cleanup button
		h->state=REST;
		redrawHS(h->id);
		// start
		playstate=MAP;
		ss=(SoundSector*)iso.data;
		while((notdone=ripISO9660RawFrame(&iso,i)) && playstate==MAP)
		{
			channel=cn=xachannel(ss);
			filenum=fn=xafileno(ss);
			if(cn>=0 && cn<=32)
			{
				// update xamap info
				if(xamap->channels<cn+1)
				{
					xamap->channels=cn+1;
					drawmap();
				}
				// update xamap channel info
				if(ISXAAUDIO(xatype(ss)))
					xamap->channel[cn].frames++;
				if(xamap->channel[cn].files<fn);
				xamap->channel[cn].files=fn;
				// update xamap channel file info
				if(xamap->channel[cn].file[fn].frames==0)
					xamap->channel[cn].file[fn].offset=i;
				if(ISXAAUDIO(xatype(ss)))
					xamap->channel[cn].file[fn].frames++;
				xamap->channel[cn].file[fn].end=i;
				//update xamap map
				xamap->map[i].channel=cn;
				xamap->map[i].file=fn;
				xamap->map[i].type=xatype(ss);

				setlabelf(L.channel_num,"%02d",channel);
				setxamapdata(ss);
				setframedata(ss);
				setframe(i,False);
				drawmapbar(getmapx(i),cn,xamap->map[i].type,False,True);
				JAXeventnow(jax);
				JAXsync(jax,False);
			}
			i++;
			xamap->maplen=i;
		}
		if(!notdone)
			playstate=STOP;
	}
	//save xamap
	f=openxamap("w");
	if(f)
	{
		writemap(f,xamap);
		gzclose(f);
	}

	drawmap();
	setframe(0,True);

	return(0);
}

/******************************************************************************/

int mapleft(Jax *jax, Hotspot *h)
{
	int i;

	if(!xamap || playstate==MAP)
		return(0);
	for(i=frame-1;
			i>0
			&& ((!ISXAEND(xamap->map[i].type))
				|| (xamap->map[i].channel!=channel));
			i--);
	if(i<0)
		i=0;
	while(i>1
			&& (!ISXAAUDIO(xamap->map[i].type)
				|| (xamap->map[i].channel!=channel)))
		i--;
	if(playstate==PLAY)
		dspreset(dspfd);
	setframe(i,(playstate!=PLAY));
	framechanged=(playstate==PLAY);
	return(0);
}

int mapright(Jax *jax, Hotspot *h)
{
	int i;

	if(!xamap || playstate==MAP)
		return(0);
	for(i=frame+1;
			i<xamap->maplen
			&& ((!ISXAEND(xamap->map[i].type))
				|| xamap->map[i].channel!=channel);
			i++);
	while(i<xamap->maplen
			&& (!ISXAAUDIO(xamap->map[i].type)
				|| (xamap->map[i].channel!=channel)))
		i++;
	if(i>xamap->maplen)
		return(0);
	if(playstate==PLAY)
		dspreset(dspfd);
	setframe(i,(playstate!=PLAY));
	framechanged=(playstate==PLAY);
	return(0);
}

/******************************************************************************/

void drawmapbar(int x, int cn, int type, int updatewin, int direct)
{
	Hotspot *hs;
	int pixel;

	hs=getHS(C.map);
	pixel=-1;
	if(type==XANONE)
		pixel=JAXblack(jax);
	if(ISXAAUDIO(type))
		pixel=colors[BLUE].pixel;
	if(ISXAVIDEO(type))
	{
		if(ISXAAUDIO(type))
			pixel=colors[MAGENTA].pixel;
		else
			pixel=colors[RED].pixel;
	}
	if(ISXADATA(type))
	{
		if(ISXAAUDIO(type))
			pixel=colors[CYAN].pixel;
		else
			pixel=colors[GREEN].pixel;
	}
	if(ISXAEND(type))
		pixel=colors[YELLOW].pixel;
	if(XA_TRIGGER&type)
		pixel=grays[2].pixel;
	if(type==XACURRENT)
		pixel=JAXwhite(jax);
	if(pixel==-1)
		pixel=grays[0].pixel;
	JAXsetfg(jax,pixel);
	if(direct)
	{
		if(hs)
		{
				XFillRectangle(jax->d,jax->w,jax->gc,
						x+hs->x,((int)(mapyd+.5))*cn+hs->y,
						1,(int)(mapyd+.5)-1);
		}
	}
	else
	{
		XFillRectangle(jax->d,hs->pixmap,jax->gc,
				x,((int)(mapyd+.5))*cn,
				1,(int)(mapyd+.5)-1);
	}
	if(updatewin)
		redrawHS(C.map);
}

/******************************************************************************/

void drawmap()
{
	Hotspot *hs;
	unsigned char type;
	int	x,y,oldx,i,cn;

	hs=getHS(C.map);
	JAXsetfg(jax,grays[1].pixel);
	XFillRectangle(jax->d,hs->pixmap,jax->gc,0,0,hs->w,hs->h);
	if(!xamap)
	{
		redrawHS(C.map);
		return;
	}
	if(xamap->channels)
		mapyd=hs->h/(float)xamap->channels;
	else
		mapyd=hs->h/32.0;
	mapframes=(iso.end - iso.start + 1)/(float)hs->w;
	for(y=0;y<32;y++)
	{
		for(x=0;x<W;x++)
			maptypes[x][y]=XANONE;
	}
	oldx=0;
	for(i=0;i<xamap->maplen;i++)
	{
		x=getmapx(i);
		if(x!=oldx)
		{
			for(y=0;y<xamap->channels;y++)
				drawmapbar(oldx,y,maptypes[oldx][y],False,False);
			oldx=x;
		}
		cn=xamap->map[i].channel;
		type=xamap->map[i].type;
		
		if(maptypes[x][cn]==XANONE)
			maptypes[x][cn]=0;
		maptypes[x][cn]|=type;
	}
	for(y=0;y<xamap->channels;y++)
		drawmapbar(oldx,y,maptypes[x][y],False,False);
	redrawHS(C.map);
}

/******************************************************************************/

int mapclick(Jax *jax, Hotspot *hs)
{
	Window junkw;
	int x,y,junki;
	long i;
	static long oldf=-1;
	static int oldx=-1,oldy=-1;
	unsigned int kabs;
	
	if(!iso.isodr || !xamap || playstate==WAV || playstate==MP3)
		return(0);
	hs->state|=NOREDRAW;
	if(jax->xe.xany.type==ButtonRelease)
		return(0);
	XQueryPointer(jax->d,jax->w,&junkw,&junkw,&junki,&junki,&x,&y,&kabs);
	if(!(kabs&Button1Mask))
		return(0);
	x-=hs->x;
	y-=hs->y;
	if(x<0) x=0; if(x>=hs->w) x=hs->w;
	if(y<0) y=0; if(y>=hs->h) y=hs->h;
	if(oldx!=x || oldy!=y || frame!=oldf)
	{
		channel=(int)(y/mapyd);
		for(i=x*mapframes;
				i<(x+1)*mapframes
				&& i<xamap->maplen
				&& xamap->map[i].channel!=channel;
				i++);
		oldf=i;
		if(playstate==PLAY)
			dspreset(dspfd);
		setframe(i,playstate==STOP);
		framechanged=True;
		oldx=x;
		oldy=y;
	}
	return(0);
}

/******************************************************************************/

int savewav(Jax *jax,struct HOTSPOT *h)
{
	static unsigned long i,notdone,start,type;
	unsigned long size,outsize;
	long j,k;
	//int blksize;
	SoundSector *ss;
	FILE *f=NULL;
	int multiplier;
	char fname[4096];

	if(!iso.isodr || !filename)
		return(0);
	if(!chkready())
		return(0);
	if(h->id==savemp3id)
	{
		char cmd[8192], *p;
		
		type=playstate=MP3;
		start=i=frame;
		sprintf(fname,"%s-ch%d",filename+1,channel);
		while((p=strchr(fname,'/'))) *p='-';
		while((p=strchr(fname,'.'))) *p='_';
		strcat(fname,".");
		strcat(fname,mp3ext);
		sprintf(cmd,"%s \"%s\"",mp3command,fname);
		printm("Running \"%s\"\n",cmd);
		f=popen(cmd,"w");
		if(!f)
		{
			perror(cmd);
			return(0);
		}
	}
	else if(playstate==STOP || playstate==PAUSE)
	{
		char *p;
		
		type=playstate=WAV;
		start=i=frame;
		sprintf(fname,"%s-ch%d",filename+1,channel);
		while((p=strchr(fname,'/'))) *p='-';
		while((p=strchr(fname,'.'))) *p='_';
		strcat(fname,".wav");
		printm("Writing WAV file : \"%s\"\n",fname);
		f=createwav(fname,Hz,2);
		if(!f)
		{
			perror(fname);
			return(0);
		}
	}
	else
		return(0);
	outsize=0;
	printm("Press STOP to end ripping, or wait for %s.\n", wavstoponend?"EOF/EOR record":"End of file");
	h->state=REST|DIRTY;
	redrawHS(h->id);
	initXaDecode();
	if(playonrip)
	{
		if(!(dspfd=opendsp()))
			return(0);
		//setdspfrag(dspfd,8,12);
		if(!setdspbits(dspfd,16))
			return(0);
		if(!setdspchannels(dspfd,(stereo?2:1)))
			return(0);
		if(!setdsprate(dspfd,samplerate))
			return(0);
		if(!setdspS16LE(dspfd))
			return(0);
	}
	ss=(SoundSector*)iso.data;
	while((playstate==WAV || playstate==MP3) && (notdone=ripISO9660RawFrame(&iso,i)))
	{
		/*
		if(framechanged)
		{
			i=frame;
			framechanged=0;
			continue;
		}
		*/
		setframe(i,False);
		if(xachannel(ss)==channel)
		{
			//static int bytes;
			//getdspobytes(dspfd,&bytes);
			//fprintf(stderr,"bytesout=0x%08x\033[K\r",bytes);
			if(i>start && ISXAEND(xatype(ss)) && wavstoponend)
			{
				playstate=STOP;
				break;
			}
			setframedata(ss);
			filenum=xafileno(ss);
			setxamapdata();
			if((size=convXaToWave(iso.data,wav,channel,0,255)))
			{
				if(xastereo(ss)!=stereo)
					setchannels(xastereo(ss)+1);
				if(samplerate!=(xahalfhz(ss)?Hz/2:Hz))
					setsamplerate(xahalfhz(ss)?Hz/2:Hz);
				dowaveform(wav,size);
				if(playonrip)
				{
					if(skipplayonrip)
						dspreset(dspfd);
					writedsp(dspfd,wav,size);
				}
				multiplier=(stereo?1:2)*(samplerate==Hz?1:2);
				outsize+=size*multiplier;
				if(stereo)
				{
					for(j=0;j<size/4;j++)
						for(k=0;k<(samplerate==Hz?1:2);k++)
							fwrite(&((long*)wav)[j],4,1,f);
				}
				else
				{
					for(j=0;j<size/2;j++)
						for(k=0;k<multiplier;k++)
							fwrite(&((short*)wav)[j],2,1,f);
				}
								
			}
		}
		/*//this skip ahead routine seems to be worse than sequental reads...
		for(i++;
				i < xamap->maplen
				&& !((((int)xamap->map[i].channel)&0xff) == channel
					 && (((int)xamap->map[i].type)&0xff) == XAAUDIO) ;
				i++);*/
		i++;//comment this line if trying skip routine above...
		JAXeventnow(jax);
		JAXsync(jax,False);
	}
	if(f)
	{
		if(type==WAV)
		{
			closewav(f,outsize);
			printm("%luKB of data written to \"%s\"\n",
					outsize/1024, fname);
		}
		else
		{
			struct stat buf;
			
			pclose(f);
			stat(fname,&buf);
			printm("%luKB of data written to \"%s\" resulting in a %luKB file (%u:1)\n",
					outsize/1024, fname, buf.st_size/1024, outsize/buf.st_size);
		}
	}
	if(playonrip)
	{
		dspsync(dspfd);
		closedsp(dspfd);
	}
	if(!notdone)
		playstate=STOP;
	return(0);
}

/******************************************************************************/

unsigned long wavsizepos,headersize;

FILE *createwav(char *fname, int rate, int channels)
{
	FILE *f;
	struct {
		char           chunkID[4];
		long           chunkSize;
		short          wFormatTag;
		unsigned short wChannels;
		unsigned long  dwSamplesPerSec;
		unsigned long  dwAvgBytesPerSec;
		unsigned short wBlockAlign;
		unsigned short wBitsPerSample;
	} format;
	
	if(!(f=fopen(fname,"w")))
		return(NULL);
	fputs("RIFF",f);
	fwrite(&headersize,sizeof(long),1,f);
	fputs("WAVE",f);
	memcpy(format.chunkID,"fmt ",4);
	format.chunkSize=sizeof(format)-8;
	format.wFormatTag=1;
	format.wChannels=channels;
	format.dwSamplesPerSec=rate;
	format.wBitsPerSample=16;
	format.wBlockAlign=channels*2;
	format.dwAvgBytesPerSec=rate*channels*2;
	fwrite(&format,sizeof(format),1,f);
	memcpy(format.chunkID,"data",4);
	fwrite(&format,4,1,f);
	wavsizepos=ftell(f);
	format.chunkSize=0;
	fwrite(&format.chunkSize,sizeof(long),1,f);
	headersize=sizeof(format)+12;
	return(f);
}

void closewav(FILE *f, long size)
{
	if(!f)
		return;
	fseek(f,wavsizepos,SEEK_SET);
	fwrite(&size,sizeof(long),1,f);
	fseek(f,4,SEEK_SET);
	headersize+=size;
	fwrite(&headersize,sizeof(long),1,f);
	fclose(f);
}

/******************************************************************************/

void printm(char *format, ...)
{
	char str[8192];
	va_list ap;
	Hotspot *hs;
	static int donewline=0;

	if(message<MAX_MESSAGE-1 && donewline)
		message++;
	else
	if(donewline)
	{
		int i;
		for(i=1;i<MAX_MESSAGE;i++)
		{
			hs=getHS(L.messages[i]);
			setlabelf(L.messages[i-1],"\001%s",hs->label);
		}
	}
	va_start(ap, format);
	*str=1;
	vsprintf(str+1,format,ap);
	va_end(ap);
	donewline=(str[strlen(str)-1]=='\n');
	setlabel(L.messages[message],str,0);
	JAXpendingevents(jax);
}
