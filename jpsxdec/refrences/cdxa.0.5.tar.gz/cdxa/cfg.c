#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "cfg.h"

//#define DEBUG

#define False 0
#define True 1

#define	MP3COMMAND "lame -x -r -b128 -V1 -mj -q1 -p -s 37.800 --quiet -"

void setgreys();

char dofilefilter=True, wavstoponend=True, playonrip=True, skipplayonrip=False;
int xascansize=32;
int version=VERSION;
float guiR=70, guiG=70, guiB=70, greyscale[4]={ .700, 1.000, 1.300, 1.600 };
XColor grays[4]=
{
	{0,TRIPLE(65535*3.0/8),0,0},	//bottom
	{0,TRIPLE(65535*5.0/8),0,0},	//background
	{1,TRIPLE(65535*7.0/8),0,0},	//top
	{1,TRIPLE(65535*7.5/8),0,0}		//shine
};
char *mp3command=NULL,*mp3ext=NULL;

/******************************************************************************/

void readcfg(char *fname)
{
	FILE *f;
	char line[4096],*argv[2],*s;
	int n=0;
	
	if(!fname)
		fname=cfgname();
	mp3command=strdup(MP3COMMAND);
	mp3ext=strdup("mp3");
	if((f=fopen(fname,"r")))
	{
#ifdef DEBUG
		printf("reading config file %s\n",fname);
#endif
		version=0;
		while(fgets(line,4096,f))
		{
			n++;
			//argv=makeArgv(line,"#");
			s=strchr(line,'#');
			if(!s)
				s=strchr(line,'\n');
			while(s && s>line && strchr(" \t\n\r",s[-1])) s--;
			if(s)
				*s=0;
			argv[0]=line;
			s=strpbrk(line," \t=");
			if(!s)
				argv[1]=NULL;
			else
			{
				*s=0;
				s++;
				while(*s && strchr(" \t",*s)) s++;
				argv[1]=s;
			}
			if(!strcmp(argv[0],"version"))
				version=strtol(argv[1],NULL,0);
			if(!strcmp(argv[0],"xascansize"))
			{
				xascansize=strtol(argv[1],NULL,0);
				if(xascansize<1)
					dofilefilter=False;
				else
					dofilefilter=True;
			}
			if(!strcmp(argv[0],"guiR"))
				guiR=strtod(argv[1],NULL);
			if(!strcmp(argv[0],"guiG"))
				guiG=strtod(argv[1],NULL);
			if(!strcmp(argv[0],"guiB"))
				guiB=strtod(argv[1],NULL);
			if(!strcmp(argv[0],"wavstoponend"))
				wavstoponend=strtol(argv[1],NULL,0)?1:0;
			if(!strcmp(argv[0],"playonrip"))
				playonrip=strtol(argv[1],NULL,0)?1:0;
			if(!strcmp(argv[0],"skipplayonrip"))
				skipplayonrip=strtol(argv[1],NULL,0)?1:0;
			if(!strcmp(argv[0],"mp3command"))
			{
				if(mp3command)
					free(mp3command);
				mp3command=strdup(argv[1]);
			}
			if(!strcmp(argv[0],"mp3ext"))
			{
				if(mp3ext)
					free(mp3ext);
				mp3ext=strdup(argv[1]);
			}
		}
		fclose(f);
		if(version<VERSION)
		{
			printf("Older config(0x%04X<0x%04X) read in, updating yours at %s\n",version,VERSION,fname);
			writecfg(fname);
		}
	}
	else
	{
		printf("No config found, writing you a new one at %s\n",fname);
		writecfg(fname);
	}
	setgreys();
#ifdef DEBUG
	printf("version=0x%04X\n",version);
	printf("xascansize=%d\n",xascansize);
	printf("  dofilefilter=%d\n",dofilefilter);
	printf("wavstoponend=%d\n",wavstoponend);
	printf("mp3command=%s\n",mp3command);
	printf("mp3ext=%s\n",mp3ext);
	printf("playonrip=%d",playonrip);
	printf("skipplayonrip=%d",skipplayonrip);
#endif
}

/******************************************************************************/

void writecfg(char *fname)
{
	FILE *f;
	
	if(!fname)
		fname=cfgname();
	if((f=fopen(fname,"w")))
	{
		fprintf(f,"#version of cdxa config file\n"
				"# DO NOT CHANGE\n"
				"version=0x%04X\n",VERSION);
		fprintf(f,"\n");

		fprintf(f,"#xascansize=[0-1024]\n"
				"# default is 32, 0 disables filtering\n"
				"xascansize=%d\n",xascansize);
		fprintf(f,"\n");

		fprintf(f,"#wavstoponend=[0/1]\n"
				"# default is 1, 0 disables EOF/EOR detection on ripping wavs/mp3\n"
				"wavstoponend=%d\n",wavstoponend?1:0);
		fprintf(f,"\n");

		fprintf(f,"#playonrip=[0/1]\n"
				"# default is 1, 0 disables playing audio while ripping wavs/mp3\n"
				"# playing audio while ripping will slow down the ripping process if the\n"
				"#   encoding process is faster than the audio can be played.\n"
				"playonrip=%d\n",playonrip?1:0);
		fprintf(f,"\n");

		fprintf(f,"#skipplayonrip=[0/1]\n"
				"# default is 0, 1 enables skip-playing audio while ripping wavs/mp3\n"
				"# this makes it sound like cd audio on fast forward, but keeps the speed high\n"
				"skipplayonrip=%d\n",skipplayonrip?1:0);
		fprintf(f,"\n");

		fprintf(f,"#mp3command=command\n"
				"# defaults:\n"
				"#  LAME (the best there is for mp3)\n"
				"#mp3command="MP3COMMAND"\n"
				"#  GOGO with SMP on 2 cpus (I love the speed!)\n"
				"#mp3command=gogo -s 37.8 -d 44.1 -cpu 2 -v 1 -b 128 -m j -riff wave -offset 0 stdin\n"
				"#  SOX|OggVorbis (sox is required since oggenc only allows 44.1KHz)\n"
				"#mp3command=sox -V -t raw -r 37800 -c 2 -s -w - -t raw -r 44100 -c 2 -s -w - | oggenc -r -b 256 - >\n"
				"mp3command=%s\n",mp3command);
		fprintf(f,"\n");

		fprintf(f,"#mp3ext=extension for encoded file\n"
				"# defaults:\n"
				"#mp3ext=mp3 # for LAME, GOGO, etc...\n"
				"#mp3ext=ogg # for oggenc\n"
				"mp3ext=%s\n",mp3ext);
		fprintf(f,"\n");

		fprintf(f,"#guiR=[0.0-100.0] gui red%%\n"
				"# default 70.0\n"
				"guiR=%.1f\n",guiR);
		fprintf(f,"#guiG=[0.0-100.0] gui green%%\n"
				"# default 70.0\n"
				"guiG=%.1f\n",guiG);
		fprintf(f,"#guiB=[0.0-100.0] gui blue%%\n"
				"# default 70.0\n"
				"guiB=%.1f\n",guiB);

		fprintf(f,"\n# vim: syntax=sh\n");
		fclose(f);
	}
}

/******************************************************************************/

char *cfgname()
{
	static char fname[4096];
	char *home;
	
	home=getenv("HOME");
	snprintf(fname,4096,"%s/.cdxa",home);
	mkdir(fname,0644);
	snprintf(fname,4096,"%s/.cdxa/cdxarc",home);
	return(fname);
}

/******************************************************************************/

void setgreys()
{
	int i;
	float p;

	for(i=0;i<4;i++)
	{
		p=65535*(guiR*greyscale[i])/100.0;
		if(p>65535)
			p=65535;
		grays[i].red  =p;
		p=65535*(guiG*greyscale[i])/100.0;
		if(p>65535)
			p=65535;
		grays[i].green=p;
		p=65535*(guiB*greyscale[i])/100.0;
		if(p>65535)
			p=65535;
		grays[i].blue =p;
	}
}
