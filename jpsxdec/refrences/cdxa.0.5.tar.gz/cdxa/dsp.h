#ifndef DSP_H
#define DSP_H

#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <linux/soundcard.h>

int opendsp(void);
int setdspbits(int fd, int bits);
int setdspchannels(int fd, int channels);
int setdsprate(int fd, int rate);
int setdspS16LE(int fd);
int dspsync(int fd);
int dspreset(int fd);
int setdspdiv(int fd, int div);
int setdspfrag(int fd, short pow2size, short num);
int getdspblksize(int fd, int *size);
int getdspobytes(int fd, int *bytes);
int writedsp(int fd, char *buf, size_t size);
int closedsp(int fd);

#endif
