#ifndef cdxa_h

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <sys/param.h> //MAXPATHLEN
#include <zlib.h>
#include <time.h>
#include "util.h"
#include "iso9660.h"
#include "xadecode.h"
#include "dsp.h"
//#include "crc32.h"
#include "jax/jax.h"
#include "xamap.h"
#include "cfg.h"

#define W 				800
#define H 				600
#define FONT	"-adobe-helvetica-bold-r-normal--11-80-100-100-p-60-iso8859-1"
#define COLOR(c)		((int)(65535*c/100))
#define BIT(var,bit)	((var&(1<<bit))?1:0)
#define WAVESHIFT		10
#define Hz				37800 //38000
#define MAX_MESSAGE		3

/******************************************************************************/

typedef enum
{
	STOP,
	PLAY,
	PAUSE,
	MAP,
	WAV,
	MP3
} PlayState;
typedef enum
{
	NONE=0,
	DOT,
	LINE,
	SOLID
} WaveMode;
typedef enum
{
	BUTTON=1,
	LABEL,
	CANVAS
} Type;
typedef enum
{
	//BUTTON
	REST=1<<0,
	ACTIVE=1<<1,
	DIRTY=1<<2,
	// LABEL
	CENTER=1<<3,
	LEFT=1<<4,
	RIGHT=1<<5,
	// GENERAL
	NOREDRAW=1<<6
} State;
typedef struct HOTSPOT
{
	int id;
	Type type;
	int x,y,w,h;
	char *label;
	State state;
	int (*buttonfunc)(Jax*,struct HOTSPOT*);
	void (*drawfunc)(Jax*,struct HOTSPOT*);
	Pixmap pixmap;	//CANVAS
	void *data;
} Hotspot;
typedef struct {
	int cdrom_name, cdrom_pub, cdrom_prep, cdrom_app;
	int xa_name, xa_frames, xa_channels;
	int frame_msf, frame_channel, frame_filenum, frame_type, frame_stereo;
	int channel_num, channel_name, channel_len, channel_files;
	int file_name, file_rate, file_len, file_offset;
	int offset, messages[MAX_MESSAGE];
} Labels;
typedef struct {
	int wave;
	int map;
} Canvases;
typedef struct WAVQUEUE {
	char wav[XAWAVBUFSIZE];
	int size;
	int pos;
	struct WAVQUEUE *next;
} WavQueue;

/******************************************************************************/

int handle_expose(Jax *jax);
int handle_button(Jax *jax);
int handle_destroy(Jax *jax, Hotspot *hs);
Hotspot *getHS(int);
int deleteHS(int);
int newHS(int x, int y, int w, int h, int state, int type, char* label,
		int (*buttonfunc)(Jax*,struct HOTSPOT*),
		void (*drawfunc)(Jax*,struct HOTSPOT*));
int doHS(Jax*, Hotspot*);
void drawHS(Jax*, Hotspot*);
int inHS(Hotspot*, int, int); //x,y
int HSeventhandler(Jax*);
void drawBox(Jax*, int,int,int,int,int,int); //x,y,w,h,light,dark
int maxStringWidth(Jax *jax,int num_strings, ...);
void redrawallHS(void);
void setdata(int id, void *data);
void setlabel(int id, char *str, int maxlen);
void setframedata(SoundSector *ss);
void printm(char *format, ...);

void createGUI(Jax *jax);

int ejectcdrom(Jax *jax,struct HOTSPOT *h);
int newcdrom(Jax *jax,struct HOTSPOT *h);
int openfile(Jax *jax,struct HOTSPOT *h);
int cancelfileselect(Jax *jax,struct HOTSPOT *h);
int setfilename(Jax *jax,struct HOTSPOT *h);
int dofilenamechange(Jax *jax,struct HOTSPOT *h);
int playpause(Jax *jax,struct HOTSPOT *h);
int stop(Jax *jax,struct HOTSPOT *h);
int channelup(Jax *jax,struct HOTSPOT *h);
int channeldown(Jax *jax,struct HOTSPOT *h);
int ratelow(Jax *jax,struct HOTSPOT *h);
int ratehigh(Jax *jax,struct HOTSPOT *h);
int nowave(Jax *jax, Hotspot *h);
int dotwave(Jax *jax, Hotspot *h);
int linewave(Jax *jax, Hotspot *h);
int solidwave(Jax *jax, Hotspot *h);
int mapfile(Jax *jax, Hotspot *h);
int mapleft(Jax *jax, Hotspot *h);
int mapright(Jax *jax, Hotspot *h);
int mapclick(Jax *jax, Hotspot *h);
int savewav(Jax *jax, Hotspot *h);

int getnewcdrom(ISO9660 *iso, char *dev, char track);
int selectfile(ISO9660 *iso, char *filename);
void simplexaplay(char *dev, char *filename, char channel, long samplerate);
void cdxaplay(char *dev);
static void dowaveform(char *wav, long size);
void setframe(unsigned long i, int doread);
void setsamplerate(long hz);
gzFile openxamap(char *mode);
void drawmapbar(int x, int cn, int type, int updatewin, int direct);
void drawmap();
int getmapx(long frame);
void drawcurrentlocation(void);
FILE *createwav(char *fname, int rate, int channels);
void closewav(FILE *f, long size);

/******************************************************************************/

#ifdef cdxa_c

Jax_Events je[]=
{
	{ExposureMask, Expose, handle_expose},
	{ButtonPressMask, ButtonPress, handle_button},
	{ButtonReleaseMask, ButtonRelease, HSeventhandler},
	{ButtonMotionMask, MotionNotify, HSeventhandler},
	{0,NoExpose,HSeventhandler},
	{0, ClientMessage, (int(*)(Jax*))handle_destroy},
	{0,0,NULL}
};
int changed;
typedef enum
{
	RED=0,
	GREEN,
	BLUE,
	YELLOW,
	CYAN,
	MAGENTA
} MapColor;
XColor colors[]=
{
	{0,COLOR(100),	0,			0,			0,0},	//red
	{1,0,			COLOR(100),	0,			0,0},	//green
	{1,0,			0,			COLOR(50),	0,0},	//blue
	{1,COLOR(100),	COLOR(100),	0,			0,0},	//yellow
	{1,0,			COLOR(50),	COLOR(50),	0,0},	//cyan
	{1,COLOR(50),	0,			COLOR(50),	0,0},	//magenta
};
Hotspot *hs=NULL;
int numhs=0, hsid=1;
Labels L;
Canvases C;
Jax *jax=NULL;
ISO9660 iso;
char wav[XAWAVBUFSIZE];
int dspfd=-1;
char *dev="/dev/cdrom";
long track=0;
char *filename=NULL;
int channel=0;
int filenum;
PlayState playstate=STOP;
long samplerate=Hz;
int ne=0, message;
WaveMode wavemode=SOLID;
long frame=-1;
unsigned long isopdcrc=0, isodrcrc=0;
char cdloaded=False;
// Map stuff
XAMap *xamap=NULL;
char mapdir[MAXPATHLEN+1];
float mapyd=1;
int mapw;
long mapoffset=0;
float mapframes=0;
int maptypes[W][32];
char framechanged=False;
char stereo=True, busy=False;
int savemp3id, outbytes, lastbytes;

#endif

#endif
