#ifndef matrix_h
#define matrix_h

typedef struct {
	int r,c;
	double **m;
} Matrix;

Matrix *matrixInit(Matrix *m);	// empty matrix m (no memory stuff)
Matrix *matrixIdentity(Matrix *m, int s); //fills m with an s*s identity matrix
Matrix *matrixNew(int r, int c);
Matrix * matrixAlloc(Matrix *m, int r, int c); // returns m
Matrix *matrixNewCopy(Matrix *n);
Matrix *matrixCopy(Matrix *m, Matrix *n); // copies n into m and returns m
Matrix *matrixCopyArray(Matrix *m, double n[], int r, int c); // returns m
void matrixFree(Matrix *m);
void matrixDelete(Matrix *m);

void matrixPrint(Matrix *m);

Matrix *matrixTranspose(Matrix *m); // returns m transposed
Matrix *matrixInverse(Matrix *m);   // returns m inversed
Matrix *matrixMultiply(Matrix *m, Matrix *n); // m*n into m returns m
double matrixDeterminant(Matrix *m); // returns det(m)
Matrix *matrixDiv1(Matrix *m, double d); // returns m/d in m
//double matrixDeterminant3x3(Matrix *m); // returns det(m) when m is 3x3
Matrix *matrixPseudoInverse(Matrix *m); // A^+ = inverse(T(m)*m)*T(m) = m(returned)

#endif
