#ifndef XAMAP_H
#define XAMAP_H

#include <stdio.h>
#include <zlib.h>

typedef struct
{
	char name[64];				//user assigned name
	long samplerate;			//in Hz
	long offset;				//frame offset of the beginning of file
	long end;					//frame offset of the end of file
	long frames;				//length in frames
} XAFileInfo;

typedef struct
{
	char name[64];				//user assigned name
	long frames;				//channel length in frames
	int files;					//max file number in file
	XAFileInfo file[256];		//file info
} XAChannelInfo;

typedef struct
{
	unsigned char channel;		//channel for this frame
	unsigned char file;			//file number for this frame
	unsigned char type;			//XA frame type
} XAChannelMap;

typedef struct
{
	unsigned long isopdcrc;		//generated CRC32 from isopd of cdrom (match)
	unsigned long isodrcrc;		//generated CRC32 from isodr of file (match)
	unsigned long frames;		//length of file in frames (match)
	int channels;				//max channel found in file
	XAChannelInfo channel[32];	//channel(&sub-file) info
	long maplen;				//last frame mapped (size of map)
	XAChannelMap *map;			//array of frame info (maplen=length)
} XAMap;

#define XAMapSize (sizeof(XAMap)-sizeof(XAChannelMap*))

XAMap *newmap(unsigned long isopdcrc, unsigned long isodrcrc, unsigned long frames, long default_samplerate);
XAMap *readmap(gzFile);
int writemap(gzFile, XAMap*);
void freemap(XAMap*);

#endif
