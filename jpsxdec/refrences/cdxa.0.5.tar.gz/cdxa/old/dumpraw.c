#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <fcntl.h>
#include <stdarg.h>
#include <errno.h>
#include <linux/cdrom.h>
#include <linux/iso_fs.h>

//#define DEBUG

int dohex=0,dodebug=0;

int Printf(char *fmt,...)
{
	if(dodebug)
	{
		va_list ap;

		va_start(ap,fmt);
		vfprintf(stderr,fmt,ap);
		va_end(ap);
	}
    return(0);
}

void Exit(char *str)
{
	if(errno)
		perror(str);
    exit(1);
}

void dumpch(char *data, int len)
{
    int i;

    for(i=0;i<len;i++)
        if(isprint(data[i]))
            printf("%c",data[i]);
		/*
        else if(data[i]<' ')
            printf("\033[1m%c\033[m",data[i]+'@');
		*/
		else
            printf("\033[1m.\033[m");
}

void hexdump(char *data, int len, int offset)
{
    int i,j;

    for(i=0;i<len;i++)
    {
        if(!(i%16))
            printf("%8.8x: ",i+offset);
        printf("%2.2x",data[i]&0xff);
        if(!((i+1)%4))
            printf(" ");
        if(((i+1)%16)==0 || (i+1)==len)
        {
            j=i>>4<<4;
            dumpch(&data[j],i-j+1);
        }
        if(!((i+1)%16))
            printf("\n");
    }
}

void frame2msf(unsigned long i, struct cdrom_msf *msf)
{
    msf->cdmsf_min0  =   i   /(CD_FRAMES *CD_SECS);
    msf->cdmsf_sec0  =  (i   / CD_FRAMES)%CD_SECS;
    msf->cdmsf_frame0=   i   % CD_FRAMES;
    msf->cdmsf_min1  =  (i+1)/(CD_FRAMES *CD_SECS);
    msf->cdmsf_sec1  = ((i+1)/ CD_FRAMES)%CD_SECS;
    msf->cdmsf_frame1=  (i+1)% CD_FRAMES;
}

int main(int argc, char **argv)
{
	int fd, notdone, t=3, i;
	unsigned long offset=0, start=0, end=0, lastgood=0;
	char devname[MAXPATHLEN]="/dev/cdrom", c, fname[MAXPATHLEN]="cdrom.raw";
	struct cdrom_tochdr toc;
    struct cdrom_tocentry toce;
	unsigned char data[CD_FRAMESIZE_RAW],*p;
	struct cdrom_msf *msf;
	FILE *f;

	while((c=getopt(argc,argv,"xhd:f:v"))!=EOF)
	{
		switch(c)
		{
			case 'x':
				dohex=1;
				break;
			case 'd':
				strncpy(devname,optarg,MAXPATHLEN);
				break;
			case 'f':
				strncpy(fname,optarg,MAXPATHLEN);
				break;
			case 'v':
				dodebug=1;
				break;
			case 'h':
			case '?':
			case ':':
			default:
				fprintf(stderr,"%s [-hxv] [-d device] [-f filename]\n",argv[0]);
				Exit("getopt");
				break;
		}
	}

	fd=open(devname,O_RDONLY);
	if(fd == -1)
		Exit(devname);
	Printf("Opened: %s\n\n",devname);
	
	if(strcmp(fname,"-"))
		f=fopen(fname,"wb");
	else
		f=stdout;
	Printf("Opened: %s\n\n",fname);

	// get cdrom TOC Head
	Printf("TOCHDR\n");
	if(ioctl(fd,CDROMREADTOCHDR,&toc)==-1)
		Exit("CDROMREADTOCHDR");
	Printf("First Track: %u\n",toc.cdth_trk0);
	Printf("Last  Track: %u\n",toc.cdth_trk1);
	Printf("\n");

	// get cdrom TOC Entries
	Printf("TOCENTRY\n");
	memset(&toce,0,sizeof(toce));
	toce.cdte_format=CDROM_LBA;
	for(i=toc.cdth_trk0; i<=toc.cdth_trk1+1; i++)
	{
		char *formatstr[]={
			"Unknown",
			"LBA",
			"MSF"
		};

		if(i<=toc.cdth_trk1)
			toce.cdte_track=i;
		else
			toce.cdte_track=CDROM_LEADOUT;
		if(ioctl(fd,CDROMREADTOCENTRY,&toce)==-1)
			Exit("CDROMREADTOCENTRY");
		Printf("Track    : %u\n",toce.cdte_track);
		Printf("Address  : %u\n",toce.cdte_adr);
		Printf("Control  : %u\n",toce.cdte_ctrl);
		Printf("Format   : %d = %s\n",toce.cdte_format, formatstr[toce.cdte_format]);
		switch(toce.cdte_format)
		{
			/*
			case CDROM_MSF:
				Printf("MSF      : %lu  ",msf2frame(&toce.cdte_addr.msf));
				if(i==toc.cdth_trk0)
				{
					trackoffset=msf2frame(&toce.cdte_addr.msf);
					Printf("\nfirst frame of first track: %ld\n",trackoffset+16);
				}
				printmsf(&toce.cdte_addr.msf);
				Printf("\n");
				break;
				*/
			case CDROM_LBA:
				Printf("LBA      : 0x%.8x\n",toce.cdte_addr.lba);
				if(toce.cdte_addr.lba>end)
					end=toce.cdte_addr.lba;
				break;
		}
		Printf("DataMode : %u\n",toce.cdte_datamode);
	}
	Printf("start=%lu end=%lu\n",start,end);

	notdone=1;
	offset=start;
	p=data+CD_SYNC_SIZE+CD_HEAD_SIZE;
	while(offset<end && notdone)
	{
		msf=(void*)data;
		frame2msf(offset,msf);
		//memcpy(data,&offset,sizeof(offset));
		if(ioctl(fd,CDROMREADRAW,data,data)!=-1)
		{
			Printf("    ");
			lastgood=offset;
			if(t!=3)
				Printf("\n   ");
			t=3;
		}
		else
		{
			msf=(void*)p;
			Printf("|");
			memset(p,0,CD_FRAMESIZE_RAW);
			frame2msf(offset,msf);
			//memcpy(data,&offset,sizeof(offset));
			if(ioctl(fd,CDROMREADMODE2,p,p)!=-1)
			{
				Printf("   ");
				lastgood=offset;
				if(t!=2)
					Printf("\n|   ");
				t=2;
			}
			else
			{
				Printf("|");
				memset(data,0,CD_FRAMESIZE_RAW);
				frame2msf(offset,msf);
				//memcpy(p,&offset,sizeof(offset));
				if(ioctl(fd,CDROMREADMODE1,p,p)!=-1)
				{
					Printf("  ");
					lastgood=offset;
					if(t!=1)
						Printf("\n||  ");
					t=1;
				}
				else
				{
					Printf("|");
					if(lseek(fd,offset*CD_FRAMESIZE,SEEK_SET)!=-1 
						&& read(fd,p,CD_FRAMESIZE)!=-1)
					{
						Printf(" ");
						lastgood=offset;
						if(t!=0)
							Printf("\n||| ");
						t=0;
					}
					else
					{
						static struct cdrom_read_audio cra;

						Printf("|");
						memset(data,0,CD_FRAMESIZE_RAW);
						cra.addr.lba=offset;
						cra.addr_format=CDROM_LBA;
						cra.nframes=1;
						cra.buf=data;
						frame2msf(offset,msf);
						//memcpy(p,&offset,sizeof(offset));
						if(ioctl(fd,CDROMREADAUDIO,&cra)!=-1)
						{
							lastgood=offset;
							if(t!=4)
								Printf("\n||||");
							t=4;
						}
						else
						{
							if(t!=0xf)
								Printf("\nXXXX");
							t=0xf;
						}
					}
				}
			}
		}
		if(dohex)
			hexdump(data,CD_FRAMESIZE_RAW,offset*CD_FRAMESIZE_RAW);
		else
		{
			fwrite(data,CD_FRAMESIZE_RAW,1,f);
			Printf("%8d %1.1x %8d : %10lu bytes\033[K\r",lastgood,t,offset,(offset+1)*CD_FRAMESIZE_RAW);
		}
		offset++;
	}

	Printf("\n");
	fflush(f);
	if(strcmp(fname,"-"))
		fclose(f);
	close(fd);
	return(0);
}
