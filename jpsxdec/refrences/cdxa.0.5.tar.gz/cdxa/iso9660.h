#ifndef ISO9660_H
#define ISO9660_H
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/cdrom.h>
#include <linux/iso_fs.h>

							 /* Data Definitions */

typedef struct ISODR
{
	struct ISODR *next;
	char isxa;
	char *path;
	struct iso_directory_record isodr;
} ISODR;
#define ISODR_EXTRA (sizeof(struct ISODR)+sizeof(char*)+1)

enum {
	ISODR_FLAG_ISFILE=0,
	ISODR_FLAG_ISDIR=2
};

typedef struct
{
	struct ISODR *ISODR;
	struct ISODR *isodrtail;
	struct ISODR *isodr;
	struct cdrom_tochdr toc;
	struct cdrom_tocentry toce;
	struct cdrom_mcn mcn;
	struct cdrom_multisession ms;
	struct cdrom_msf msf;
	struct iso_directory_record *isodrptr;
	struct iso_primary_descriptor *isopd;
	unsigned long trackoffset, start, end;
	int session;
	int fd;
	u_char data[CD_FRAMESIZE_RAW], isopddata[CD_FRAMESIZE_RAW];
} ISO9660;

extern char *formatstr[];

								/* Prototypes */

// Utils
char *cdstatus(int status);
unsigned long msf2frame(struct cdrom_msf0 *msf);
void frame2msf(unsigned long i, struct cdrom_msf *msf);
void isofixname(char *name);

// ISODR Ops
struct ISODR *isoreaddirblock(int fd, int i, char *path);
struct ISODR *findisofname(struct ISODR *ISODR, char *fname);

// ISO9660 Ops
int openISO9660(ISO9660 *iso, char *dev);
int closeISO9660(ISO9660 *iso);
int gettocISO9660(ISO9660 *iso, char track);
int multisessionISO9660(ISO9660 *iso);
int getisopdISO9660(ISO9660 *iso);
int getisodirISO9660(ISO9660 *iso);
int findfileISO9660(ISO9660 *iso, char *name);
void calcboundsISO9660(ISO9660 *iso);
int ripISO9660RawFrame(ISO9660 *iso, unsigned long offset);

// CDROM Ops
int resetCDROM(int fd);
int ejectCDROM(int fd);
int drivestatusCDROM(int fd);
int discstatusCDROM(int fd);
int getmcnCDROM(ISO9660 *iso);

// Prints
void printmsf(struct cdrom_msf0 *msf);
void printmsf2(struct cdrom_msf *msf);
void printisodr(struct iso_directory_record *isodr);
void printtoce(struct cdrom_tocentry *toce);
void printtochdr(struct cdrom_tochdr *toc);
void printisopd(struct iso_primary_descriptor *isopd);

#endif
