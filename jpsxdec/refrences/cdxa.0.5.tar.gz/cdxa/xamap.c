#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "xamap.h"

XAMap *readmap(gzFile f)
{
	XAMap *xamap;
	int err;

	xamap=(XAMap*)malloc(sizeof(XAMap));
	if(gzread(f,xamap,XAMapSize)!=XAMapSize)
	{
		fprintf(stderr, "gzread error: %s\n", gzerror(f, &err));
		free(xamap);
		xamap=NULL;
	}
	else
	{
		xamap->map=(XAChannelMap*)malloc(sizeof(XAChannelMap)*xamap->frames);
		if(gzread(f,xamap->map,sizeof(XAChannelMap)*xamap->maplen)!=sizeof(XAChannelMap)*xamap->maplen)
		{
			fprintf(stderr, "gzread error: %s\n", gzerror(f, &err));
			free(xamap->map);
			free(xamap);
			xamap=NULL;
		}
	}
	return(xamap);
}

int writemap(gzFile f, XAMap *xamap)
{
	int ct=0,err;

	if(!f)
		return(0);
	if(gzwrite(f,xamap,XAMapSize)!=XAMapSize)
		fprintf(stderr, "gzwrite error: %s\n", gzerror(f, &err));
	else
	{
		if((ct=gzwrite(f,xamap->map,sizeof(XAChannelMap)*xamap->maplen))!=
				sizeof(XAChannelMap)*xamap->maplen)
		{
			fprintf(stderr, "gzwrite error: %s\n", gzerror(f, &err));
			ct=0;
		}
	}
	return(ct);
}

void freemap(XAMap *xamap)
{
	if(xamap && xamap->map)
		free(xamap->map);
	if(xamap)
		free(xamap);
}

XAMap *newmap(unsigned long isopdcrc, unsigned long isodrcrc, unsigned long frames, long default_samplerate)
{
	XAMap *xamap;
	int c,f;

	xamap=(XAMap*)malloc(sizeof(XAMap));
	xamap->map=(XAChannelMap*)malloc(sizeof(XAChannelMap)*frames);
	memset(xamap->map,0,sizeof(XAChannelMap)*frames);
	xamap->maplen=0;
	xamap->isopdcrc=isopdcrc;
	xamap->isodrcrc=isodrcrc;
	xamap->frames=frames;
	xamap->channels=0;
	for(c=0;c<32;c++)
	{
		xamap->channel[c].name[0]=0;
		xamap->channel[c].frames=0;
		xamap->channel[c].files=0;
		for(f=0;f<256;f++)
		{
			xamap->channel[c].file[f].name[0]=0;
			xamap->channel[c].file[f].samplerate=default_samplerate;
			xamap->channel[c].file[f].offset=0;
			xamap->channel[c].file[f].frames=0;
			xamap->channel[c].file[f].end=0;
		}
	}
	return(xamap);
}
