#include <stdio.h>
#include "matrix.h"

int main(int argc, char **argv)
{
	double m2[]={
		1,3,
		0,2,
	};
	double m3[]={
		1,0,0,
		2,1,3,
		0,0,2,
	};
	double m5x3[]={
		1,-1,1,
		1,1,1,
		1,2,4,
		1,3,9,
		1,5,25,
	};
	double y[]={
		0,
		2,
		3,
		2,
		3,
		5,
	};
	double md[]={
		1,0,0,0,//0,0,
		1,1,1,1,//1,1,
		1,2,4,8,//16,32,
		1,3,9,12,//36,108,
		//1,4,16,64,512,2048,
		//1,5,25,125,625,3125,
	};
	Matrix m,n;

	matrixInit(&m);
	matrixInit(&n);
/*
	matrixCopyArray(&m,m2,2,2);
	matrixPrint(&m);
	printf("det=%f\n",matrixDeterminant(&m));

	matrixCopyArray(&m,m3,3,3);
	matrixPrint(&m);
	printf("det=%f\n",matrixDeterminant(&m));

	matrixCopyArray(&m,m3,3,3);
	matrixPrint(&m);
	matrixPrint(matrixInverse(&m));

	matrixCopyArray(&n,m3,3,3);
	matrixPrint(&n);
	matrixPrint(matrixTranspose(&n));

	matrixCopyArray(&n,m3,3,3);
	matrixPrint(&n);
	matrixPrint(&m);
	matrixPrint(matrixMultiply(&m,&n));

	//matrixPrint(matrixIdentity(&n,6));
*/
/*
	matrixCopyArray(&m,m5x3,5,3);
	matrixCopyArray(&n,m5x3,5,3);

	printf("A = ");
	matrixPrint(&n);

	printf("T(A) = ");
	matrixTranspose(&m);
	matrixPrint(&m);

	printf("T(A)*A = ");
	matrixMultiply(&m,&n);
	matrixPrint(&m);

	printf("(T(A)*A)^-1 = ");
	matrixInverse(&m);
	matrixPrint(&m);

	matrixTranspose(&n);

	printf("A^+ = ((T(A)*A)^-1)*T(A) = ");
	matrixMultiply(&m,&n);
	matrixPrint(&m);

	matrixCopyArray(&n,y,5,1);
	printf("y = ");
	matrixPrint(&n);

	printf("(A^+)y = ");
	matrixMultiply(&m,&n);
	matrixPrint(&m);
*/
/*
	matrixCopyArray(&m,m5x3,5,3);
	printf("A = ");
	matrixPrint(&m);

	printf("A^+ = ");
	matrixPseudoInverse(&m);
	matrixPrint(&m);
	
	matrixCopyArray(&n,y,5,1);
	printf("y = ");
	matrixPrint(&n);

	printf("(A^+)y = ");
	matrixMultiply(&m,&n);
	matrixPrint(&m);
*/
	matrixCopyArray(&m,md,4,4);
	printf("A = ");
	matrixPrint(&m);

	printf("A^+ = ");
	matrixPseudoInverse(&m);
	matrixPrint(&m);
	
	matrixCopyArray(&n,y,4,1);
	printf("y = ");
	matrixPrint(&n);

	printf("(A^+)y = ");
	matrixMultiply(&m,&n);
	matrixPrint(&m);

	return(0);
}
