/*  XMMS - Cross-platform multimedia player
 *  Copyright (C) 1998-1999  Peter Alm, Mikael Alm, Olle Hallnas, Thomas Nilsson
 *                           and 4Front Technologies
 *
 *  CDXA Audio Player - XMMS Input Plugin
 *	Copyright (C) 2000 Jonathan Atkins
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/cdrom.h>
#include <linux/iso_fs.h>
#include <gtk/gtk.h>

#include <xmms/util.h>

#include "cdxaaudio.h"
#include "crc32.h"
#include "xadecode.h"

//#define DEBUG
//#define DEBUG_TOC

#ifndef DEBUG
//#define SHOW_BUFFER
#endif

#define CDROMDEVICE "/dev/hdd"
#define CDROMDIR "/cdrom"
//#define CDROMDEVICE "/dev/sr0"
//#define CDROMDIR "/cdram"

#define FILEEXT ".cdxaa"

#ifndef MAXPATHLEN
#define MAXPATHLEN 4096
#endif

#ifndef ISODR_FLAG_ISDIR
#define ISODR_FLAG_ISDIR 2
#endif

#ifndef ISODR_FLAG_ISFILE
#define ISODR_FLAG_ISFILE 0
#endif

#undef SLASH
#define SLASH '\\'

#ifdef DEBUG
#define Printf printf
#else
#define Printf
#endif

#ifdef DEBUG
#define Debug(a) a
#else
#define Debug(a)
#endif

/* Structs */
typedef struct {
	char *name;
	unsigned long start, len;
} CDXAA_TOC_Entry;

typedef struct {
	int len;
	unsigned long crc;
	CDXAA_TOC_Entry *toce;
} CDXAA_TOC;

typedef struct {
	char path[MAXPATHLEN];
	unsigned long offset;
} CDXAA_Dir;

/* Prototypes */
static GList *cdxaa_scan_dir(char *dir);
static gboolean cdxaa_get_toc(char *dir, CDXAA_TOC *toc);
static void hexdump(unsigned char *data, int len);
static char *fixfilename(char *filename);
static int readraw(int fd, unsigned char *buf,int frame);
static void free_cdxaa_toc(CDXAA_TOC *toc);
static gboolean get_cdxaa_toce(char *filename, CDXAA_TOC_Entry *toce);

/* Variables */
InputPlugin cdxaaudio_ip =
{
	NULL,
	NULL,
	"CDXA Audio Player " VERSION,
	cdxaaudio_init,
	about,
	config, /* configure */
	is_our_file,
	cdxaa_scan_dir,
	play_file,
	stop,
	cdxaaudio_pause,
	seek,
	NULL, /* set_eq */
	get_time,
	NULL, /* get_volume */
	NULL, /* set_volume */
	NULL, /* add_vis (Obsolete) */
	NULL, /* get_vis_type (Obsolete) */
	NULL, /* add_vis_pcm */
	NULL, /* set_info */
	NULL, /* set_info_text */
	get_song_info,
	NULL, /* file_info_box */
	NULL
};
CDXAState state;
static pthread_t play_thread, read_thread;
static gboolean audio_error = FALSE;
static int num_blocks=1024, pre_blocks=4;
static char slash[2]={SLASH,'\0'};

/******************************************************************************/

InputPlugin *get_iplugin_info(void)
{
	Printf("get_iplugin_info()\n");
	return &cdxaaudio_ip;
}

/******************************************************************************/

static void cdxaaudio_init(void)
{
	Printf("cdxaaudio_init()\n");
#ifdef SHOW_BUFFER
	printf("sizeof(XABlock)=%d bufsize=%d\n",sizeof(XABlock),sizeof(XABlock)*num_blocks);
#endif
	memset(&state,0,sizeof(CDXAState));
	state.stopped=TRUE;
	state.dev=g_strdup(CDROMDEVICE);
	state.dir=g_strdup(CDROMDIR);
	Printf("Init complete:\n\tdev=%s\n\tdir=%s\n",state.dev,state.dir);
}

/******************************************************************************/

static void about()
{
	static GtkWidget *w=NULL;
	GtkWidget *vbox, *label, *ok, *aa;

	if(!w)
	{
		w=gtk_dialog_new();
		gtk_object_set_data(GTK_OBJECT(w), "cdxaaudio_about", w);
		gtk_window_set_title(GTK_WINDOW(w), "About CDXA-Audio plugin");
		gtk_window_set_policy(GTK_WINDOW(w), FALSE, FALSE, FALSE);
		gtk_window_set_position(GTK_WINDOW(w), GTK_WIN_POS_MOUSE);
		gtk_signal_connect(GTK_OBJECT(w), "destroy", GTK_SIGNAL_FUNC(gtk_widget_destroyed), &w);
		gtk_container_border_width(GTK_CONTAINER(w), 5);

		vbox=GTK_DIALOG(w)->vbox;
		gtk_object_set_data(GTK_OBJECT(w), "vbox", vbox);
		gtk_widget_show(vbox);
		gtk_container_border_width(GTK_CONTAINER(vbox), 5);
		
		label=gtk_label_new("CDXA Audio Plugin\nhttp://jonatkins.org/cdxa/\nby Jonathan Atkins\n");
        gtk_object_set_data(GTK_OBJECT(w), "label", label);
        gtk_widget_show(label);
        gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);

		aa = GTK_DIALOG(w)->action_area;
		gtk_object_set_data(GTK_OBJECT(w), "action_area", aa);
		gtk_widget_show(aa);
		gtk_container_border_width(GTK_CONTAINER(aa), 5);

		ok = gtk_button_new_with_label("Ok");
        gtk_signal_connect_object(GTK_OBJECT(ok), "clicked",
                      GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(w));

        gtk_object_set_data(GTK_OBJECT(w), "about_exit", ok);
        gtk_widget_show(ok);
        gtk_box_pack_start(GTK_BOX(aa), ok, TRUE, TRUE, 0);

        gtk_widget_show(w);
	}
	else
	{
		gdk_window_raise(w->window);
	}
}

/******************************************************************************/

static void config_ok(GtkWidget * widget, gpointer data)
{
	gtk_widget_destroy(GTK_WIDGET(data));
}

/******************************************************************************/

static void config()
{
	static GtkWidget *w=NULL;
	GtkWidget *vbox, *label, *ok, *cancel, *nb, *bbox;
	
	if(!w)
	{
		w=gtk_window_new(GTK_WINDOW_DIALOG);
		gtk_object_set_data(GTK_OBJECT(w), "cdxaaudio_configure", w);
		gtk_window_set_title(GTK_WINDOW(w), "CDXA Audio Configuration");
		gtk_window_set_policy(GTK_WINDOW(w), FALSE, FALSE, FALSE);
		gtk_window_set_position(GTK_WINDOW(w), GTK_WIN_POS_MOUSE);
		gtk_signal_connect(GTK_OBJECT(w), "destroy", GTK_SIGNAL_FUNC(gtk_widget_destroyed), &w);
		gtk_container_border_width(GTK_CONTAINER(w), 5);

		vbox = gtk_vbox_new(FALSE, 10);
        gtk_container_add(GTK_CONTAINER(w), vbox);
		gtk_object_set_data(GTK_OBJECT(w), "vbox", vbox);
		gtk_widget_show(vbox);
		gtk_container_border_width(GTK_CONTAINER(vbox), 5);

		nb=gtk_notebook_new();
		gtk_object_set_data(GTK_OBJECT(w), "notebook", nb);
		gtk_widget_show(nb);
		gtk_box_pack_start(GTK_BOX(vbox), nb, TRUE, TRUE, 0);
		gtk_container_border_width(GTK_CONTAINER(nb), 3);
		

		bbox = gtk_hbutton_box_new();
        gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox), GTK_BUTTONBOX_END);
        gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox), 5);
        gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 0);

        ok = gtk_button_new_with_label("Ok");
        gtk_signal_connect(GTK_OBJECT(ok), "clicked", GTK_SIGNAL_FUNC(config_ok), GTK_OBJECT(w));
        GTK_WIDGET_SET_FLAGS(ok, GTK_CAN_DEFAULT);
        gtk_box_pack_start(GTK_BOX(bbox), ok, TRUE, TRUE, 0);
        gtk_widget_show(ok);
        gtk_widget_grab_default(ok);

        cancel = gtk_button_new_with_label("Cancel");
        gtk_signal_connect_object(GTK_OBJECT(cancel), "clicked", GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(w));
        GTK_WIDGET_SET_FLAGS(cancel, GTK_CAN_DEFAULT);
        gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 0);
        gtk_widget_show(cancel);

        gtk_widget_show(bbox);

		gtk_widget_show(w);
	}
	else
	{
		gdk_window_raise(w->window);
	}
}

/******************************************************************************/

static int is_our_file(char *filename)
{
	gchar *ext;
	int iscdxa=FALSE;

	Printf("is_our_file(\"%s\")\n",filename);
	ext = strrchr(filename, '.');
	if (ext && !strcasecmp(ext,FILEEXT))
		iscdxa=TRUE;
	Printf("	return(%d)\n",iscdxa);
	return(iscdxa);
}

/******************************************************************************/

static int channelct()
{
	int i,ct;

	ct=0;
	for(i=0;i<32;i++)
		if(state.channel_seen[i])
			ct++;
	return(ct?ct:1);
}

/******************************************************************************/

static int frameof(int time)
{
	return(time*XAHz/(8064/2));
}

/******************************************************************************/

static int timeof(int frames)
{
	//return(frames*1000);
	return(frames*(8064/2)/XAHz*1000);
}

/******************************************************************************/
// export state to frontend

static void setstateinfo(char *str)
{
	char name[1024];

	sprintf(name,"%s ch%d/%d",state.title,state.channel+1,state.maxchannel+1);
	cdxaaudio_ip.set_info(
			(str?str:(state.channel<=state.maxchannel?name:state.title)),
			//state.length,
			//60000*(state.maxchannel+1), 
			timeof(state.length),
			//((unsigned long)state.length*channelct()*8064)/XAHz,
			state.bits*state.freq*(state.stereo?2:1),
			state.freq,
			(state.stereo?2:1));
}

/******************************************************************************/

#define BufFree (state.tail<=state.head\
				 ?state.tail+state.bufsize-state.head\
				 :state.tail-state.head)

#define BufUsed (state.bufsize-BufFree)

static void *xaread(void *args)
{
	SoundSector *ss;
	XABlock *xab;
	unsigned char buf[CD_FRAMESIZE_RAW],*wav;
	int channel;
	Debug(int ct;)

	Printf("xaread()\n");
	state.offset=0;
	state.channel=0;
	state.maxchannel=0;
	ss=(SoundSector*)buf;
	initXaDecode();
	while(state.channel<=state.maxchannel && state.reading && state.playing)
	{
		//Printf("\txaread offset=%d/%d\n",state.offset,state.length);
		Debug(ct=0;)
		while(state.seek_to!=-1 && state.reading && state.playing)
		{
			xmms_usleep(30000);
			Debug(ct++;)
		}
		Debug(if(ct)
			Printf("xaread waited %d cycles for seek to finish\n",ct);)
		//Printf("\t\tbuf tail=%d head=%d free=%d/%d readraw\n",state.tail,state.head,BufFree,state.bufsize);
#ifdef SHOW_BUFFER
		printf("tail=% 4d head=% 4d free=% 4d/% -4d offset=% 8lu/%lu\033[K\r",state.tail,state.head,BufFree,state.bufsize,state.offset,state.length);
#endif
		if(readraw(state.fd,buf,state.offset+state.start)==-1)
			state.offset=state.length;
		else
		{
			channel=xachannel(ss);
			if(!state.channel_seen[channel])
			{
				if(channel>state.maxchannel)
					state.maxchannel=channel;
				state.channel_seen[channel]=TRUE;
				if(state.channel<channel && !state.channel_seen[state.channel])
					state.channel=channel;
				setstateinfo(NULL);
			}
			//Printf("buf tail=%d head=%d free=%d/%d decode channel=%d?=%d offset=%d\033[K\r",state.tail,state.head,BufFree,state.bufsize,channel,state.channel,state.offset);
			xab=&state.buf[state.head];
			wav=xab->buf;
			if((xab->len=convXaToWave(buf,wav,state.channel,0,255))>0)
			{
				Debug(ct=0;)
				while(BufFree<2 && state.reading && state.playing && state.seek_to==-1)
				{
					xmms_usleep(30000);
					Debug(ct++;)
				}
				Debug(if(ct)
					Printf("xaread waited %d cycles for buffer space to be free\n",ct);)
				if(!state.reading || !state.playing)
					break;
				if(state.seek_to==-1)
				{
				//Printf("\txaread decoded offset=%d len=%d\n",state.offset,xab->len);
					xab->channel=channel;
					xab->filenum=xafileno(ss);
					xab->stereo=xastereo(ss);
					xab->freq=(xahalfhz(ss)?XAHz/2:XAHz);
					xab->offset=state.offset;
					state.head=(state.head+1)%state.bufsize;
				}
			}
			if(state.seek_to==-1)
				state.offset++;
		}
		// increment offset or rewind and increase channel number
		if(state.offset>=state.length)
		{
			Printf("\txaread next channel\n");
			state.offset=0;
			state.channel++;
			setstateinfo(NULL);
		}
	}
	state.reading=FALSE;
	Printf("xaread exit\n");
	Debug(ct=0;)
	while(state.playing)
	{
		xmms_usleep(10000);
		Debug(ct++;)
	}
	Debug(if(ct)
		Printf("xaread waited %d cycles for play to finish\n",ct);)
	pthread_exit(NULL);
}

/******************************************************************************/

void prebuffer()
{
	Debug(int ct;)
	
	Debug(ct=0;)
		while(BufUsed<state.prebuf && state.playing && state.reading && state.seek_to==-1)
		{
			char str[1024];
			xmms_usleep(10000);
			sprintf(str,"prebuffer %d/%d %s",BufUsed,state.prebuf,state.title);
			setstateinfo(str);
			Debug(ct++;)
		}
	Debug(if(ct)
			Printf("prebuffer waited %d cycles for read to start\n",ct);)
	setstateinfo(NULL);
}

/******************************************************************************/

static void *xaplay(void *args)
{
	XABlock *xab;
	int channel=0;
	Debug(int ct;)

	Printf("xaplay()\n");
	cdxaaudio_ip.output->open_audio(FMT_S16_LE,state.freq,(state.stereo?2:1));
	prebuffer();
	while(state.playing && (state.reading||BufUsed))
	{
		Debug(ct=0;)
		while(!BufUsed && state.playing && state.reading && state.seek_to==-1)
		{
			xmms_usleep(30000);
			Debug(ct++;)
		}
		Debug(if(ct)
			Printf("xaplay waited %d cycles for read to happen\n",ct);)
		if(!state.playing || (!BufUsed && !state.reading))
			break;
		//Printf("\t\tbuf tail=%d head=%d free=%d/%d write_audio\n",state.tail,state.head,BufFree,state.bufsize);
		xab=&state.buf[state.tail];
		Debug(ct=0;)
		while(cdxaaudio_ip.output->buffer_free()<xab->len && state.playing)
		{
			xmms_usleep(30000);
			Debug(ct++;)
		}
		Debug(if(ct)
			Printf("xaplay waited %d cycles for free output buffer\n",ct);)
		if(!state.playing)
			break;
		state.play_offset=xab->offset;
		if(channel!=xab->channel)
		{
			cdxaaudio_ip.output->flush(0);
			channel=xab->channel;
		}
		cdxaaudio_ip.add_vis_pcm(cdxaaudio_ip.output->written_time(),FMT_S16_LE,(xab->stereo?2:1),xab->len,xab->buf);
		cdxaaudio_ip.output->write_audio(xab->buf,xab->len);
		// is xa block in stereo
		if(state.stereo!=xab->stereo)
		{
			state.stereo=xab->stereo;
			setstateinfo(NULL);
		}
		state.tail=(state.tail+1)%state.bufsize;
		// handle seek if requested
		if(state.seek_to != -1)
		{
			state.offset=state.seek_to;
			//cdxaaudio_ip.output->flush(state.offset*1000);
			cdxaaudio_ip.output->flush(timeof(state.offset));
			//cdxaaudio_ip.output->flush(cdxaaudio_ip.output->output_time());
			state.head=state.tail=0;
			state.seek_to = -1;
			prebuffer();
		}
	}
	state.playing=FALSE;
	Printf("xaplay exit\n");
	pthread_exit(NULL);
}

/******************************************************************************/

static void play_file(char *filename)
{
	CDXAA_TOC_Entry toce;
	char *p;
	int ct;
	
	Printf("play_file(\"%s\")\n",filename);
	while(!state.stopped)
		xmms_usleep(100000);
	state.offset=0;
	state.seek_to=-1;
	state.filenum=0;
	state.channel=0;
	state.tail=state.head=0;
	state.start=state.length=0;
	memset(state.channel_seen,0,32*sizeof(gboolean));
	if((state.fd=open(state.dev,O_RDONLY))==-1)
		{ stop(); return; }

	//get_song_info(filename,&state.title,&state.length);
	filename=fixfilename(filename);
	if(state.title)
		free(state.title);
	state.title=g_strdup(filename+strspn(filename,slash));
	state.length=0;
	if(get_cdxaa_toce(filename,&toce))
	{
		state.length=toce.len;
		state.start=toce.start;
	}
	else
		{ stop(); return; }
	if(SLASH!='/')
		while((p=strchr(state.title,SLASH)))
			*p='/';
	Printf("\ttitle=\"%s\"\tlength=%lu start=%lu\n",state.title,state.length,state.start);

	// init state
	state.bits=16;
	state.freq=XAHz;
	state.stereo=TRUE;
	state.bufsize=num_blocks;
	state.prebuf=pre_blocks;
	if(state.buf)
		free(state.buf);
	state.buf=malloc(state.bufsize*sizeof(XABlock));
	setstateinfo(NULL);

	state.reading=TRUE;
	state.playing=TRUE;
	state.stopped=FALSE;
	pthread_create(&read_thread,NULL,xaread,NULL);
	pthread_create(&play_thread,NULL,xaplay,NULL);
}

/******************************************************************************/

static void stop(void)
{
	Printf("stop()\n");

	if(state.stopped)
		return;

	if(state.playing)
	{
		state.playing=FALSE;
		pthread_join(play_thread,NULL);
	}

	cdxaaudio_ip.output->close_audio();

	if(state.reading)
	{
		state.reading=FALSE;
		pthread_join(read_thread,NULL);
	}

	if(state.buf)
		free(state.buf);
	state.buf=NULL;

	if(state.fd!=-1)
		close(state.fd);
	state.fd=-1;

	state.stopped=TRUE;
}

/******************************************************************************/

static void cdxaaudio_pause(short p)
{
	Printf("cdxaaudio_pause(%hd)\n",p);
	cdxaaudio_ip.output->pause(p);
}

/******************************************************************************/

static void seek(int time)
{

	Printf("seek(%d)\n",time);
	state.seek_to=frameof(time);
	Printf("seek_to=%d\n",state.seek_to);
}

/******************************************************************************/

static int get_time(void)
{
	int t=-1;
	//Printf("get_time()\n");
	if(state.playing)
		t=cdxaaudio_ip.output->output_time();
		//t=((int)(state.channel+(state.play_offset/(float)state.length)*60000));
		//t=timeof(state.play_offset);
	//Printf("gettime	t=%d:%02d\n",t/60000,(t%60000)/1000);
	return(t);
}

/******************************************************************************/

static gboolean get_cdxaa_toce(char *filename, CDXAA_TOC_Entry *toce)
{
	CDXAA_TOC toc;
	int i;
	
	if(cdxaa_get_toc(state.dir,&toc))
	{
		for(i=0;i<toc.len;i++)
			if(!strcmp(toc.toce[i].name,filename))
			{
				if(toce)
				{
					toce->name=toc.toce[i].name;
					toce->start=toc.toce[i].start;
					toce->len=toc.toce[i].len;
				}
				return(TRUE);
			}
		//free_cdxaa_toc(&toc);
	}
	return(FALSE);
}

/******************************************************************************/

static void get_song_info(char *filename, char **title, int *length)
{
	char *name,*p;
	CDXAA_TOC_Entry toce;

	Printf("get_song_info(\"%s\",%p,%p)\n",filename,title,length);
	filename=fixfilename(filename);
	*title=g_strdup(filename+strspn(filename,slash));
	*length=0;
	if(get_cdxaa_toce(filename,&toce))
		*length=timeof(toce.len);
	if(SLASH!='/')
		while((p=strchr(*title,SLASH)))
			*p='/';
	Printf("\ttitle=\"%s\"\tlength=%d\n",*title,*length);
}

/******************************************************************************/

static GList *cdxaa_scan_dir(char *dir)
{
	GList *l=NULL;
	gint i;
	CDXAA_TOC toc;

	Printf("cdxaa_scan_dir(\"%s\")\n",dir);
	if(strncmp(state.dir, dir, strlen(state.dir)))
		return(NULL);
	Printf("\tcdxaa_get_toc(\"%s\",%p)\n",dir,&toc);
	if(!cdxaa_get_toc(dir,&toc) || !toc.len)
		return(NULL);
	Printf("\ttoc.crc=%08x toc.len=%d\n",toc.crc,toc.len);
	for(i=toc.len-1; i>=0; i--)
	{
		Printf("\tg_list_prepend(l,\"%s%s\")\n",toc.toce[i].name,FILEEXT);
		l=g_list_prepend(l,g_strdup_printf("%s%s",toc.toce[i].name,FILEEXT));
	}
	//free_cdxaa_toc(&toc);
	Printf("\treturn(%p)\n",l);
	return(l);
}

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

#ifndef DEBUG_TOC
#undef Printf
#define Printf
#endif

static void free_cdxaa_toc(CDXAA_TOC *toc)
{
	int i;
	if(!toc->toce || !toc->len)
		return;
	for(i=0;i<toc->len;i++)
		if(toc->toce[i].name)
			free(toc->toce[i].name);
	free(toc->toce);
}

/******************************************************************************/

static void init_cdxaa_toc_entry(CDXAA_TOC_Entry *toce)
{
	memset(toce,0,sizeof(CDXAA_TOC_Entry));
}

/******************************************************************************/

static void init_cdxaa_toc(CDXAA_TOC *toc)
{
	memset(toc,0,sizeof(CDXAA_TOC));
}

/******************************************************************************/

static void add_cdxaa_toc_entry(CDXAA_TOC *toc, char *name, unsigned long start ,unsigned long len)
{
	Printf("add_cdxaa_toc_entry(%p,\"%s\",%u,%u)\n",toc,name,start,len);
	toc->toce=realloc(toc->toce,(toc->len+1)*sizeof(CDXAA_TOC_Entry));
	init_cdxaa_toc_entry(&toc->toce[toc->len]);
	toc->toce[toc->len].name=strdup(name);
	toc->toce[toc->len].start=start;
	toc->toce[toc->len].len=len;
	toc->len++;
}

/******************************************************************************/

static void frame2msf(unsigned long i, struct cdrom_msf *msf)
{
	msf->cdmsf_min0  =   i   /CD_SECS   /CD_FRAMES;
	msf->cdmsf_sec0  =  (i   /CD_FRAMES)%CD_SECS;
	msf->cdmsf_frame0=   i   %CD_FRAMES;
	msf->cdmsf_min1  =  (i+1)/CD_SECS   /CD_FRAMES;
	msf->cdmsf_sec1  = ((i+1)/CD_FRAMES)%CD_SECS;
	msf->cdmsf_frame1=  (i+1)%CD_FRAMES;
}


/******************************************************************************/

static unsigned long msf2frame(struct cdrom_msf0 *msf)
{
	return(msf->minute*CD_SECS*CD_FRAMES+
			msf->second*CD_FRAMES+
			msf->frame);
}

/******************************************************************************/

static void isofixname(char *name)
{
	int i;

	Printf("isofixname(\"%s\")\n",name);
	switch(name[0])
	{
		case 0:
			strcpy(name,".");
			break;
		case 1:
			strcpy(name,"..");
			break;
	}
	for(i=0;name[i];i++)
	{
		if(isupper(name[i]))
			name[i]=name[i]-'A'+'a';
		if(name[i]==';' && name[i+1]=='1')
			name[i]=0;
		if(name[i]==';')
			name[i]='.';
	}
	Printf("	(after)name=\"%s\"\n",name);
}

/******************************************************************************/

static void init_cdxaa_dir(CDXAA_Dir *dir)
{
	memset(dir,0,sizeof(CDXAA_Dir));
}
/******************************************************************************/

static void add_cdxaa_dir(CDXAA_Dir **dirs, int *len, char *path, unsigned long offset)
{
	Printf("add_cdxaa_dir(%p,%d,\"%s\",%lu)\n",*dirs,*len,path,offset);
	(*dirs)=realloc(*dirs,(*len+1)*sizeof(CDXAA_Dir));
	init_cdxaa_dir(&(*dirs)[*len]);
	strncpy((*dirs)[*len].path,path,MAXPATHLEN);
	(*dirs)[*len].offset=offset;
	(*len)++;
}

/******************************************************************************/


static void printtoce(struct cdrom_tocentry *toce)
{
	char *formatstr[]={
		"Unknown",
		"LBA",
		"MSF"
	};

	Printf("Track    : %u\n",toce->cdte_track);
	Printf("Address  : %u\n",toce->cdte_adr);
	Printf("Control  : %u\n",toce->cdte_ctrl);
	Printf("Format   : %d = %s\n",toce->cdte_format, formatstr[toce->cdte_format]);
}

static void printtochdr(struct cdrom_tochdr *toc)
{
	Printf("First Track: %u\n",toc->cdth_trk0);
	Printf("Last  Track: %u\n",toc->cdth_trk1);
}

static void printisodr(struct iso_directory_record *isodr)
{
	char ch;

	Printf("length                : %u\n",*isodr->length);
	Printf("ext_attr_length       : %u\n",*isodr->ext_attr_length);
	Printf("extent                : %ld\n",*(unsigned long*)isodr->extent);
	Printf("size                  : %ld\n",*(unsigned long*)isodr->size);
	//Printf("date                  : %u\n",*isodr->date);
	Printf("flags                 : %u\n",*isodr->flags);
	Printf("file_unit_size        : %u\n",*isodr->file_unit_size);
	Printf("interleave            : %lu\n",*(unsigned long*)isodr->interleave);
	Printf("volume_sequence_number: %u\n",*isodr->volume_sequence_number);
	Printf("name_len              : %u\n",*isodr->name_len);
	ch=isodr->name[0];
	Printf("name                  : %*.*s\n",*isodr->name_len,*isodr->name_len,isodr->name);
}

static void printisopd(struct iso_primary_descriptor *isopd)
{
	struct iso_directory_record *isodrptr;
	
	Printf("type                  : %d\n",*isopd->type);
	Printf("id                    : %5.5s\n",isopd->id);
	Printf("version               : %d\n",*isopd->version);
	Printf("system_id             : %32.32s\n",isopd->system_id);
	Printf("volume_id             : %32.32s\n",isopd->volume_id);
	Printf("volume_space_size     : %ld * %d\n",*(long*)isopd->volume_space_size,ISOFS_BLOCK_SIZE);
	Printf("volume_set_size       : 0x%lx\n",*(long*)isopd->volume_set_size);
	Printf("volume_sequence_number: 0x%lx\n",*(long*)isopd->volume_sequence_number);
	Printf("logical_block_size    : %ld\n",*(long*)isopd->logical_block_size);
	Printf("path_table_size       : %ld\n",*(long*)isopd->path_table_size);
	Printf("type_l_path_table     : %ld\n",*(long*)isopd->type_l_path_table);
	Printf("opt_type_l_path_table : %ld\n",*(long*)isopd->opt_type_l_path_table);
	//Printf("type_m_path_table     : %ld\n",*(long*)isopd->type_m_path_table);
	//hexdump(isopd->type_m_path_table,4);
	//Printf("\nopt_type_m_path_table : %ld\n",*(long*)isopd->opt_type_m_path_table);
	Printf("iso directory record\n");
	isodrptr=(struct iso_directory_record*)&isopd->root_directory_record;
	printisodr(isodrptr);
	Printf("volume_set_id         : %.28s\n",isopd->volume_set_id);
	Printf("publisher_id          : %.128s\n",isopd->publisher_id);
	Printf("preparer_id           : %.128s\n",isopd->preparer_id);
	Printf("application_id        : %.128s\n",isopd->application_id);
	Printf("copyright_file_id     : %.37s\n",isopd->copyright_file_id);
	Printf("abstract_file_id      : %.37s\n",isopd->abstract_file_id);
	Printf("bibliographic_file_id : %.37s\n",isopd->bibliographic_file_id);
	Printf("file_structure_version: %d\n",*isopd->file_structure_version);
	Printf("application_data      : ");
	//hexdump(isopd->application_data,512);
	Printf("\n");
}

static void dumpch(unsigned char *data, int len)
{
	int i;

	for(i=0;i<len;i++)
		if(isprint(data[i]))
			Printf("%c",data[i]);
		else
			Printf(".");
}

static void hexdump(unsigned char *data, int len)
{
	int i,j;

	for(i=0;i<len;i++)
	{
		if(!(i%16))
			Printf("\n%8.8x: ",i);
		Printf("%2.2x",data[i]&0xff);
		if(!((i+1)%4))
			Printf(" ");
		if(((i+1)%16)==0 || (i+1)==len)
		{
			j=i>>4<<4;
			dumpch(&data[j],i-j+1);
		}
	}
	Printf("\n");
}

/******************************************************************************/

static gboolean cdxaa_get_toc(char *dir, CDXAA_TOC *toc)
{
	int fd;
	struct cdrom_tochdr toch;
	struct cdrom_tocentry toce;
	struct iso_primary_descriptor isopd;
	struct iso_directory_record *isodrptr;
	unsigned char buf[CD_FRAMESIZE_RAW];
	unsigned int trackoffset=0,offset;
	char path[MAXPATHLEN]="",fullname[MAXPATHLEN]="";
	CDXAA_Dir *dirs=NULL,*pwd=NULL;
	int numdirs=0,i,datatrack=0;
	static CDXAA_TOC oldtoc={0,0,NULL};

	Printf("cdxaa_get_toc(\"%s\",%p)\n",dir,toc);
	init_cdxaa_toc(toc);
	if((fd=open(state.dev,O_RDONLY))==-1)
		return(FALSE);
	/* cdrom_tochdr */
	Printf("cdrom_tochdr\n");
	if(ioctl(fd,CDROMREADTOCHDR,&toch)==-1)
		{ close(fd); return(FALSE); }
	toc->crc=crc32(&toch,sizeof(struct cdrom_tochdr),0);
	printtochdr(&toch);
	/* cdrom_tocentry */
	Printf("cdrom_tocentry\n");
	toce.cdte_format=CDROM_MSF;
	/* complete crc32 calculations */
	for(i=toch.cdth_trk0;i<=toch.cdth_trk1;i++)
	{
		toce.cdte_track=i;
		if(ioctl(fd,CDROMREADTOCENTRY,&toce)!=-1)
			toc->crc=crc32(&toch,sizeof(struct cdrom_tochdr),toc->crc);
		if(!datatrack && toce.cdte_ctrl&CDROM_DATA_TRACK) /* find first data track */
			datatrack=i;
	}
	if(!datatrack)
		{ close(fd); return(FALSE); }
	Printf("crc=%08x",toc->crc);
	if(oldtoc.crc==toc->crc)
	{
		Printf("Using oldtoc\n");
		memcpy(toc,&oldtoc,sizeof(CDXAA_TOC));
		close(fd);
		return(TRUE);
	}
	Printf("Need new toc\n");
	free_cdxaa_toc(&oldtoc);
	init_cdxaa_toc(&oldtoc);
	toce.cdte_track=datatrack; /* TODO: Only works for first data track */
	if(ioctl(fd,CDROMREADTOCENTRY,&toce)==-1)
		{ close(fd); return(FALSE); }
	printtoce(&toce);
	switch(toce.cdte_format)
	{
		case CDROM_MSF:
			trackoffset=msf2frame(&toce.cdte_addr.msf);
			break;
		case CDROM_LBA:
			trackoffset=toce.cdte_addr.lba;
			break;
	}
	/* iso_primary_descriptor */
	Printf("iso_primary_descriptor\n");
	frame2msf(trackoffset+16,(struct cdrom_msf*)&buf);
	if(ioctl(fd,CDROMREADRAW,buf,buf) < 0)
		{ close(fd); return(FALSE); }
	memcpy(&isopd,&buf[CD_SYNC_SIZE+CD_HEAD_SIZE+CD_SUBHEAD_SIZE],sizeof(struct iso_primary_descriptor));
	printisopd(&isopd);
	/* search dirs for path match */
	Printf("search dirs for path match\n");
	isodrptr=(struct iso_directory_record*)&isopd.root_directory_record;
	i=trackoffset+(*isodrptr->extent); //usually extent is 22
	pwd=NULL;
	do
	{
		if(pwd)
			i=trackoffset+pwd->offset;
		Printf("i=%u\n",i);
		if(readraw(fd,buf,i)<0)
			break;
		hexdump(buf,CD_FRAMESIZE_RAW);
		/* 	iso_directory_record CD_FRAMESIZE_RAW blocks */
		for(offset=0;offset<2048;offset+=*isodrptr->length)
		{
			Printf("offset=%u\n",offset);
			isodrptr=(struct iso_directory_record*)(buf+CD_SYNC_SIZE+CD_HEAD_SIZE+CD_SUBHEAD_SIZE+offset);
			if(!isodrptr || !(*(unsigned*)isodrptr->length))
				break;
			printisodr(isodrptr);
			isofixname(isodrptr->name);
			if((*(unsigned*)isodrptr->flags)&ISODR_FLAG_ISDIR)
			{ /* dir */
				if(*isodrptr->name_len!=1)
				{
					sprintf(path, "%s%c%s",(pwd?pwd->path:""),SLASH,isodrptr->name);
					add_cdxaa_dir(&dirs,&numdirs,path,*(unsigned long*)isodrptr->extent);
				}
			}
			else
			{ /* file */
				/*Printf("\"%s\" ?= \"%s\"\n",(pwd?pwd->path:"/"),dir+strlen(state.dir));
				if(!strcmp(pwd?pwd->path:"/",dir+strlen(state.dir)))
				{
					add_cdxaa_toc_entry(toc,isodrptr->name,
							*(unsigned long*)isodrptr->extent+trackoffset,
							*(unsigned long*)isodrptr->size);
				}*/
				/*sprintf(fullname,"%s%s%c%s%s",
						state.dir,(pwd?pwd->path:""),SLASH,isodrptr->name,FILEEXT);*/
				if(pwd && pwd->path[0])
					sprintf(fullname,"%s%c%s",pwd->path,SLASH,isodrptr->name);
				else
					sprintf(fullname,"%c%s",SLASH,isodrptr->name);
				add_cdxaa_toc_entry(toc,fullname,
						*(unsigned long*)isodrptr->extent+trackoffset,
						(*(unsigned long*)isodrptr->size+2047)>>11);
			}
			
		}
		if(pwd)
		{
			numdirs--;
			if(numdirs>0)
				memcpy(dirs,&dirs[1],numdirs*sizeof(CDXAA_Dir));
			dirs=realloc(dirs,numdirs*sizeof(CDXAA_Dir));
			pwd=dirs;
		}
		if(!pwd && numdirs>0 && dirs)
			pwd=dirs;
	} while(pwd);
	close(fd);
	if(dirs)
		free(dirs);
	for(i=0;i<toc->len;i++)
		Printf("%d) \"%s\" %lu %lu\n",i,toc->toce[i].name,toc->toce[i].start,toc,toc->toce[i].len);
	memcpy(&oldtoc,toc,sizeof(CDXAA_TOC));
	return(TRUE);
}

#ifdef DEBUG
#undef Printf
#define Printf printf
#endif

/******************************************************************************/
/* this is required due to the state of subdir handling in xmms 1.0.1         */
/* it also normalizes the filename to match the toc list correctly            */

static char *fixfilename(char *infilename)
{
	static char *p, doubleslash[3]={'/',SLASH,'\0'}, *filename=NULL;

	Printf("fixfilename(\"%s\")\n",infilename);
	if(filename)
		free(filename);
	filename=g_strdup(infilename);
	if((p=strstr(filename,doubleslash)))
		strcpy(filename,p+1);	
	while(filename[0]==SLASH && !strncmp(filename,state.dir,strlen(state.dir)))
	{
		while(!strncmp(filename,state.dir,strlen(state.dir)))
			strcpy(filename,filename+strlen(state.dir));
		while(filename[0]==SLASH && filename[1]==SLASH)
			strcpy(filename,filename+1);
	}
	while(filename[0]==SLASH)
		strcpy(filename,filename+1);
	p=strrchr(filename,'.');
	if(p && !strcmp(p,FILEEXT))
		*p=0;
	memmove(filename+1,filename,strlen(filename)+1);
	filename[0]=SLASH;
	Printf("\tfilename=\"%s\"\n",filename);
	return(filename);
}

/******************************************************************************/

static int readraw(int fd, unsigned char *buf,int frame)
{
	frame2msf(frame,(struct cdrom_msf*)buf);
	return(ioctl(fd,CDROMREADRAW,buf,buf));
}
