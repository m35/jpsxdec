#include "matrix.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

Matrix *matrixInit(Matrix *m)
{
	m->r=0;
	m->c=0;
	m->m=NULL;
	return(m);
}

Matrix *matrixNew(int r, int c)
{
	//printf("matrixNew(%d,%d)\n",r,c);
	Matrix *m=malloc(sizeof(Matrix));
	matrixAlloc(m,r,c);
	return(m);
}

Matrix *matrixAlloc(Matrix *m, int r, int c)
{
	int i;
	
	//printf("matrixAlloc(%p,%d,%d)\n",m,r,c);
	m->r=r;
	m->c=c;
	if(r)
	{
		m->m=(double**)malloc(sizeof(double*)*r);
		for(i=0;i<r;i++)
			m->m[i]=(double*)malloc(sizeof(double)*c);
	}
	else
		m->m=NULL;
	return(m);
}

Matrix *matrixNewCopy(Matrix *n)
{
	int i;
	Matrix *m;
	
	m=matrixNew(n->r,n->c);
	for(i=0;i<m->r;i++)
		memcpy(m->m[i],n->m[i],sizeof(double)*m->c);
	return(m);
}

Matrix *matrixCopy(Matrix *m, Matrix *n)
{
	int i;
	
	matrixFree(m);
	matrixAlloc(m,n->r,n->c);
	for(i=0;i<m->r;i++)
		memcpy(m->m[i],n->m[i],sizeof(double)*m->c);
	return(m);
}

Matrix *matrixCopyArray(Matrix *m, double n[], int r, int c)
{
	int i,j;
	
	matrixFree(m);
	matrixAlloc(m,r,c);
	for(i=0;i<r;i++)
		for(j=0;j<c;j++)
			m->m[i][j]=n[i*c+j];
	return(m);
}

void matrixFree(Matrix *m)
{
	int i;

	//printf("matrixFree(%p)\n",m);
	//matrixPrint(m);
	if(m && m->m)
	{
		for(i=0;i<m->r;i++)
			if(m->m[i])
				free(m->m[i]);
		free(m->m);
	}
}

void matrixDelete(Matrix *m)
{
	//printf("matrixDelete(%p)\n",m);
	if(m)
	{
		matrixFree(m);
		free(m);
	}
}

void matrixPrint(Matrix *m)
{
	int r,c;

	printf("%p[%d,%d]\n",m,m->r,m->c);
	for(r=0;r<m->r;r++)
	{
		for(c=0;c<m->c;c++)
			printf("%f\t",m->m[r][c]);
		printf("\n");
	}
}

Matrix *matrixIdentity(Matrix *m, int s)
{
	int i;

	matrixAlloc(m,s,s);
	for(i=0;i<m->r;i++)
	{
		memset(m->m[i],0,sizeof(double)*s);
		m->m[i][i]=1;
	}
	return(m);
}

Matrix *matrixTranspose(Matrix *m)
{
	int r,c;
	Matrix n;
	
	matrixAlloc(&n,m->c,m->r);
	for(r=0;r<m->r;r++)
		for(c=0;c<m->c;c++)
			n.m[c][r]=m->m[r][c];
	matrixCopy(m,&n);
	matrixFree(&n);
	return(m);
}

static Matrix *subMatrix(Matrix *m, int r, int c, Matrix *n)
{
	int r1,c1,r2,c2;

	for(r1=r2=0;r1<m->r;r1++,r2++)
		for(c1=c2=0;c1<m->c;c1++,c2++)
		{
			if(c1==c)
				c1++;
			if(r1==r)
				r1++;
			if(c1<m->c && r1<m->r)
				n->m[r2][c2]=m->m[r1][c1];
		}
	return(n);
}

Matrix *matrixInverse(Matrix *m)
{
	int r,c;
	double det,s;
	Matrix n,o;
	
	det=matrixDeterminant(m);
	if(m->c != m->r || !det)
	{
		printf("matrixInverse: invalid matrix!\n");
		matrixPrint(m);
		printf("det=%f\n",det);
		return(NULL);
	}
	matrixInit(&n);
	matrixCopy(&n,m);
	matrixAlloc(&o,m->r-1,m->c-1);
	for(c=0;c<n.c;c++)
	{
		s=(c%2?-1:1);
		for(r=0;r<n.r;s*=-1,r++)
		{
			subMatrix(m,r,c,&o);
			n.m[c][r]=s*matrixDeterminant(&o)/det;
		}
	}
	matrixCopy(m,&n);
	matrixFree(&o);
	matrixFree(&n);
	return(m);
}

double matrixDeterminant(Matrix *m)
{
	Matrix n;
	double d,s;
	int c;
	
	//matrixPrint(m);
	if(!m || m->r!=m->c || !m->m)
	{
		printf("matrixDeterminant: invalid matrix!\n");
		matrixPrint(m);
		return(0);
	}
	if(m->r==1)
	{
		//printf("det1x1=%f\n",m->m[0][0]);
		return(m->m[0][0]);
	}
	if(m->r==2)
	{
		d=m->m[0][0]*m->m[1][1]-m->m[1][0]*m->m[0][1];
		//printf("det2x2=%f\n",d);
		return(d);
	}
	matrixAlloc(&n,m->r-1,m->c-1);
	for(s=1,d=0,c=0; c<m->c; s*=-1,c++)
	{
		subMatrix(m,0,c,&n);
		d += s*m->m[0][c]*matrixDeterminant(&n);
	}
	matrixFree(&n);
	//printf("det=%f\n",d);
	return(d);
}

Matrix *matrixDiv1(Matrix *m, double d)
{
	int r,c;

	for(r=0;r<m->r;r++)
		for(c=0;c<m->c;c++)
			m->m[r][c]/=d;
	return(m);
}

Matrix *matrixMultiply(Matrix *m, Matrix *n)
{
	Matrix o;
	int r,c,i;
	
	matrixAlloc(&o,m->r,n->c);
	for(r=0;r<o.r;r++)
		for(c=0;c<o.c;c++)
			for(i=0,o.m[r][c]=0; i<m->c; i++)
				o.m[r][c]+=m->m[r][i]*n->m[i][c];
	matrixCopy(m,&o);
	matrixFree(&o);
	return(m);
}

Matrix *matrixPseudoInverse(Matrix *m)
{
	Matrix n;

	matrixInit(&n);
	matrixCopy(&n,m);
	matrixTranspose(m);
	matrixMultiply(m,&n);
matrixPrint(m);
	matrixInverse(m);
matrixPrint(m);
	matrixTranspose(&n);
	matrixMultiply(m,&n);
	return(m);
}
