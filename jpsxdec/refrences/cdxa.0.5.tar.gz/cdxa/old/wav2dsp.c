#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <linux/soundcard.h>

int main(int argc, char **argv)
{
	int fd;
	int arg;
	unsigned char buf[4096];
	int status;

	status = fd = open("/dev/dsp", O_RDWR);
	if (status == -1) {
		perror("error opening /dev/dsp");
		exit(1);
	}

	arg = 16;
	status = ioctl(fd, SOUND_PCM_WRITE_BITS, &arg);
	if (status == -1)
		perror("SOUND_PCM_WRITE_BITS ioctl failed");
	if (arg != 16)
		perror("unable to set sample size");

	arg = 2;
	status = ioctl(fd, SOUND_PCM_WRITE_CHANNELS, &arg);
	if (status == -1)
		perror("SOUND_PCM_WRITE_CHANNELS ioctl failed");
	if (arg != 2)
		perror("unable to set number of channels");

	arg = 37800;
	status = ioctl(fd, SOUND_PCM_WRITE_RATE, &arg);
	if (status == -1) {
		perror("error from SOUND_PCM_WRITE_RATE ioctl");
		exit(1);
	}

	arg = AFMT_S16_LE;
	status = ioctl(fd, SOUND_PCM_SETFMT, &arg);
	if (status == -1)
		perror("SOUND_PCM_SETFMT ioctl failed");
	if (arg != AFMT_S16_LE)
		perror("unable to set number of channels");

	while(fread(buf,1,sizeof(buf),stdin))
	{
		status = write(fd, buf, sizeof(buf));
		if (status == -1) {
			perror("error writing to /dev/dsp");
			exit(1);
		}
	}

	status = close(fd);
	if (status == -1) {
		perror("error closing /dev/dsp");
		exit(1);
	}

	return(0);
}
