#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/cdrom.h>
#include <linux/iso_fs.h>
#include "iso9660.h"
#include "util.h"

char *formatstr[]={
	"Unknown",
	"LBA",
	"MSF"
};

void printmsf(struct cdrom_msf0 *msf)
{
	Printf("%u:%u:%u",
			msf->minute,
			msf->second,
			msf->frame);
}

unsigned long msf2frame(struct cdrom_msf0 *msf)
{
	return(msf->minute*CD_SECS*CD_FRAMES+
			msf->second*CD_FRAMES+
			msf->frame);
}

char *cdstatus(int status)
{
	char *statusstr[]={
		"CDS_NO_INFO",
		"CDS_NO_DISC",
		"CDS_TRAY_OPEN",
		"CDS_DRIVE_NOT_READY",
		"CDS_DISC_OK"
	};
	char *formatstr[]={
		"CDS_AUDIO",
		"CDS_DATA_1",
		"CDS_DATA_2",
		"CDS_XA_2_1",
		"CDS_XA_2_2",
		"CDS_MIXED"
	};
	if(status<=CDS_DISC_OK && status>=CDS_NO_INFO)
		return(statusstr[status-CDS_NO_INFO]);
	if(status<=CDS_MIXED && status>=CDS_AUDIO)
		return(formatstr[status-CDS_AUDIO]);
	return("Invalid!");
}

void frame2msf(unsigned long i, struct cdrom_msf *msf)
{
	msf->cdmsf_min0  =   i   /CD_SECS   /CD_FRAMES;
	msf->cdmsf_sec0  =  (i   /CD_FRAMES)%CD_SECS;
	msf->cdmsf_frame0=   i   %CD_FRAMES;
	msf->cdmsf_min1  =  (i+1)/CD_SECS   /CD_FRAMES;
	msf->cdmsf_sec1  = ((i+1)/CD_FRAMES)%CD_SECS;
	msf->cdmsf_frame1=  (i+1)%CD_FRAMES;
}

void printmsf2(struct cdrom_msf *msf)
{
	Printf("min0  : %d\n",msf->cdmsf_min0);
	Printf("sec0  : %d\n",msf->cdmsf_sec0);
	Printf("frame0: %d\n",msf->cdmsf_frame0);
	Printf("min1  : %d\n",msf->cdmsf_min1);
	Printf("sec1  : %d\n",msf->cdmsf_sec1);
	Printf("frame1: %d\n",msf->cdmsf_frame1);
}

void printisodr(struct iso_directory_record *isodr)
{
	char ch;

	Printf("length                : %u\n",*isodr->length);
	Printf("ext_attr_length       : %u\n",*isodr->ext_attr_length);
	Printf("extent                : %ld\n",*(unsigned long*)isodr->extent);
	Printf("size                  : %ld\n",*(unsigned long*)isodr->size);
	//Printf("date                  : %u\n",*isodr->date);
	Printf("flags                 : %u\n",*isodr->flags);
	Printf("file_unit_size        : %u\n",*isodr->file_unit_size);
	Printf("interleave            : %lu\n",*(unsigned long*)isodr->interleave);
	Printf("volume_sequence_number: %u\n",*isodr->volume_sequence_number);
	Printf("name_len              : %u\n",*isodr->name_len);
	ch=isodr->name[0];
	Printf("name                  : %*.*s\n",*isodr->name_len,*isodr->name_len,isodr->name);
}

void isofixname(char *name)
{
	int i;

	switch(name[0])
	{
		case 0:
			strcpy(name,".");
			break;
		case 1:
			strcpy(name,"..");
			break;
	}
	for(i=0;name[i];i++)
	{
		if(isupper(name[i]))
			name[i]=name[i]-'A'+'a';
		if(name[i]==';' && name[i+1]=='1')
			name[i]=0;
		if(name[i]==';')
			name[i]='.';
	}
}

struct ISODR *isoreaddirblock(int fd, int i, char *path)
{
	struct iso_directory_record *isodrptr;
	struct ISODR *ISODR=NULL, *isodr=NULL;
	struct cdrom_msf msf;
	u_char data[CD_FRAMESIZE_RAW];
	void *ptr;
	int offset;

	frame2msf(i,&msf);
	printmsf2(&msf);
	memcpy(data,&msf,sizeof(msf));
	if(ioctl(fd,CDROMREADRAW,data,data) < 0)
	{
		perror("CDROMREADRAW");
		return(NULL);
	}
	else
	{
		hexdump(data+CD_SYNC_SIZE+CD_HEAD_SIZE+CD_SUBHEAD_SIZE,2048);
		ptr=data+CD_SYNC_SIZE+CD_HEAD_SIZE+CD_SUBHEAD_SIZE;
		offset=0;
		while(offset<2048)
		{
			isodrptr=ptr+offset;
			if(!*isodrptr->length) return(ISODR);
			if(!ISODR)
			{
				isodr=ISODR=malloc(*isodrptr->length+ISODR_EXTRA);
				isodr->next=NULL;
			}
			else
			{
				isodr->next=malloc(*isodrptr->length+ISODR_EXTRA);
				isodr=isodr->next;
				isodr->next=NULL;
			}
			isodr->path=strdup(path);
			isofixname(isodrptr->name);
			isodr->isxa=2; //unscanned
			memcpy(&isodr->isodr, isodrptr, *isodrptr->length);
			Printf("offset                ) %d\n",offset);
			printisodr(isodrptr);
			Printf("path                  : %s\n",path);
			offset+=*isodrptr->length;
		}
	}
	return(ISODR);
}

struct ISODR *findisofname(struct ISODR *ISODR, char *fname)
{
	struct ISODR *isodr;
	char path[4096];

	for(isodr=ISODR; isodr; isodr=isodr->next)
	{
		Printf("isodr : path(%s) file(%s)\n",isodr->path,isodr->isodr.name);
		sprintf(path,"%s/%s",isodr->path,isodr->isodr.name);
		Printf("path  : %s\n",path);
		Printf("fname : %s\n",fname);
		if(!strcasecmp(path,fname))
			return(isodr);
	}
	return(NULL);
}

int openISO9660(ISO9660 *iso, char *dev)
{
	iso->fd=open(dev,O_RDONLY);
	if(iso->fd == -1)
		perror("open");
	else
		Printf("Opened: %s\n",dev);
	return(iso->fd);
}

int closeISO9660(ISO9660 *iso)
{
	int err;
	ISODR *p,*q;

	err=close(iso->fd);
	iso->fd=-1;
	if(iso->ISODR)
	{
		for(q=p=iso->ISODR; q && p; p=q)
		{
			q=p->next;
			if(p->path)
				free(p->path);
			free(p);
		}
		iso->ISODR=NULL;
	}
	Printf("Close: %d\n",err);
	return(err);
}

int resetCDROM(int fd)
{
	// reset the drive // this is optional!  I just liked it ;)
	Printf("resetCDROM\n");
	if(ioctl(fd,CDROMRESET,NULL)==-1)
	{
		perror("CDROMRESET");
		return(0);
	}
	return(1);
}

int ejectCDROM(int fd)
{
	Printf("ejectCDROM\n");
	if(ioctl(fd,CDROMEJECT)==-1)
	{
		perror("CDROMEJECT");
		return(0);
	}
	return(1);
}

int drivestatusCDROM(int fd)
{
	int i;
	// check drive status
	Printf("DRIVE_STATUS\n");
	if((i=ioctl(fd,CDROM_DRIVE_STATUS,CDSL_CURRENT))==-1)
	{
		perror("DRIVE_STATUS");
		return(0);
	}
	Printf("Drive Status: %d = %s\n",i,cdstatus(i));
	return(i==CDS_DISC_OK);
}

int discstatusCDROM(int fd)
{
	int i;

	// check disc status
	Printf("DISC_STATUS\n");
	if((i=ioctl(fd,CDROM_DISC_STATUS))==-1)
	{
		perror("DISC_STATUS");
		return(0);
	}
	Printf("Disk Format/Status: %d = %s\n",i,cdstatus(i));
	return(i!=CDS_AUDIO);
}

void printtoce(struct cdrom_tocentry *toce)
{
	Printf("Track    : %u\n",toce->cdte_track);
	Printf("Address  : %u\n",toce->cdte_adr);
	Printf("Control  : %u\n",toce->cdte_ctrl);
	Printf("Format   : %d = %s\n",toce->cdte_format, formatstr[toce->cdte_format]);
}

void printtochdr(struct cdrom_tochdr *toc)
{
	Printf("First Track: %u\n",toc->cdth_trk0);
	Printf("Last  Track: %u\n",toc->cdth_trk1);
}

int gettocISO9660(ISO9660 *iso, char track)
{
	int i;

	// get cdrom TOC Head
	Printf("TOCHDR\n");
	if(ioctl(iso->fd,CDROMREADTOCHDR,&iso->toc)==-1)
	{
		perror("CDROMREADTOCHDR");
		return(0);
	}
	printtochdr(&iso->toc);

	// get cdrom TOC Entries
	Printf("TOCENTRY\n");
	memset(&iso->toce,0,sizeof(iso->toce));
	iso->toce.cdte_format=CDROM_MSF;
	for(i=iso->toc.cdth_trk0; i<=iso->toc.cdth_trk1; i++)
	{
		iso->toce.cdte_track=i;
		if(ioctl(iso->fd,CDROMREADTOCENTRY,&iso->toce)==-1)
		{
			perror("CDROMREADTOCENTRY");
			return(0);
		}
		printtoce(&iso->toce);
		switch(iso->toce.cdte_format)
		{
			case CDROM_MSF:
				Printf("MSF      : %lu  ",msf2frame(&iso->toce.cdte_addr.msf));
				if(i==iso->toc.cdth_trk0+track)
					iso->trackoffset=msf2frame(&iso->toce.cdte_addr.msf);
				printmsf(&iso->toce.cdte_addr.msf);
				Printf("\n");
				break;
			case CDROM_LBA:
				Printf("LBA      : 0x%.8x\n",iso->toce.cdte_addr.lba);
				break;
		}
		Printf("DataMode : %u\n",iso->toce.cdte_datamode);
	}
	Printf("First Frame of Track %d: %ld\n",track,iso->trackoffset);
	return(1);
}

int multisessionISO9660(ISO9660 *iso)
{
	// check for multisession
	Printf("MULTISESSION\n");
	if(ioctl(iso->fd,CDROMMULTISESSION,&iso->ms)!=-1)
	{
		Printf("Address of Last Session: 0x%.8x\n",iso->ms.addr.lba);
		Printf("XA Flag                : %d\n",iso->ms.xa_flag);
		Printf("Format                 : %d = %s\n",iso->ms.addr_format,formatstr[iso->ms.addr_format]);
		return(1);
	}
	perror("CDROMMULTISESSION");
	return(0);
}

int getmcnCDROM(ISO9660 *iso)
{
	Printf("MCN\n");
	if(ioctl(iso->fd,CDROM_GET_MCN,&iso->mcn)!=-1)
	{
		Printf("Medium Catalog Number: %s\n",iso->mcn.medium_catalog_number);
		return(1);
	}
	perror("Medium Catalog Number");
	return(0);
}

void printisopd(struct iso_primary_descriptor *isopd)
{
	struct iso_directory_record *isodrptr;
	
	Printf("type                  : %d\n",*isopd->type);
	Printf("id                    : %5.5s\n",isopd->id);
	Printf("version               : %d\n",*isopd->version);
	Printf("system_id             : %32.32s\n",isopd->system_id);
	Printf("volume_id             : %32.32s\n",isopd->volume_id);
	Printf("volume_space_size     : %ld * %d\n",*(long*)isopd->volume_space_size,ISOFS_BLOCK_SIZE);
	Printf("volume_set_size       : 0x%lx\n",*(long*)isopd->volume_set_size);
	Printf("volume_sequence_number: 0x%lx\n",*(long*)isopd->volume_sequence_number);
	Printf("logical_block_size    : %ld\n",*(long*)isopd->logical_block_size);
	Printf("path_table_size       : %ld\n",*(long*)isopd->path_table_size);
	Printf("type_l_path_table     : %ld\n",*(long*)isopd->type_l_path_table);
	Printf("opt_type_l_path_table : %ld\n",*(long*)isopd->opt_type_l_path_table);
	//Printf("type_m_path_table     : %ld\n",*(long*)isopd->type_m_path_table);
	//hexdump(isopd->type_m_path_table,4);
	//Printf("\nopt_type_m_path_table : %ld\n",*(long*)isopd->opt_type_m_path_table);
	Printf("iso directory record\n");
	isodrptr=(struct iso_directory_record*)&isopd->root_directory_record;
	printisodr(isodrptr);
	Printf("volume_set_id         : %.28s\n",isopd->volume_set_id);
	Printf("publisher_id          : %.128s\n",isopd->publisher_id);
	Printf("preparer_id           : %.128s\n",isopd->preparer_id);
	Printf("application_id        : %.128s\n",isopd->application_id);
	Printf("copyright_file_id     : %.37s\n",isopd->copyright_file_id);
	Printf("abstract_file_id      : %.37s\n",isopd->abstract_file_id);
	Printf("bibliographic_file_id : %.37s\n",isopd->bibliographic_file_id);
	Printf("file_structure_version: %d\n",*isopd->file_structure_version);
	Printf("application_data      : ");
	hexdump(isopd->application_data,512);
	Printf("\n");
}

int getisopdISO9660(ISO9660 *iso)
{
	// get iso primary descriptor
	Printf("iso primary descriptor\n");
	frame2msf(iso->trackoffset+16,&iso->msf);
	printmsf2(&iso->msf);
	memcpy(iso->isopddata,&iso->msf,sizeof(iso->msf));
	if(ioctl(iso->fd,CDROMREADRAW,iso->isopddata,iso->isopddata) < 0)
	{
		perror("getisopdISO9660:CDROMREADRAW");
		return(0);
	}
	iso->isopd=(struct iso_primary_descriptor*)(&iso->isopddata[CD_SYNC_SIZE+CD_HEAD_SIZE+CD_SUBHEAD_SIZE]);
	printisopd(iso->isopd);
	return(1);
}

int getisodirISO9660(ISO9660 *iso)
{
	int i,ct=0;
	char path[4096]="";
	struct ISODR *isodr=NULL;

	iso->isodrtail=iso->ISODR=NULL;
	// get dir
	i=iso->trackoffset+22;
	do
	{
		if(!iso->ISODR)
			isodr=iso->isodrtail=iso->ISODR=isoreaddirblock(iso->fd,i,path);
		else
			iso->isodrtail->next=isoreaddirblock(iso->fd,i,path);
		while(iso->isodrtail && iso->isodrtail->next)
			iso->isodrtail=iso->isodrtail->next;
		if(isodr && *isodr->isodr.flags&ISODR_FLAG_ISDIR)
			isodr=isodr->next;
		while(isodr && (!(*isodr->isodr.flags&ISODR_FLAG_ISDIR) || (*isodr->isodr.name_len==1)))
			isodr=isodr->next;
		if(isodr)
		{
			Printf("\nDIR: \n");
			sprintf(path, "%s/%s", isodr->path, isodr->isodr.name);
			printisodr(&isodr->isodr);
			i=iso->trackoffset+(*(long*)isodr->isodr.extent);
		}
		ct++;
	} while (isodr);
	return(ct);
}

int findfileISO9660(ISO9660 *iso, char *name)
{
	
	Printf("Name: %s\n",name);
	iso->isodr=findisofname(iso->ISODR,name);
	if(!iso->isodr)
	{
		fprintf(stderr,"File not found:%s\n",name);
		return(0);
	}
	printisodr(&iso->isodr->isodr);
	return(1);
}

void calcboundsISO9660(ISO9660 *iso)
{
	iso->start=iso->trackoffset+*(unsigned long*)iso->isodr->isodr.extent;
	iso->end=iso->start+(*(unsigned long*)iso->isodr->isodr.size>>11);
}

int ripISO9660RawFrame(ISO9660 *iso, unsigned long offset)
{
	unsigned long i;
	
	// do rip
	frame2msf(
		(i=iso->trackoffset+*(unsigned long*)iso->isodr->isodr.extent+offset),
		&iso->msf);
	if(i>=iso->start && i<=iso->end)
	{
		//fprintf(stderr,"i=%lu\n",i);
		memcpy(iso->data,&iso->msf,sizeof(iso->msf));
		if(ioctl(iso->fd,CDROMREADRAW,iso->data,iso->data)<0)
		{
			perror("ripISO9660XA:CDROMREADRAW");
			return(0);
		}
		else
			return(1);
	}
	return(0);
}
