#include <stdlib.h>
#include <string.h>
#include "dsp.h"
#include "matrix.h"

int freq=0,samplerate,channels=0;

int opendsp()
{
	int status;

	status = open("/dev/dsp", O_RDWR);
	if (status == -1) {
		perror("Error opening /dev/dsp");
		return(0);
	}
	return(status);
}

int setdspbits(int fd, int bits)
{
	int status;

	status = ioctl(fd, SOUND_PCM_WRITE_BITS, &bits);
	if (status == -1)
	{
		perror("SOUND_PCM_WRITE_BITS ioctl failed");
		return(0);
	}
	if (bits != 16)
	{
		perror("Unable to set sample size");
		return(0);
	}
	return(1);
}

int setdspchannels(int fd, int _channels)
{
	int status,arg;

	arg=_channels;
	status = ioctl(fd, SOUND_PCM_WRITE_CHANNELS, &arg);
	if (status == -1)
	{
		perror("SOUND_PCM_WRITE_CHANNELS ioctl failed");
		return(0);
	}
	if (arg != _channels)
	{
		perror("Unable to set number of channels");
		return(0);
	}
	channels=_channels;
	return(1);
}

int setdsprate(int fd, int rate)
{
	int status;

	samplerate=rate;
	rate=44100;
	status = ioctl(fd, SOUND_PCM_WRITE_RATE, &rate);
	if (status == -1) {
		perror("Error from SOUND_PCM_WRITE_RATE ioctl");
		return(0);
	}
	if(rate<samplerate)
	{
		rate=44100;
		status = ioctl(fd, SOUND_PCM_WRITE_RATE, &rate);
		if (status == -1) {
			perror("Error from SOUND_PCM_WRITE_RATE ioctl");
			return(0);
		}
	}
	freq=rate;
	return(freq);
}

int setdspS16LE(int fd)
{
	int status, arg;

	arg = AFMT_S16_LE;
	status = ioctl(fd, SOUND_PCM_SETFMT, &arg);
	if (status == -1)
	{
		perror("SOUND_PCM_SETFMT ioctl failed");
		return(0);
	}
	if (arg != AFMT_S16_LE)
	{
		perror("Unable to set sound format");
		return(0);
	}
	return(1);
}

int dspsync(int fd)
{
	int status;

	writedsp(fd,NULL,0);
	status = ioctl(fd, SOUND_PCM_SYNC, 0);
	if (status == -1)
	{
		perror("SOUND_PCM_SYNC ioctl failed");
		return(0);
	}
	return(1);
}

int dspreset(int fd)
{
	int status;

	status = ioctl(fd, SOUND_PCM_RESET, 0);
	if (status == -1)
	{
		perror("SOUND_PCM_RESET ioctl failed");
		return(0);
	}
	return(1);
}

int setdspdiv(int fd, int div)
{
	int status, arg;

	arg = div;
	status = ioctl(fd, SNDCTL_DSP_SUBDIVIDE, &arg);
	if (status == -1)
	{
		perror("SNDCTL_DSP_SUBDIVIDE ioctl failed");
		return(0);
	}
	return(1);
}

int setdspfrag(int fd, short pow2size, short num)
{
	int status;
	unsigned long arg;

	arg=((((unsigned long)pow2size)<<16)&0xffff0000)|(((unsigned long)num)&0xffff);
	//fprintf(stderr,"fragarg=0x%08lx\n",arg);
	status = ioctl(fd, SNDCTL_DSP_SETFRAGMENT, &arg);
	if (status == -1)
	{
		perror("SNDCTL_DSP_SETFRAGMENT ioctl failed");
		return(0);
	}
	return(1);
}

int getdspblksize(int fd, int *size)
{
	int status, *arg;

	arg = size;
	status = ioctl(fd, SNDCTL_DSP_GETBLKSIZE, arg);
	if (status == -1)
	{
		perror("SNDCTL_DSP_GETBLKSIZE ioctl failed");
		*size=64*1024;
		return(0);
	}
	return(1);
}

int getdspobytes(int fd, int *bytes)
{
	int status;
	count_info info;

	status = ioctl(fd, SNDCTL_DSP_GETOPTR, &info);
	if (status == -1)
	{
		perror("SNDCTL_DSP_GETOPTR ioctl failed");
		return(0);
	}
	*bytes=info.bytes*(samplerate/(float)freq);
	return(1);
}

static int refreq(short *buf, int size, int *size2, short **buf2, int from, int to)
{
	double d,J;
	int i,j;
	static double pim4x4[]={
		 1.000000,  0.000000,  0.000000,  0.000000,
		-1.277778,  1.333333,  0.166667, -0.222222,
		 0.166667,  0.000000, -0.500000,  0.333333,
		 0.111111, -0.333333,  0.333333, -0.111111,
	},
				  pim[4], ym[4];
	
	d=from/(double)to;
	*size2=((double)(size-3))/d;
	*buf2=realloc(*buf2,*size2*2*channels);
	if(channels==1)
	{
		for(i=0;i<(*size2);i++)
		{
			j=(int)(i*d)&0xfffe;
			J=((double)i*d)-j;
			//printf("d=%f i=%d j=%d J=%f(%d)\n",d,i,j,J,(int)J);
			//(*buf2)[i]=buf[j];
			ym[0]=buf[j];
			ym[1]=buf[j+1];
			ym[2]=buf[j+2];
			ym[3]=buf[j+3];
			pim[0]=ym[0];
			pim[1]=pim4x4[4]*ym[0]+pim4x4[5]*ym[1]+pim4x4[6]*ym[2]+pim4x4[7]*ym[3];
			pim[2]=pim4x4[8]*ym[0]+pim4x4[10]*ym[2]+pim4x4[11]*ym[3];
			pim[3]=pim4x4[12]*ym[0]+pim4x4[13]*ym[1]+pim4x4[14]*ym[2]+pim4x4[15]*ym[3];
			(*buf2)[i]=pim[0]+pim[1]*J+pim[2]*J*J+pim[3]*J*J*J;
		}
	}
	else
	{
		for(i=0;i<(*size2)*2;i++)
		{
			j=(int)(i*d)&0xfffe;
			J=((double)i*d)-j;
			//printf("d=%f i=%d j=%d J=%f(%d)\n",d,i,j,J,(int)J);
			//(*buf2)[i]=buf[j];
			ym[0]=buf[j];
			ym[1]=buf[j+2];
			ym[2]=buf[j+4];
			ym[3]=buf[j+6];
			pim[0]=ym[0];
			pim[1]=pim4x4[4]*ym[0]+pim4x4[5]*ym[1]+pim4x4[6]*ym[2]+pim4x4[7]*ym[3];
			pim[2]=pim4x4[8]*ym[0]+pim4x4[10]*ym[2]+pim4x4[11]*ym[3];
			pim[3]=pim4x4[12]*ym[0]+pim4x4[13]*ym[1]+pim4x4[14]*ym[2]+pim4x4[15]*ym[3];
			(*buf2)[i]=pim[0]+pim[1]*J+pim[2]*J*J+pim[3]*J*J*J;
			i++;
			j++;
			//printf("d=%f i=%d j=%d J=%f(%d)\n",d,i,j,J,(int)J);
			//(*buf2)[i]=buf[j];
			ym[0]=buf[j];
			ym[1]=buf[j+2];
			ym[2]=buf[j+4];
			ym[3]=buf[j+6];
			pim[0]=ym[0];
			pim[1]=pim4x4[4]*ym[0]+pim4x4[5]*ym[1]+pim4x4[6]*ym[2]+pim4x4[7]*ym[3];
			pim[2]=pim4x4[8]*ym[0]+pim4x4[10]*ym[2]+pim4x4[11]*ym[3];
			pim[3]=pim4x4[12]*ym[0]+pim4x4[13]*ym[1]+pim4x4[14]*ym[2]+pim4x4[15]*ym[3];
			(*buf2)[i]=pim[0]+pim[1]*J+pim[2]*J*J+pim[3]*J*J*J;
		}
	}
	//memcpy(*buf2,buf,*size2*4);
	return(size-3);
}

static char *resamplebuf(char *Buf, int from, int to, int size, int *Size2)
{
	static char *buf1=NULL;
	char *buf2=NULL;
	int last=0;
	static int size1=0;

	//printf("Buf=%p size=%d buf1=%p last=%d size1=%d\n",Buf,size,buf1,last,size1);
	if(size && Buf)
	{
		if(!buf1)
		{
			size1=6*channels;
			buf1=malloc(size1);
			memset(buf1,0,size1);
		}
		buf1=realloc(buf1,size1+size);
		memcpy(buf1+size1,Buf,size);
		size1+=size;
	}
	else
	{
		if(buf1 && size1)
		{
			buf1=realloc(buf1,size1+6*channels);
			memset(buf1+size1,0,6*channels);
			refreq((short*)buf1,size1/2/channels+3,Size2,(short**)&buf2,from,to);
			*Size2*=2*channels;
			size1=0;
			free(buf1);
			buf1=NULL;
			return(buf2);
		}
		else
		{
			*Size2=0;
			return(NULL);
		}
	}
	size1/=2*channels;
	last=refreq((short*)buf1,size1,Size2,(short**)&buf2,from,to);
	*Size2*=2*channels;
	size1*=2*channels;
	last*=2*channels;
	memmove(buf1,buf1+last,size1-last);
	size1-=last;
	//buf1=realloc(buf1,size1);
	return(buf2);
}

int writedsp(int fd, char *buf, size_t size)
{
	int status;
	int size2;
	char *buf2;

	buf2=resamplebuf(buf,samplerate,freq,size, &size2);
	if(buf2)
	{
		status = write(fd, buf2, size2);
		free(buf2);
		if (status == -1) {
			perror("Error writing to /dev/dsp");
			return(0);
		}
	}
	return(1);
}

int closedsp(int fd)
{
	int status;

	status = close(fd);
	if (status == -1) {
		perror("Error closing /dev/dsp");
		return(0);
	}
	return(1);
}
