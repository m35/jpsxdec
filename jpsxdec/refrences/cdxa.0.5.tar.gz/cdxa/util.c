#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "util.h"

int null(char *fmt,...)
{
	return(0);
}

void Exit()
{
	perror("");
	exit(1);
}

void dumpch(unsigned char *data, int len)
{
	int i;

	for(i=0;i<len;i++)
		if(isprint(data[i]))
			Printf("%c",data[i]);
		else
			Printf(".");
}

void hexdump(unsigned char *data, int len)
{
	int i,j;

	for(i=0;i<len;i++)
	{
		if(!(i%16))
			Printf("\n%8.8x: ",i);
		Printf("%2.2x",data[i]&0xff);
		if(!((i+1)%4))
			Printf(" ");
		if(((i+1)%16)==0 || (i+1)==len)
		{
			j=i>>4<<4;
			dumpch(&data[j],i-j+1);
		}
	}
	Printf("\n");
}

// writes a rudimentary RIFF header for later checking with xa2wav
char WriteRiffHeader(FILE *fdest)
{
	char rifhdr[44];

	memset(rifhdr,0,44);
	memcpy(rifhdr+0,"RIFF",4);
	memcpy(rifhdr+8,"CDXA",4);
	rewind(fdest);
	return fwrite(rifhdr,44,1,fdest);
};

void chomp(char *str)
{
	char *p;
	for(p=&str[strlen(str)-1];*p==' ';p--)
		*p='\0';
	while(*str==' ')
		memmove(str,str+1,strlen(str+1));
}

