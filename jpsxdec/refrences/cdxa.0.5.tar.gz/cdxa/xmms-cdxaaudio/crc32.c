#include "crc32.h"

#define P 0x4c11db7
#define BIT(a) (a?1:0)

unsigned long crc32(void *data, int len, unsigned long seed)
{
	int bit;
	int i;
	char *buf;
	unsigned long crc;

	crc=seed;
	buf=data;
	for(i=0;i<len;i++)
	{
		for(bit=0x80;bit;bit=bit>>1)
		{
			if(crc&0x80000000)
				crc = ((crc<<1)^P) ^ BIT(buf[i]&bit);
			else
				crc =  (crc<<1)    | BIT(buf[i]&bit);
		}
	}
	return(crc);
}
