#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

//#define NO_XA_HEADER

#define USE_FXD 1

#define kNumOfSamples   224
#define kNumOfSGs       18
#define TTYWidth		80

#define max(a,b) (a<b?b:a)
#define min(a,b) (a>b?b:a)

/* ADPCM */
#define XA_DATA_START   (0x44-48)

/* WAVE */
#define WAV_DATA_START  0x2c

enum {
        FALSE,
		TRUE
};

#define FXD_FxdToPCM(dt)        (max(min((short)((dt)>>16), 32767), -32768))
#define DblToPCM(dt)            (short)(max(min((dt), 32767), -32768))

#define WHP_READ68_AUTO(fp, dt)         WHP_Read68(dt, sizeof(*(dt)), 1, fp)
#define WHP_WRITE68_AUTO(fp, dt)        WHP_Write68(dt, sizeof(*(dt)), 1, fp)

#define WHP_CNV_SHORT68(dt, ndt)                WHP_CnvEndianShort((dt), (ndt))
#define WHP_CNV_LONG68(dt, ndt)                 WHP_CnvEndianLong((dt), (ndt))

#if USE_FXD
#define FXD_FxdToPcm16(dt)      (max(min((dt)/2, 32767), -32768))
#define FXD_Pcm16ToFxd(dt)      ((long)dt*2)
#endif

typedef int BOOL;

typedef char SoundGroup[128];

typedef struct SoundSector {
	char            sectorFiller[48];
	SoundGroup      SoundGroups[18];
} SoundSector;

typedef unsigned long DWORD;
typedef unsigned short WORD;

typedef struct {
	        char id[4];
			DWORD size;
} CHK_HD;

typedef struct {
	WORD formatTag;
	WORD nChannels;
	DWORD nSamplesPerSec;
	DWORD nAvgBytesPerSec;
	WORD nBlockAlign;
} WAVE_FMT;

/*      PCM  */
typedef struct {
	WORD nbitsPerSample;
} WAVE_PCM_SPEC;

#if USE_FXD
typedef long FXD;
#endif

char name[4096];
long flen;

SoundSector ssct;
char decodeBuf[kNumOfSamples*2];

#if USE_FXD
static FXD      K0[4] = {
	0x00000000,
	0x0000F000,
	0x0001CC00,
	0x00018800
};
static FXD      K1[4] = {
	0x00000000,
	0x00000000,
	0xFFFF3000,
	0xFFFF2400
};
FXD t1, t2;
FXD t1_x, t2_x;
#else
static double   K0[4] = {
	0.0,
	0.9375,
	1.796875,
	1.53125
};
static double   K1[4] = {
	0.0,
	0.0,
	-0.8125,
	-0.859375
};
double t1, t2;
double t1_x, t2_x;
#endif

BOOL convXaToWave(FILE *adp, char *wave_name, int cn, int fn_s, int fn_e);
BOOL checkXaHeader(char *xa_hdr);
long decodeSoundSect(SoundSector *ssct, FILE *wav);
long decodeSoundSect1(SoundSector *ssct, FILE *wav);
FILE *openWaveFile(char *fname, int cn, int fn);
void writeWaveHeader(FILE *wav, DWORD cycle, int channels, long totalSize);
signed char getSoundData(char *buf, long unit, long sample);
signed char getFilter(char *buf, long unit);
signed char getRange(char *buf, long unit);
#if USE_FXD
FXD FXD_FixMul(FXD a, FXD b);
#endif

int main(int argc, char *argv[])
{
	FILE *adp;
	int cn=0, fn;

	if (argc < 3 || argc > 5) {
		fprintf(stderr,
			"Usage : %s <XA_File> <WAV_File> <Channel> [fileno]\n", argv[0]);
		exit(1);
	}

	if(strcmp(argv[1],"-"))
	{
		adp = fopen(argv[1], "rb");
		if (!adp)
		{
			perror(argv[0]);
			exit(1);
		}
		fseek(adp,0,SEEK_END);
		flen=ftell(adp);
		fseek(adp,0,SEEK_SET);
	}
	else
	{
		flen=1;
		adp=stdin;
	}
	if (argc > 3)
	{
		cn = atoi(argv[3]);
		if (cn < 0 || 31 < cn)
		{
			fprintf(stderr, "Channel must be betwwen 0 and 31\n");
			exit(2);
		}
	}
	if (argc == 3)
	{
		if(adp==stdin)
		{
			fprintf(stderr,"multichannel decoding is not available for stdout\n");
			exit(1);
		}
		for (cn = 0; cn < 32; ++cn)
		{
			if (convXaToWave(adp, argv[2], cn, 1, 255))
			{
				fclose(adp);
				exit(3);
			}
			fseek(adp, 0, SEEK_SET);
		}
	}
	else if (argc == 4)
	{
		convXaToWave(adp, argv[2], cn, 1, 255);
	}
	else
	{
		fn = atoi(argv[4]);
		if (fn < 1)
		{
			fprintf(stderr, "fn must be >= 1\n");
			exit(2);
		}
		convXaToWave(adp, argv[2], cn, fn, fn);
	}
	fclose(adp);
	return(0);
}

BOOL convXaToWave(FILE *adp, char *wave_name, int cn, int fn_s, int fn_e)
{
	long totalSize=0;
	BOOL retVal = TRUE;
	int fn;
	FILE *wav=NULL;
	char xa_hdr[XA_DATA_START];
	int  channels=1;
	int maxch=0;
	long frame,cur,prev;

	t1 = t2 = 0;
	t1_x = t2_x = 0;
	fn = fn_s;
#ifndef NO_XA_HEADER
	if (fread(&xa_hdr, sizeof(xa_hdr), 1, adp) != 1) {
		fprintf(stderr, "Error read input file\n");
		return retVal;
	}
	if (checkXaHeader(xa_hdr)) {
		fprintf(stderr, "Input file not XA format\n");
		return retVal;
	}
#endif
	memset(&ssct, 0,sizeof(SoundSector));
	frame=0; cur=-1;
	while (fread(&ssct, sizeof(SoundSector), 1, adp) == 1)
	{
		/*fprintf(stderr,"reading %d\n",ssct.sectorFiller[45]&0xff);
		{
			static int i,j;
			for(j=0;j<4;j++)
			{
				for(i=0;i<16;i++)
					fprintf(stderr,"%02x ",ssct.sectorFiller[i+(j*16)]&0xff);
				fprintf(stderr,"\n");
			}
		}*/

		if(ssct.sectorFiller[45] >maxch)
			maxch=ssct.sectorFiller[45];

		prev=cur;
		cur=ssct.sectorFiller[45];
		if(cur<=prev)
		{
			frame=(frame+1)%TTYWidth; 
			if(!frame)
				fprintf(stderr,"\033[9;1H\033[J");
		}
		fprintf(stderr,"\033[%ld;%ldH\033[4%d;1m%ld\033[0m\r",
				cur+9,
				frame+1,
				(ssct.sectorFiller[46] == 0x64
				 ?(ssct.sectorFiller[45] == cn?2:4)
				 :1
				),
				cur);

		if ((ssct.sectorFiller[45] == cn) && (ssct.sectorFiller[46] == 0x64))
		{
			channels = (ssct.sectorFiller[47] & 1)+1;
			if (ssct.sectorFiller[44] != fn)
			{
				if (ssct.sectorFiller[44] > fn_e)
					break;
				if(wav!=stdout);
				{
					writeWaveHeader(wav, 38000, channels, totalSize);
					fclose(wav);
					fprintf(stderr,"\033[8;1H%d.%d) %ld\033[K\n",cn,ssct.sectorFiller[44]&0xff,totalSize);
					wav=NULL;
				}
				fn=ssct.sectorFiller[44];
			}
			if (ssct.sectorFiller[44] == fn)
			{
				if(!wav)
				{
					wav = openWaveFile(wave_name, cn, fn);
					if(wav!=stdout)
						fseek(wav, WAV_DATA_START, SEEK_SET);
					totalSize = 0;
				}
				if (channels == 2)
					totalSize += decodeSoundSect1(&ssct, wav);
				else
					totalSize += decodeSoundSect(&ssct, wav);
				if(adp==stdin)
					fprintf(stderr,"\033[8;1H%d.%d/%d) %ld %ld:%02ld\033[K\r",cn,fn,maxch,totalSize,totalSize/(38000*4)/60,totalSize/(38000*4)%60);
				else
					fprintf(stderr,"\033[8;1H%d.%d/%d) %ld@%ld/%ld % 3.2f%%\033[K\r",cn,ssct.sectorFiller[44]&0xff,maxch,totalSize,ftell(adp),flen,ftell(adp)/(float)flen*100);
				retVal = FALSE;
			}
		}
	}	
	if(wav)
	{
		if(wav!=stdout);
			writeWaveHeader(wav, 38000, channels, totalSize);
		fclose(wav);
		fprintf(stderr,"\033[8;1H%d.%d) %ld\033[K\n",cn,fn,totalSize);
	}
	return retVal;
}

BOOL checkXaHeader(char *xa_hdr)
{
	if (memcmp(xa_hdr, "RIFF", 4))
		return TRUE;
	if (memcmp(&xa_hdr[8], "CDXA", 4))
		return TRUE;
	return FALSE;
}

long decodeSoundSect(SoundSector *ssct, FILE *wav)
{
	long count, outputBytes;
	signed char snddat, filt, range;
	short decoded;
	long unit, sample;
	long sndgrp;
#if USE_FXD
	FXD tmp2, tmp3, tmp4, tmp5;
#else
	double tmp2, tmp3, tmp4, tmp5;
#endif
	
	outputBytes = 0;

	for (sndgrp = 0; sndgrp < kNumOfSGs; sndgrp++)
	{
		count = 0;
		for (unit = 0; unit < 8; unit++)
		{
			range = getRange(ssct->SoundGroups[sndgrp], unit);
			filt = getFilter(ssct->SoundGroups[sndgrp], unit);
			for (sample = 0; sample < 28; sample++)
			{
				snddat = getSoundData(ssct->SoundGroups[sndgrp], unit, sample);
#if USE_FXD
				tmp2 = (long)(snddat) << (12 - range);
				tmp3 = FXD_Pcm16ToFxd(tmp2);
				tmp4 = FXD_FixMul(K0[filt], t1);
				tmp5 = FXD_FixMul(K1[filt], t2);
				t2 = t1;
				t1 = tmp3 + tmp4 + tmp5;
				decoded = FXD_FxdToPcm16(t1);
#else
				tmp2 = (double)(1 << (12 - range));
				tmp3 = (double)snddat * tmp2;
				tmp4 = t1 * K0[filt];
				tmp5 = t2 * K1[filt];
				t2 = t1;
				t1 = tmp3 + tmp4 + tmp5;
				decoded = DblToPCM(t1);
#endif
				decodeBuf[count++] = (char)(decoded & 0x0000ffff);
				decodeBuf[count++] = (char)(decoded >> 8);
			}
		}
		fwrite(decodeBuf, 1, sizeof(decodeBuf), wav);
		outputBytes += count;
	}
	return outputBytes;
}

long decodeSoundSect1(SoundSector *ssct, FILE *wav)
{
	long count, outputBytes;
	signed char snddat, filt, range;
	signed char filt1, range1;
	short decoded;
	long unit, sample;
	long sndgrp;
#if USE_FXD
	FXD tmp2, tmp3, tmp4, tmp5;
#else
	double tmp2, tmp3, tmp4, tmp5;
#endif

	outputBytes = 0;

	for (sndgrp = 0; sndgrp < kNumOfSGs; sndgrp++)
	{
		count = 0;
		for (unit = 0; unit < 8; unit+= 2)
		{
			range = getRange(ssct->SoundGroups[sndgrp], unit);
			filt = getFilter(ssct->SoundGroups[sndgrp], unit);
			range1 = getRange(ssct->SoundGroups[sndgrp], unit+1);
			filt1 = getFilter(ssct->SoundGroups[sndgrp], unit+1);

			for (sample = 0; sample < 28; sample++)
			{
				// Channel 1
				snddat = getSoundData(ssct->SoundGroups[sndgrp], unit, sample);
#if USE_FXD
				tmp2 = (long)(snddat) << (12 - range);
				tmp3 = FXD_Pcm16ToFxd(tmp2);
				tmp4 = FXD_FixMul(K0[filt], t1);
				tmp5 = FXD_FixMul(K1[filt], t2);
				t2 = t1;
				t1 = tmp3 + tmp4 + tmp5;
				decoded = FXD_FxdToPcm16(t1);
#else
				tmp2 = (double)(1 << (12 - range));
				tmp3 = (double)snddat * tmp2;
				tmp4 = t1 * K0[filt];
				tmp5 = t2 * K1[filt];
				t2 = t1;
				t1 = tmp3 + tmp4 + tmp5;
				decoded = DblToPCM(t1);
#endif
				decodeBuf[count++] = (char)(decoded & 0x0000ffff);
				decodeBuf[count++] = (char)(decoded >> 8);

				// Channel 2
				snddat = getSoundData(ssct->SoundGroups[sndgrp], unit+1, sample);
#if USE_FXD
				tmp2 = (long)(snddat) << (12 - range1);
				tmp3 = FXD_Pcm16ToFxd(tmp2);
				tmp4 = FXD_FixMul(K0[filt1], t1_x);
				tmp5 = FXD_FixMul(K1[filt1], t2_x);
				t2_x = t1_x;
				t1_x = tmp3 + tmp4 + tmp5;
				decoded = FXD_FxdToPcm16(t1_x);
#else
				tmp2 = (double)(1 << (12 - range1));
				tmp3 = (double)snddat * tmp2;
				tmp4 = t1_x * K0[filt1];
				tmp5 = t2_x * K1[filt1];
				t2_x = t1_x;
				t1_x = tmp3 + tmp4 + tmp5;
				decoded = DblToPCM(t1_x);
#endif
				decodeBuf[count++] = (char)(decoded & 0x0000ffff);
				decodeBuf[count++] = (char)(decoded >> 8);
			}
		}
		fwrite(decodeBuf, 1, sizeof(decodeBuf), wav);
		outputBytes += count;
	}
	return outputBytes;
}

FILE *openWaveFile(char *fname, int cn, int fn)
{
	FILE *wav;

	if(!strcmp(fname,"-"))
		wav=stdout;
	else
	{
		sprintf(name, "%s.%02d.wav", fname, cn);
		fprintf(stderr, "%s\n", name);
		wav = fopen(name, "wb");
		if (wav == NULL) {
			fprintf(stderr, "Error creating %s\n", name);
			exit(1);
		}
	}
	return wav;
}

void writeWaveHeader(FILE *wav, DWORD cycle, int channels, long totalSize)
{
	static CHK_HD rifhd = {{'R','I','F','F'}};
	static char wave_id[] = {'W','A','V','E'};
	static CHK_HD fmthd = {{'f','m','t',' '}};
	static WAVE_PCM_SPEC pcmspec;
	static WAVE_FMT fmt;
	static CHK_HD datahd = {{'d', 'a', 't', 'a'}};

	fmthd.size = sizeof(WAVE_FMT)+sizeof(WAVE_PCM_SPEC);
	fmt.formatTag = 1;
	fmt.nChannels = channels;
	fmt.nSamplesPerSec = cycle;
	fmt.nAvgBytesPerSec = cycle * 2 * fmt.nChannels;
	fmt.nBlockAlign = 2 * fmt.nChannels;
	pcmspec.nbitsPerSample = 16;
	datahd.size = totalSize;
	rifhd.size = sizeof(wave_id) +
		sizeof(fmthd) + fmthd.size + sizeof(datahd) + datahd.size;

	rewind(wav);
	fwrite(&rifhd, sizeof(rifhd), 1, wav);
	fwrite(wave_id, sizeof(wave_id), 1, wav);
	fwrite(&fmthd, sizeof(fmthd), 1, wav);
	fwrite(&fmt, sizeof(fmt), 1, wav);
	fwrite(&pcmspec, sizeof(pcmspec), 1, wav);
	fwrite(&datahd, sizeof(datahd), 1, wav);
}

signed char getSoundData(char *buf, long unit, long sample)
{
	signed char ret;
	char *p;
	long offset, shift;

	p = buf;
	shift = (unit%2) * 4;

	offset = 16 + (unit / 2) + (sample * 4);
	p += offset;

	ret = (*p >> shift) & 0x0F;

	if (ret > 7) {
		ret -= 16;
	}
	return ret;
}

signed char getFilter(char *buf, long unit)
{
	return (*(buf + 4 + unit) >> 4) & 0x03;
}


signed char getRange(char *buf, long unit)
{
	return *(buf + 4 + unit) & 0x0F;
}

#if USE_FXD
FXD FXD_FixMul(FXD a, FXD b)
{
	long                high_a, low_a, high_b, low_b;
	long                hahb, halb, lahb;
	unsigned long       lalb;
	FXD                 ret;

	high_a = a >> 16;
	low_a = a & 0x0000FFFF;
	high_b = b >> 16;
	low_b = b & 0x0000FFFF;

	hahb = (high_a * high_b) << 16;
	halb = high_a * low_b;
	lahb = low_a * high_b;
	lalb = (unsigned long)(low_a * low_b) >> 16;

	ret = hahb + halb + lahb + lalb;

	return ret;
}
#endif
