#ifndef XAUTIL_H
#define XAUTIL_H

#include <stdio.h>

//#define DEBUG

#ifdef DEBUG
#define Printf printf
#else
#define Printf null
//#define Printf
#endif

void dumpch(unsigned char *data, int len);
void hexdump(unsigned char *data, int len);
int null(char *fmt,...);
void Exit(void);
void chomp(char *str);

char WriteRiffHeader(FILE *fdest);

#endif
