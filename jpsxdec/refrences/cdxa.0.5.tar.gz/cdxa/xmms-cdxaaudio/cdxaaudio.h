/*  XMMS - Cross-platform multimedia player
 *  Copyright (C) 1998-1999  Peter Alm, Mikael Alm, Olle Hallnas, Thomas Nilsson
 *                           and 4Front Technologies
 *
 *  CDXA Audio Player - XMMS Input Plugin
 *  Copyright (C) 2000 Jonathan Atkins
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#ifndef CDXAAUDIO_H
#define CDXAAUDIO_H

#include "config.h"

#include <pthread.h>

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <glib.h>

#include "xmms/plugin.h"
#include "xadecode.h"

extern InputPlugin cdxaaudio_ip;

typedef struct {
	int channel, filenum, freq, stereo, len;
	unsigned long offset;
	unsigned char buf[XAWAVBUFSIZE];
} XABlock;

typedef struct {
	char *dev, *dir;
	int fd;	/* cdrom file descriptor */
	gboolean stereo, playing, reading, stopped;
	long bits, freq;
	int filenum, channel, maxchannel;
	unsigned long start, length;
	int	tail ,head;
	int seek_to, offset, play_offset;
	char *title;
	XABlock *buf;
	int bufsize, prebuf;	//number of XABlocks blocks
	gboolean channel_seen[32];
	///////////////////////////////////////////////////////////////
	long avg_bytes_per_sec;
} CDXAState;

static void cdxaaudio_init(void);
static int is_our_file(char *filename);
static void play_file(char *filename);
static void stop(void);
static void seek(int time);
static void cdxaaudio_pause(short p);
static int get_time(void);
static void about(void);
static void config(void);
static void get_song_info(char *filename, char **title, int *length);

#endif
