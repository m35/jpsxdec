#ifndef CRC32_H
#define CRC32_H

unsigned long crc32(void *data, int len, unsigned long seed);

#endif
